"""Build block geometry using the upstream sprites' original palette and UVs.
Run with Python + Pillow and the supplied upstream jar; no upstream art is bundled.
"""
from pathlib import Path
import json,zipfile,io,sys
from PIL import Image
jar=Path(sys.argv[1] if len(sys.argv)>1 else 'libs/turnbattle-2.0.21.jar')
root=Path(__file__).resolve().parents[1]/'src/main/resources/assets/turnbattle/models/item'
root.mkdir(parents=True,exist_ok=True)
z=zipfile.ZipFile(jar)
faces=['north','south','east','west','up','down']
def image(name):return Image.open(io.BytesIO(z.read(f'assets/turnbattle/textures/item/{name}.png'))).convert('RGBA')
def uv_color(im,rgb):
 x,y=min(((x,y) for y in range(im.height) for x in range(im.width) if im.getpixel((x,y))[3]>127),key=lambda p:sum((im.getpixel(p)[i]-rgb[i])**2 for i in range(3)))
 return [x+.05,y+.05,x+.95,y+.95]
def cube(a,b,uv):return {'from':a,'to':b,'faces':{f:{'uv':uv,'texture':'#layer0'} for f in faces}}
def model(name,elements,small=False):
 data={'parent':'minecraft:item/handheld','textures':{'layer0':f'turnbattle:item/{name}','particle':f'turnbattle:item/{name}'},'elements':elements}
 data['display']={'gui':{'rotation':[25,225,0],'translation':[0,0,0],'scale':[.8,.8,.8]},'fixed':{'rotation':[0,180,0],'translation':[0,0,0],'scale':[.75,.75,.75]},'ground':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[.4,.4,.4]}}
 if small:
  for key,rot in [('thirdperson_righthand',[0,-90,55]),('thirdperson_lefthand',[0,90,-55]),('firstperson_righthand',[0,-90,25]),('firstperson_lefthand',[0,90,-25])]:data['display'][key]={'rotation':rot,'translation':[0,2,0],'scale':[.65,.65,.65]}
 (root/f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
# Keep the exact recognizable sprite outlines, with solid block depth and bevel-free edges.
for name,depth in [('toy_knife',2.5),('real_knife',2.5),('climb_claws',3),('tough_glove',4),('ballet_shoes',3)]:
 im=image(name);elements=[]
 for y in range(16):
  for x in range(16):
   if im.getpixel((x,y))[3]<128:continue
   elements.append(cube([x,15-y,8-depth/2],[x+1,16-y,8+depth/2],[x,y,x+1,y+1]))
 model(name,elements)
name='torn_notebook';im=image(name);els=[]
def add(a,b,color):els.append(cube(a,b,uv_color(im,color)))
add([4.4,3.6,6.4],[11.6,12.4,9.6],(207,201,170)) # closed page block
add([4,3.2,6],[12,12.8,6.5],(126,64,182))
add([4,3.2,9.5],[12,12.8,10],(126,64,182))
add([3.7,3.2,6],[4.6,12.8,10],(83,47,123))
add([4.1,4,5.8],[4.7,12,6],(164,117,210)) # worn edge
add([6,7.3,9.99],[9.8,9.6,10.15],(166,125,214)) # cover label
add([7.4,2.7,7.9],[8.1,3.6,8.3],(136,86,187)) # bookmark
model(name,els,True)
name='empty_gun';im=image(name);els=[]
add([5.6,2,6.7],[8.6,7.4,9.3],(91,70,41))
add([5.4,2,6.4],[7.9,5.9,6.8],(112,88,52))
add([5,7,6.3],[11,10,9.7],(143,141,127)) # frame
add([7.1,6.7,5.9],[10.1,10.4,10.1],(171,167,153)) # cylinder
add([9.8,8.5,6.7],[14,10,9.3],(182,179,162)) # short barrel
add([13.7,8.6,7.1],[14.1,9.9,8.9],(66,63,55)) # muzzle
add([12.5,10,7.6],[13.4,10.6,8.4],(195,194,175))
add([4.7,9.5,7.2],[5.5,10.8,8.8],(122,118,101))
add([8.4,5.3,7.4],[11,5.9,8.6],(87,85,72)) # squared trigger guard
add([10.4,5.4,7.4],[11,7.4,8.6],(87,85,72))
add([8.6,6,7.7],[9.2,7.2,8.3],(69,65,54))
model(name,els,True)
name='burnt_pan';im=image(name);els=[]
# Preserve the original round pixel rim, scorched bowl and diagonal wooden handle.
for y in range(16):
 for x in range(16):
  r,g,b,a=im.getpixel((x,y))
  if a<128:continue
  neutral=max(r,g,b)-min(r,g,b)<18
  rim=neutral and max(r,g,b)>48
  handle=r>65 and r>g*1.3
  rear,front=(6,10) if rim else ((6.6,9.4) if handle else (6,7.4))
  els.append(cube([x,15-y,rear],[x+1,16-y,front],[x,y,x+1,y+1]))
model(name,els)
print('Generated',len(list(root.glob('*.json'))),'block models')
