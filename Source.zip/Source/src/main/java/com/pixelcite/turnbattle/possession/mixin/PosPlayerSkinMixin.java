package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin({AbstractClientPlayerEntity.class,MirrorCloneRenderer.MirrorFakePlayer.class})
public abstract class PosPlayerSkinMixin {
    @Inject(method="getSkinTextures",at=@At("HEAD"),cancellable=true)
    private void possession$skin(CallbackInfoReturnable<SkinTextures> cir){
        var e=(AbstractClientPlayerEntity)(Object)this;var a=PosClient.bodies.get(PosClient.soulOf(e));
        if(a!=null&&a.owner()!=null)cir.setReturnValue(PosClient.skin(a.owner()));
    }
}
