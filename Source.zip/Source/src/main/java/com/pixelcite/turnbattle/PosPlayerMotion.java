package com.pixelcite.turnbattle;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.*;
import net.minecraft.util.*;

/** Vanilla player/biped motion transferred onto the borrowed body's original bones and proportions. */
public final class PosPlayerMotion {
    private static BipedEntityModel<LivingEntity> human;
    private PosPlayerMotion() {}
    private static BipedEntityModel<LivingEntity> reference(){
        if(human==null)human=new BipedEntityModel<>(BipedEntityModel.getModelData(Dilation.NONE,0).getRoot().createPart(64,64));
        return human;
    }
    public static void apply(BipedEntityModel<?> target,LivingEntity source,float delta,float limbAngle,float limbDistance,float age,float headYaw,float headPitch){
        var model=reference();for(var part:parts(model))part.resetTransform();
        model.handSwingProgress=source.getHandSwingProgress(delta);model.riding=source.hasVehicle();model.child=source.isBaby();
        model.sneaking=source.isInSneakingPose();model.leaningPitch=source.getLeaningPitch(delta);
        var main=armPose(source,Hand.MAIN_HAND);var off=armPose(source,Hand.OFF_HAND);
        if(main.isTwoHanded())off=source.getOffHandStack().isEmpty()?BipedEntityModel.ArmPose.EMPTY:BipedEntityModel.ArmPose.ITEM;
        model.rightArmPose=source.getMainArm()==Arm.RIGHT?main:off;model.leftArmPose=source.getMainArm()==Arm.RIGHT?off:main;
        model.animateModel(source,limbAngle,limbDistance,delta);model.setAngles(source,limbAngle,limbDistance,age,headYaw,headPitch);
        copy(target,model);
    }
    static ModelPart[] parts(BipedEntityModel<?> m){return new ModelPart[]{m.head,m.hat,m.body,m.rightArm,m.leftArm,m.rightLeg,m.leftLeg};}
    public static void copy(BipedEntityModel<?> target,BipedEntityModel<?> player){
        var to=parts(target);var from=parts(player);
        for(int i=0;i<to.length;i++){
            var a=to[i];var b=from[i];PosClient.savePart(a);
            var base=a.getDefaultTransform();var origin=b.getDefaultTransform();
            a.pivotX=base.pivotX+b.pivotX-origin.pivotX;a.pivotY=base.pivotY+b.pivotY-origin.pivotY;a.pivotZ=base.pivotZ+b.pivotZ-origin.pivotZ;
            a.pitch=b.pitch;a.yaw=b.yaw;a.roll=b.roll;
        }
        syncWear(target);
    }
    public static void syncWear(BipedEntityModel<?> target){
        if(target instanceof net.minecraft.client.render.entity.model.PlayerEntityModel<?> p){
            for(var part:new ModelPart[]{p.jacket,p.rightSleeve,p.leftSleeve,p.rightPants,p.leftPants})PosClient.savePart(part);
            p.jacket.copyTransform(p.body);p.rightSleeve.copyTransform(p.rightArm);p.leftSleeve.copyTransform(p.leftArm);p.rightPants.copyTransform(p.rightLeg);p.leftPants.copyTransform(p.leftLeg);
        }
    }
    public static BipedEntityModel.ArmPose armPose(LivingEntity source,Hand hand){
        ItemStack stack=source.getStackInHand(hand);if(stack.isEmpty())return BipedEntityModel.ArmPose.EMPTY;
        if(source.isUsingItem()&&source.getActiveHand()==hand)return switch(stack.getUseAction()){
            case BLOCK -> BipedEntityModel.ArmPose.BLOCK;
            case BOW -> BipedEntityModel.ArmPose.BOW_AND_ARROW;
            case SPEAR -> BipedEntityModel.ArmPose.THROW_SPEAR;
            case CROSSBOW -> BipedEntityModel.ArmPose.CROSSBOW_CHARGE;
            case SPYGLASS -> BipedEntityModel.ArmPose.SPYGLASS;
            case TOOT_HORN -> BipedEntityModel.ArmPose.TOOT_HORN;
            case BRUSH -> BipedEntityModel.ArmPose.BRUSH;
            default -> BipedEntityModel.ArmPose.ITEM;
        };
        if(!source.handSwinging&&stack.isOf(Items.CROSSBOW)&&CrossbowItem.isCharged(stack))return BipedEntityModel.ArmPose.CROSSBOW_HOLD;
        return BipedEntityModel.ArmPose.ITEM;
    }
}
