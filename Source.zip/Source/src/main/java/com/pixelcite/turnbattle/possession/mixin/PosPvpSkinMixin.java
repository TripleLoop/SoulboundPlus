package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="com.pixelcite.turnbattle.BattleEntityRenderer$PvpFakePlayer")
public abstract class PosPvpSkinMixin {
    @Inject(method="getSkinTextures",at=@At("HEAD"),cancellable=true)
    private void possession$skin(CallbackInfoReturnable<SkinTextures> cir){
        var a=PosClient.bodies.get(((AbstractClientPlayerEntity)(Object)this).getUuid());
        if(a!=null&&a.owner()!=null)cir.setReturnValue(PosClient.skin(a.owner()));
    }
}
