package com.pixelcite.turnbattle.possession.mixin;

import com.pixelcite.turnbattle.PosGloves;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PosGloveArmMixin {
    @Inject(method="renderArm",at=@At("TAIL"))
    private void plus$gloveArm(MatrixStack matrices,VertexConsumerProvider vertices,int light,AbstractClientPlayerEntity player,ModelPart arm,ModelPart sleeve,CallbackInfo ci){
        if(!PosGloves.firstPerson)return;
        var model=((PlayerEntityRenderer)(Object)this).getModel();
        PosGloves.render(arm,arm==model.rightArm?Arm.RIGHT:Arm.LEFT,player,matrices,vertices,light);
    }
}
