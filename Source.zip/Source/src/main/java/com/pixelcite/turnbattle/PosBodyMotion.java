package com.pixelcite.turnbattle;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

final class PosBodyMotion {
    static void struggle(Entity body,java.util.UUID logicalBody,Vec3d origin,long start,long end,long now){
        var pose=PosStruggleMotion.sample(logicalBody,now-start,end-start);
        double strength=PosConfig.get("twitch");
        Vec3d target=origin.add(pose.x()*0.45*strength,pose.y()*0.45*strength,pose.z()*0.45*strength);
        place(body,target);
    }
    static void eject(Entity body,Vec3d direction){
        if(body instanceof ServerPlayerEntity p&&BattleManager.isInBattle(p.getUuid()))return;
        Vec3d d=direction.multiply(1,0,1);if(d.lengthSquared()<0.01)d=body.getRotationVec(1).multiply(1,0,1);
        place(body,body.getPos().add(d.normalize().multiply(0.18*PosConfig.get("chestPull"))));
    }
    private static void place(Entity body,Vec3d target){
        Vec3d delta=target.subtract(body.getPos());
        if(body.getWorld().getBlockCollisions(body,body.getBoundingBox().stretch(delta)).iterator().hasNext())return;
        if(body instanceof ServerPlayerEntity p)p.teleport(p.getServerWorld(),target.x,target.y,target.z,p.getYaw(),p.getPitch());
        else body.refreshPositionAndAngles(target.x,target.y,target.z,body.getYaw(),body.getPitch());
        body.setVelocity(Vec3d.ZERO);
    }
}
