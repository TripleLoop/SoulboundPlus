package com.pixelcite.turnbattle;

import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import java.util.*;

/** A free soul may use its body's gear. Possession transfers the single live holder to the occupant. */
final class PosBodyGear {
    static final Map<UUID,NbtCompound> kept=new HashMap<>();
    static boolean backpack(ItemStack stack){return !stack.isEmpty()&&backpack(Registries.ITEM.getId(stack.getItem()));}
    static boolean backpack(Identifier id){return id.getNamespace().equals("sophisticatedbackpacks")&&(id.getPath().equals("backpack")||id.getPath().endsWith("_backpack"));}
    static void close(ServerPlayerEntity p){if(p.currentScreenHandler!=p.playerScreenHandler)p.closeHandledScreen();}
    static boolean freeAccess(ServerPlayerEntity p,PosManager.Anchor a){return a!=null&&SoulWalk.isOut(p)&&!PosManager.possessing(p.getUuid())&&PosManager.occupant(a.owner)==null;}
    static boolean keepOnSoul(ServerPlayerEntity p,PosManager.Anchor a,ItemStack stack){return freeAccess(p,a)&&backpack(stack);}
    static void left(ServerPlayerEntity p,PosManager.Anchor a){a.accessories=PosAccessories.capture(p,false);a.accessoryHolder=p.getUuid();grant(p,a);}
    static void grant(ServerPlayerEntity p,PosManager.Anchor a){
        if(!freeAccess(p,a))return;
        for(int i=0;i<a.items.size();i++)if(backpack(a.items.get(i))){int slot=p.getInventory().getStack(i).isEmpty()?i:empty(p);if(slot<0)continue;
            p.getInventory().setStack(slot,a.items.get(i));a.items.set(i,ItemStack.EMPTY);
        }p.currentScreenHandler.sendContentUpdates();
    }
    private static int empty(ServerPlayerEntity p){for(int i=0;i<36;i++)if(p.getInventory().getStack(i).isEmpty())return i;return -1;}
    static void store(PosManager.Anchor a,ItemStack stack,MinecraftServer s,int preferred){
        if(stack.isEmpty())return;
        if(preferred>=0&&preferred<a.items.size()&&a.items.get(preferred).isEmpty()){a.items.set(preferred,stack);return;}
        for(int i=0;i<36;i++)if(a.items.get(i).isEmpty()){a.items.set(i,stack);return;}
        ServerWorld world=s.getWorld(a.out.dim);if(world!=null)world.spawnEntity(new ItemEntity(world,a.out.pos.x,a.out.pos.y+0.5,a.out.pos.z,stack));
        else throw new IllegalStateException("Cannot store body item: original dimension unavailable");
    }
    static void suspend(ServerPlayerEntity p,PosManager.Anchor a){
        close(p);
        if(a==null)return;
        if(SoulWalk.isOut(p)&&!PosManager.possessing(p.getUuid()))PosManager.stashSoulItems(p,a);
        if(p.getUuid().equals(a.accessoryHolder)){a.accessories=PosAccessories.capture(p,true);a.accessoryHolder=null;}
        else depositStray(p,a);
        if(SoulWalk.isOut(p)&&!PosManager.possessing(p.getUuid()))for(int i=0;i<41;i++){
            ItemStack stack=p.getInventory().getStack(i);if(!backpack(stack))continue;p.getInventory().setStack(i,ItemStack.EMPTY);store(a,stack,p.getServer(),i);
        }
    }
    static void tickSoul(ServerPlayerEntity p,PosManager.Anchor a){if(!p.getUuid().equals(a.accessoryHolder))depositStray(p,a);grant(p,a);}
    private static void depositStray(ServerPlayerEntity p,PosManager.Anchor a){
        for(ItemStack stack:PosAccessories.stacks(PosAccessories.capture(p,true),p.getRegistryManager())){
            PosManager.Session session=PosManager.occupant(a.owner);ServerPlayerEntity holder=session!=null?PosManager.player(p.getServer(),session.soul):null;
            if(holder!=null){holder.getInventory().insertStack(stack);PosManager.inventoryTo(holder,a);holder.currentScreenHandler.sendContentUpdates();}
            if(!stack.isEmpty())store(a,stack,p.getServer(),-1);
        }
    }
    static void suspendAnchor(MinecraftServer s,PosManager.Anchor a){
        ServerPlayerEntity holder=PosManager.player(s,a.accessoryHolder);if(holder!=null){
            if(holder.getUuid().equals(a.owner)&&!PosManager.possessing(a.owner))PosManager.stashSoulItems(holder,a);
            suspend(holder,a);
        }
    }
    static NbtCompound snapshot(MinecraftServer s,PosManager.Anchor a){
        ServerPlayerEntity holder=PosManager.player(s,a.accessoryHolder);return holder!=null?PosAccessories.capture(holder,false):a.accessories.copy();
    }
    static boolean takePlayerBody(ServerPlayerEntity p,PosManager.Anchor target){
        NbtCompound gear=snapshot(p.getServer(),target);
        if(!PosAccessories.canApply(p,gear)){PosManager.message(p,"This body's accessory slot types are unavailable to your player. Possession cancelled.");return false;}
        suspend(p,PosManager.anchors.get(p.getUuid()));suspendAnchor(p.getServer(),target);
        PosAccessories.apply(p,gear);target.accessories=gear;target.accessoryHolder=p.getUuid();return true;
    }
    static boolean takeMobBody(ServerPlayerEntity p,LivingEntity mob,PosManager.Session session){
        NbtCompound gear=PosAccessories.capture(mob,false);
        if(!PosAccessories.canApply(p,gear)){PosManager.message(p,"This mob's accessory slots are unavailable to your player.");return false;}
        suspend(p,PosManager.anchors.get(p.getUuid()));PosAccessories.capture(mob,true);PosAccessories.apply(p,gear);session.accessories=gear;return true;
    }
    static void resume(MinecraftServer s,PosManager.Anchor a){
        if(a==null||PosManager.occupant(a.owner)!=null)return;ServerPlayerEntity owner=PosManager.player(s,a.owner);
        if(owner==null||PosManager.possessing(a.owner)||!SoulWalk.isOut(owner))return;
        if(!owner.getUuid().equals(a.accessoryHolder)){
            if(!PosAccessories.canApply(owner,a.accessories)){PosManager.message(owner,"Body accessory slot types are missing; gear is stored safely with your body.");return;}
            // Items equipped by a displaced soul while its body was occupied are deposited once at that body.
            for(ItemStack stack:PosAccessories.stacks(PosAccessories.capture(owner,true),s.getRegistryManager()))store(a,stack,s,-1);
            PosAccessories.apply(owner,a.accessories);a.accessoryHolder=owner.getUuid();
        }grant(owner,a);
    }
    static void release(ServerPlayerEntity p,PosManager.Session session){
        close(p);NbtCompound gear=PosAccessories.capture(p,true);
        if(session.owner!=null){PosManager.Anchor a=PosManager.anchors.get(session.owner);if(a!=null){a.accessories=gear;a.accessoryHolder=null;}}
        else if(session.mob!=null&&!session.mob.isRemoved()){
            if(PosAccessories.canApply(session.mob,gear))PosAccessories.apply(session.mob,gear);
            else for(ItemStack stack:PosAccessories.stacks(gear,p.getServer().getRegistryManager()))session.mob.dropStack(stack);
        }
    }
    static NbtList leased(MinecraftServer s,PosManager.Anchor a){
        NbtList list=new NbtList();ServerPlayerEntity p=PosManager.player(s,a.owner);if(p==null||!freeAccess(p,a))return list;
        for(int i=0;i<41;i++){ItemStack stack=p.getInventory().getStack(i);if(!backpack(stack))continue;NbtCompound item=new NbtCompound();item.putInt("Slot",i);item.put("Stack",stack.encode(s.getRegistryManager()));list.add(item);}
        ItemStack cursor=p.currentScreenHandler.getCursorStack();if(backpack(cursor)){NbtCompound item=new NbtCompound();item.putInt("Slot",-1);item.put("Stack",cursor.encode(s.getRegistryManager()));list.add(item);}return list;
    }
    static void restoreLeased(ServerPlayerEntity p,NbtList list){
        for(int i=0;i<list.size();i++){NbtCompound item=list.getCompound(i);ItemStack stack=ItemStack.fromNbt(p.getRegistryManager(),item.getCompound("Stack")).orElseThrow();int slot=item.getInt("Slot");
            if(slot>=0&&slot<41&&p.getInventory().getStack(slot).isEmpty())p.getInventory().setStack(slot,stack);
            else if(!p.getInventory().insertStack(stack))p.dropItem(stack,false,false);
        }
    }
    static void death(ServerPlayerEntity p,boolean keep,NbtCompound stored){
        NbtCompound live=PosAccessories.capture(p,true);NbtCompound gear=stored!=null?stored:live;
        if(keep)kept.put(p.getUuid(),gear);else for(ItemStack stack:PosAccessories.stacks(gear,p.getRegistryManager()))p.dropItem(stack,false,false);
    }
    static void restoreKept(ServerPlayerEntity p){
        NbtCompound gear=kept.get(p.getUuid());if(gear==null)return;if(!PosAccessories.canApply(p,gear)){PosManager.message(p,"Retained accessories are stored safely. Restore their slot definitions and rejoin.");return;}
        PosAccessories.apply(p,gear);kept.remove(p.getUuid());PosJournal.save(p.getServer());
    }
    static void soulDrop(ServerPlayerEntity p,ItemEntity dropped){
        if(dropped==null||!SoulWalk.isOut(p)||PosManager.possessing(p.getUuid()))return;
        PosManager.Anchor a=PosManager.anchors.get(p.getUuid());if(a==null)return;PosManager.trackBody(p.getServer(),a);
        ServerWorld world=p.getServer().getWorld(a.out.dim);if(world==null)return;
        dropped.setVelocity(net.minecraft.util.math.Vec3d.ZERO);
        if(world==dropped.getWorld())dropped.refreshPositionAndAngles(a.out.pos.x,a.out.pos.y+0.5,a.out.pos.z,dropped.getYaw(),0);
        else dropped.teleport(world,a.out.pos.x,a.out.pos.y+0.5,a.out.pos.z,Set.of(),dropped.getYaw(),0);
    }
}
