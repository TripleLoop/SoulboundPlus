package com.pixelcite.turnbattle;
import net.minecraft.client.MinecraftClient;
import java.lang.reflect.*;
import java.util.List;

/** Adds a ring to Soulbound's existing effect renderer, with the server-supplied soul color. */
public final class PosEntryVisual {
    private static final Field RINGS,TICKS;
    private static final Constructor<?> RING;
    static{
        try{
            RINGS=SoulWalkClient.class.getDeclaredField("rings");TICKS=SoulWalkClient.class.getDeclaredField("ticks");
            RING=Class.forName("com.pixelcite.turnbattle.SoulWalkClient$Ring").getDeclaredConstructor(int.class,long.class,int.class);
            RINGS.setAccessible(true);TICKS.setAccessible(true);RING.setAccessible(true);
        }catch(ReflectiveOperationException e){throw new ExceptionInInitializerError(e);}
    }
    @SuppressWarnings("unchecked") public static void show(MinecraftClient mc,int entityId,SoulType soul){
        if(mc.world==null)return;var entity=mc.world.getEntityById(entityId);if(entity==null)return;
        try{((List<Object>)RINGS.get(null)).add(RING.newInstance(entityId,TICKS.getLong(null),soul.getColor()&0xFFFFFF));}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot show Soulbound entry ring",e);}
        if(entity==mc.player)TurnBattleSounds.playClient(TurnBattleSounds.GRAZE,1,1);
        else mc.world.playSound(entity.getX(),entity.getY(),entity.getZ(),TurnBattleSounds.GRAZE,net.minecraft.sound.SoundCategory.PLAYERS,0.6f,1f,false);
    }
}
