package com.pixelcite.turnbattle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.*;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import java.util.*;

public final class PosClient implements ClientModInitializer {
    public record Appearance(UUID owner,String mob,UUID bodyId,net.minecraft.nbt.NbtCompound darknerLook) {
        public Appearance(UUID owner,String mob,UUID bodyId){this(owner,mob,bodyId,null);}
    }
    record Pull(long start,double x,double z,SoulType soul) {}
    public record Struggle(UUID occupant,long start,long end) {}
    public static final Map<UUID,Appearance> bodies=new HashMap<>();
    public static final Map<UUID,Struggle> struggles=new HashMap<>(); // original owner -> current occupant
    public static final Map<UUID,Pull> pulls=new HashMap<>();
    public static final Map<UUID,LivingEntity> models=new HashMap<>();
    static float twitch=1,pull=1;
    public static UUID renderingBody;
    static boolean substituting;
    @Override public void onInitializeClient(){
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(PosDummies.TYPE,PosDummyRenderer::new);
        Net121.registerClientReceiver(PosNet.BODY_WARNING,(client,handler,buf,sender)->client.execute(PosBodyWarning::show));
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(PosBodyWarning::tick);
        Net121.registerClientReceiver(PosSkillBalance.SYNC,(client,handler,buf,sender)->{
            boolean edit=buf.readBoolean();var values=PosSkillBalance.read(buf);
            client.execute(()->{PosSkillBalance.acceptClient(values,edit);if(client.currentScreen instanceof PosSkillBalanceScreen screen)screen.refresh();});
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h,c)->{PosSkillBalance.clearClient();PosTimedVisual.accept(Map.of());PosMobVision.reset();PosBodyWarning.reset();PosNativeSoulPose.clear();});
        Net121.registerClientReceiver(PosNet.STATE,(client,handler,buf,sender)->{
            float t=buf.readFloat(),p=buf.readFloat();Map<UUID,Appearance> map=new HashMap<>();
            int count=buf.readVarInt();for(int i=0;i<count;i++){UUID id=buf.readUuid();boolean human=buf.readBoolean();map.put(id,human?new Appearance(buf.readUuid(),null,null):new Appearance(null,buf.readString(256),buf.readUuid(),buf.readNbt()));}
            Map<UUID,Struggle> fights=new HashMap<>();count=buf.readVarInt();for(int i=0;i<count;i++)fights.put(buf.readUuid(),new Struggle(buf.readUuid(),buf.readLong(),buf.readLong()));
            Map<UUID,PosTimedVisual.Cue> cues=new HashMap<>();count=buf.readVarInt();for(int i=0;i<count;i++)cues.put(buf.readUuid(),new PosTimedVisual.Cue(SoulType.values()[buf.readVarInt()],buf.readVarInt(),buf.readLong(),buf.readLong()));
            client.execute(()->{PosTimedVisual.accept(cues);twitch=t;pull=p;bodies.clear();bodies.putAll(map);
                PosManager.CLIENT_BACKING.clear();PosManager.CLIENT_OCCUPIED_OWNERS.clear();
                for(Appearance a:map.values())if(a.owner()!=null)PosManager.CLIENT_OCCUPIED_OWNERS.add(a.owner());else PosManager.CLIENT_BACKING.add(a.bodyId());
                struggles.clear();struggles.putAll(fights);models.keySet().retainAll(map.keySet());});
        });
        Net121.registerClientReceiver(PosNet.ENTRY,(client,handler,buf,sender)->{
            int id=buf.readVarInt();SoulType soul=SoulType.values()[buf.readVarInt()];client.execute(()->PosEntryVisual.show(client,id,soul));
        });
        Net121.registerClientReceiver(PosNet.EFFECT,(client,handler,buf,sender)->{
            UUID body=buf.readUuid();double x=buf.readDouble(),z=buf.readDouble();SoulType soul=SoulType.values()[buf.readVarInt()];client.execute(()->{if(client.world!=null)pulls.put(body,new Pull(client.world.getTime(),x,z,soul));});
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h,c)->{bodies.clear();struggles.clear();pulls.clear();models.clear();appliedLooks.clear();PosNativeSoulPose.clear();PosManager.CLIENT_BACKING.clear();PosManager.CLIENT_OCCUPIED_OWNERS.clear();});
    }
    public static net.minecraft.client.util.SkinTextures skin(java.util.UUID owner){return MirrorCloneRenderer.MirrorFakePlayer.skinOf(owner);}
    public static UUID soulOf(Entity e){
        if(e instanceof MirrorCloneRenderer.MirrorFakePlayer p)return p.skinOwner;
        if(e instanceof MirrorCloneEntity m)return m.getOwner();
        return e.getUuid();
    }
    static UUID bodyOf(Entity e){
        if(e instanceof SoulBodyEntity b)return b.getOwner();
        UUID soul=soulOf(e);Appearance a=bodies.get(soul);return a==null?soul:(a.owner!=null?a.owner:a.bodyId);
    }
    public static boolean renderMob(Entity source,float yaw,float delta,MatrixStack matrices,VertexConsumerProvider vertices,int light){
        if(substituting||!(source instanceof LivingEntity living))return false;
        UUID soul=soulOf(source);Appearance a=bodies.get(soul);if(a==null||a.mob==null)return false;
        MinecraftClient mc=MinecraftClient.getInstance();if(mc.world==null)return false;
        LivingEntity proxy=models.get(soul);
        if(proxy==null||proxy.getWorld()!=mc.world||!Registries.ENTITY_TYPE.getId(proxy.getType()).toString().equals(a.mob)){
            Entity e=Registries.ENTITY_TYPE.get(Identifier.of(a.mob)).create(mc.world);
            if(!(e instanceof LivingEntity ll))return false;proxy=ll;proxy.setUuid(soul);models.put(soul,proxy);
        }
        applyMobLook(proxy,a.darknerLook());
        proxy.refreshPositionAndAngles(source.getX(),source.getY(),source.getZ(),source.getYaw(),source.getPitch());
        proxy.prevX=source.prevX;proxy.prevY=source.prevY;proxy.prevZ=source.prevZ;proxy.age=source.age;
        proxy.bodyYaw=living.bodyYaw;proxy.prevBodyYaw=living.prevBodyYaw;proxy.headYaw=living.headYaw;proxy.prevHeadYaw=living.prevHeadYaw;
        proxy.handSwingProgress=living.handSwingProgress;proxy.lastHandSwingProgress=living.lastHandSwingProgress;proxy.hurtTime=living.hurtTime;
        var from=(com.pixelcite.turnbattle.possession.mixin.PosLimbAccess)living.limbAnimator;
        var to=(com.pixelcite.turnbattle.possession.mixin.PosLimbAccess)proxy.limbAnimator;
        to.plus$previous(from.plus$previous());to.plus$speed(from.plus$speed());to.plus$position(from.plus$position());
        proxy.handSwinging=living.handSwinging;proxy.handSwingTicks=living.handSwingTicks;
        proxy.setVelocity(source.getVelocity());proxy.setOnGround(source.isOnGround());proxy.setPose(source.getPose());
        if(proxy instanceof net.minecraft.entity.mob.MobEntity mob)mob.setAttacking(living.handSwinging||living.isUsingItem());
        EntityRenderer<? super LivingEntity> renderer=mc.getEntityRenderDispatcher().getRenderer(proxy);
        boolean humanoid=renderer instanceof LivingEntityRenderer<?,?> r&&PosHumanoidModel.view(r.getModel())!=null;
        boolean combat=mc.currentScreen instanceof BattleScreen||LiveCombatClient.hudShown()||LiveCombatClient.moveLocked();
        CloneAnimator.Frame frame=combat?CloneAnimator.frame(soul,!living.getMainHandStack().isEmpty()):null;
        PlayerActions.ActFrame nativeAction=humanoid&&source instanceof net.minecraft.entity.player.PlayerEntity player?PlayerActions.frameFor(player):null;
        CloneAnimator.Pose renderPose=nativeAction!=null?nativeAction.pose():frame!=null?frame.pose:null;
        for(EquipmentSlot slot:EquipmentSlot.values()){
            ItemStack stack=humanoid?living.getEquippedStack(slot):ItemStack.EMPTY;
            if(humanoid&&slot==EquipmentSlot.MAINHAND){if(nativeAction!=null&&nativeAction.hand()!=null)stack=nativeAction.hand();else if(frame!=null&&frame.handOverride!=null)stack=frame.handOverride;}
            proxy.equipStack(slot,stack.copy());
        }
        matrices.push();
        if(renderPose!=null){matrices.translate(renderPose.dx()*0.012,-renderPose.dy()*0.012,0);matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(renderPose.tilt()));matrices.scale(renderPose.sx(),renderPose.sy(),1);}
        substituting=true;renderingBody=bodyOf(source);
        renderingPose=renderPose;renderingSource=living;renderingDelta=delta;
        try{renderer.render(proxy,yaw,delta,matrices,vertices,light);}finally{CloneAnimator.endModelPose();renderingPose=null;renderingSource=null;renderingBody=null;substituting=false;matrices.pop();}
        return true;
    }
    private static final Map<LivingEntity,net.minecraft.nbt.NbtCompound> appliedLooks=new WeakHashMap<>();
    public static void applyMobLook(LivingEntity proxy,net.minecraft.nbt.NbtCompound look){
        if(look==null||look.equals(appliedLooks.get(proxy)))return;
        var world=proxy.getWorld();
        if(look.contains("VariantData",10)){
            var data=proxy.writeNbt(new net.minecraft.nbt.NbtCompound());var variant=look.getCompound("VariantData");
            for(String key:variant.getKeys())data.put(key,variant.get(key).copy());
            proxy.readCustomDataFromNbt(data);
        }
        if(look.contains("BodyScale")){var scale=proxy.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_SCALE);if(scale!=null)scale.setBaseValue(look.getDouble("BodyScale"));}
        if(proxy instanceof DarknerEntity darkner){
            ItemStack item=look.contains("Item",10)?ItemStack.fromNbt(world.getRegistryManager(),look.getCompound("Item")).orElse(ItemStack.EMPTY):ItemStack.EMPTY;
            if(darkner.seed()!=look.getInt("Seed")||!ItemStack.areEqual(darkner.item(),item))darkner.setMakeup(item,look.getInt("Seed"));
        }
        appliedLooks.put(proxy,look.copy());
    }
    private static CloneAnimator.Pose renderingPose;
    private static LivingEntity renderingSource;
    private static float renderingDelta;
    private static final Map<net.minecraft.client.model.ModelPart,float[]> savedParts=new IdentityHashMap<>();
    private static final Map<net.minecraft.client.model.ModelPart,Boolean> savedVisibility=new IdentityHashMap<>();
    public static void saveVisibility(net.minecraft.client.model.ModelPart part){savedVisibility.putIfAbsent(part,part.visible);}
    static void savePart(net.minecraft.client.model.ModelPart part){savedParts.putIfAbsent(part,new float[]{part.pitch,part.yaw,part.roll,part.pivotX,part.pivotY,part.pivotZ});}
    public static void restoreParts(){for(var saved:savedVisibility.entrySet())saved.getKey().visible=saved.getValue();savedVisibility.clear();for(var e:savedParts.entrySet()){var p=e.getKey();var v=e.getValue();p.pitch=v[0];p.yaw=v[1];p.roll=v[2];p.pivotX=v[3];p.pivotY=v[4];p.pivotZ=v[5];}savedParts.clear();}
    private static double clock(LivingEntity e){return e.getWorld().getTime()+MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);}
    public static CloneAnimator.Pose extractionPose(LivingEntity e){
        var mc=MinecraftClient.getInstance();if(mc.currentScreen instanceof BattleScreen||LiveCombatClient.hudShown()||LiveCombatClient.moveLocked())return null;
        UUID body=renderingBody!=null?renderingBody:bodyOf(e);double now=clock(e),ticks=-1,fade=1;
        Struggle fight=struggles.get(body);
        if(fight!=null)ticks=PosStruggleMotion.struggleExtractionTicks(now,fight.start,fight.end);
        else{var cue=PosTimedVisual.cue(soulOf(e));if(cue!=null)ticks=PosStruggleMotion.extractionTicks(now,cue.started(),cue.expires());}
        Pull effect=pulls.get(body);
        if(effect!=null){double age=now-effect.start;if(age>=20)pulls.remove(body);else{ticks=60+Math.max(0,age)*0.2;fade=1-Math.clamp(age/20,0,1);}}
        if(ticks<0)return null;
        var pose=PosNativeSoulPose.pose((float)ticks);pose.armW*=fade;pose.headW*=fade;pose.tilt*=fade;pose.dx*=fade;pose.sy=(float)(1+(pose.sy-1)*fade);return pose;
    }
    public static void transformExtraction(LivingEntity e,MatrixStack matrices){
        var pose=extractionPose(e);if(pose==null)return;
        matrices.translate(pose.dx()*0.012,-pose.dy()*0.012,0);matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(pose.tilt()));matrices.scale(pose.sx(),pose.sy(),1);
    }
    private static PosStruggleMotion.Sample directional(LivingEntity e,UUID body){
        Struggle fight=struggles.get(body);if(fight==null)return new PosStruggleMotion.Sample(0,0,0,0);
        return PosStruggleMotion.sample(body,clock(e)-fight.start,fight.end-fight.start);
    }
    private static double[] pullVector(LivingEntity e,UUID body){
        var sample=directional(e,body);double x=sample.x()*twitch,z=sample.z()*twitch;
        Pull effect=pulls.get(body);
        if(effect!=null){
            double age=clock(e)-effect.start;if(age>=20)pulls.remove(body);
            else{double force=PosStruggleMotion.ejectionForce(age)*pull;
                double length=Math.hypot(effect.x,effect.z);if(length<0.001){x+=Math.sin(Math.toRadians(e.bodyYaw))*force;z+=Math.cos(Math.toRadians(e.bodyYaw))*force;}
                else{x+=effect.x/length*force;z+=effect.z/length*force;}}
        }
        double yaw=Math.toRadians(e.bodyYaw);return new double[]{x*Math.cos(yaw)-z*Math.sin(yaw),z*Math.cos(yaw)+x*Math.sin(yaw)};
    }
    public static void finishModelAngles(net.minecraft.client.render.entity.model.EntityModel<?> model,LivingEntity entity,float limbAngle,float limbDistance,float age,float headYaw,float headPitch){
        var biped=PosHumanoidModel.view(model);
        if(biped!=null){
            if(substituting&&renderingSource!=null)PosPlayerMotion.apply(biped,renderingSource,renderingDelta,limbAngle,limbDistance,age,headYaw,headPitch);
            animate(biped,entity);PosPlayerMotion.syncWear(biped);
            if(substituting||extractionPose(entity)!=null)PosHumanoidModel.separateArms(model,biped);
        }else animateNonHumanoid(model,entity);
    }
    public static void animateNonHumanoid(net.minecraft.client.render.entity.model.EntityModel<?> model,LivingEntity e){
        net.minecraft.client.model.ModelPart part=null;
        if(model instanceof net.minecraft.client.render.entity.model.SinglePartEntityModel<?> single)part=single.getChild("body").orElse(single.getPart());
        else if(model instanceof com.pixelcite.turnbattle.possession.mixin.PosAnimalAccess animal){var iterator=animal.possession$bodyParts().iterator();if(iterator.hasNext())part=iterator.next();}
        if(part==null)return;UUID body=renderingBody!=null?renderingBody:bodyOf(e);if(!struggles.containsKey(body)&&!pulls.containsKey(body))return;
        savePart(part);var v=pullVector(e,body);part.roll+=(float)v[0]*0.55f;part.pitch+=(float)v[1]*0.45f;part.pivotX+=(float)v[0]*2.5f;part.pivotZ-=(float)v[1]*2.5f;
    }
    public static void animate(BipedEntityModel<?> model,LivingEntity e){
        UUID body=renderingBody!=null?renderingBody:bodyOf(e);var nativePose=extractionPose(e);
        var resolvedPose=nativePose!=null?nativePose:renderingPose;
        if(!struggles.containsKey(body)&&!pulls.containsKey(body)&&resolvedPose==null)return;
        for(var part:new net.minecraft.client.model.ModelPart[]{model.body,model.head,model.hat,model.rightArm,model.leftArm,model.rightLeg,model.leftLeg})savePart(part);
        if(resolvedPose!=null)PosModelPose.apply(model,e,resolvedPose);
        if(renderingPose!=null)CloneAnimator.beginModelPose(e,renderingPose);
        var vector=pullVector(e,body);float x=(float)vector[0],z=(float)vector[1];
        model.body.pivotX+=x*3.5f;model.body.pivotZ-=z*3.2f;model.body.roll+=x*0.7f;model.body.pitch+=z*0.6f;
        model.head.pivotX+=x*2.8f;model.head.pivotZ-=z*2.6f;model.head.roll-=x*0.3f;model.head.pitch-=z*0.2f;
        // Keep the grasping arms stable; only the chest recoils at release.
        if(resolvedPose!=null){model.hat.copyTransform(model.head);return;}
        for(var arm:new net.minecraft.client.model.ModelPart[]{model.rightArm,model.leftArm}){arm.pivotX+=x*2.8f;arm.pivotZ-=z*2.6f;arm.roll+=x*0.65f;arm.pitch+=z*0.7f;}
        for(var leg:new net.minecraft.client.model.ModelPart[]{model.rightLeg,model.leftLeg}){leg.pivotX+=x*1.2f;leg.pivotZ-=z*1.1f;leg.roll+=x*0.5f;leg.pitch+=z*0.55f;}
        model.hat.copyTransform(model.head);
    }
}
