package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import java.util.List;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=BattleScreen.class,remap=false)
public abstract class PosSkillOrderBattleMixin {
    @Shadow private List<BattleSkill> availableSkills;
    @Shadow private PlayerClass playerClass,realPlayerClass;
    @Shadow private int actingRecruitCode(){throw new AssertionError();}
    @Inject(method="openSkillsMenu",at=@At("RETURN"))
    private void plus$battleOrder(CallbackInfo ci){
        // Card-deck battles encode choices by native index; normal battles encode stable skill IDs.
        if(playerClass!=null)availableSkills=PosSkillOrder.ordered(realPlayerClass==null?"self":PosSkillOrder.actor(actingRecruitCode()),availableSkills);
    }
}
