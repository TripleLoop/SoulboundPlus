package com.pixelcite.turnbattle;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import org.slf4j.LoggerFactory;

public final class PosConfig {
    public record Setting(String key,String label,String desc,ServerSettings.Kind kind,float min,float max,float step,float initial) {}
    public static final List<Setting> SETTINGS = List.of(
        bool("enabled","Possession Enabled","Enable the possession addon.",true),
        bool("players","Player Possession","Allow possession of other players' bodies.",true),
        bool("monsters","Monster Player Possession","Allow timed possession of Monster players regardless of level.",true),
        bool("mobs","Mob Possession","Allow non-passive, battle-eligible mobs; bosses are always excluded.",true),
        num("levelGap","Possession Level Threshold","At this level gap the weaker soul always loses.",1,1000,1,10),
        num("ownerBonus","Owner Equal-Level Win %","Owner's chance at equal level. Odds scale to the threshold.",50,99,1,55),
        num("cooldown","Possession Retry Seconds","Both contestants must wait before challenging this body again.",0,3600,1,30),
        num("struggle","Possession Struggle Seconds","Total clash duration; five pulls then a separate soul-removal gesture.",0.1f,60,0.1f,10),
        num("monsterBase","Monster Possession Seconds","Base possession time before absorbed-soul reduction.",1,3600,1,30),
        num("soulReduction","Seconds Lost per Absorbed Soul","Reduction to Monster possession duration per absorbed soul.",0,300,0.1f,1),
        num("minimum","Minimum Monster Seconds","Minimum possession time, even with many absorbed souls.",0.1f,3600,0.1f,2),
        bool("mobTimer","Mob Possession Timer","Optional time limit for ordinary mobs; off by default.",false),
        num("mobMultiplier","Mob Duration Multiplier","Mob duration = Monster base seconds multiplied by this value.",0.1f,100,0.1f,2),
        num("entryRadius","Soul Entry Radius","How close a soul must be to the target's chest.",0.2f,3,0.1f,0.6f),
        num("twitch","Struggle Pull Strength","Strength of chest-led limb pulls and physical body movement.",0,3,0.1f,1),
        num("chestPull","Ejection Chest Pull Strength","Visual torso pull and recoil when a soul leaves.",0,3,0.1f,1)
    );
    public static List<?> extendEntries(List<?> original){
        List<ServerSettings.Entry> entries=new ArrayList<>();
        for(Object e:original)entries.add((ServerSettings.Entry)e);
        for(Setting s:SETTINGS)entries.add(new ServerSettings.Entry("poss_"+s.key(),s.label(),s.desc(),s.kind(),s.min(),s.max(),s.step(),c->get(s.key()),(c,v)->set(s,v)));
        entries.add(new ServerSettings.Entry(PosSkillBalance.MENU_KEY,"Skill Balance — Open Editor","Configure each active skill on the server (operators only).",ServerSettings.Kind.BOOL,0,1,1,c->0f,(c,v)->{}));
        return List.copyOf(entries);
    }
    private static Setting bool(String k,String l,String d,boolean v){return new Setting(k,l,d,ServerSettings.Kind.BOOL,0,1,1,v?1:0);}
    private static Setting num(String k,String l,String d,float min,float max,float step,float v){return new Setting(k,l,d,step==1?ServerSettings.Kind.INT:ServerSettings.Kind.FLOAT,min,max,step,v);}
    private static final Map<String,Float> values = new HashMap<>();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("soulbound-possession.json");
    private static boolean loaded;
    public static synchronized void load(){
        if(loaded)return; loaded=true;
        for(Setting s:SETTINGS)values.put(s.key,s.initial);
        boolean migrate=false;
        if(Files.exists(FILE))try(Reader r=Files.newBufferedReader(FILE)){
            JsonObject o=JsonParser.parseReader(r).getAsJsonObject();
            for(Setting s:SETTINGS)if(o.has(s.key))setValue(s,o.get(s.key).getAsFloat());
            if(!o.has("_defaultsVersion")){
                if(values.get("cooldown")==15f)values.put("cooldown",30f);
                if(values.get("struggle")==3f)values.put("struggle",10f);
                migrate=true;
            }
        }catch(Exception e){LoggerFactory.getLogger("SoulboundPossession").error("Cannot load possession settings; using defaults",e);}
        if(migrate)try{save();}catch(UncheckedIOException e){LoggerFactory.getLogger("SoulboundPossession").error("Cannot save migrated possession defaults",e);}
    }
    public static float get(String key){load();return values.get(key);}
    public static boolean on(String key){return get(key)>=0.5f;}
    private static void setValue(Setting s,float v){if(Float.isFinite(v))values.put(s.key,Math.clamp(v,s.min,s.max));}
    public static synchronized void set(Setting s,float v){load();setValue(s,v);save();}
    private static void save(){
        try{Files.createDirectories(FILE.getParent());Path tmp=FILE.resolveSibling(FILE.getFileName()+".tmp");
            var data=new Gson().toJsonTree(values).getAsJsonObject();data.addProperty("_defaultsVersion",2);
            Files.writeString(tmp,new GsonBuilder().setPrettyPrinting().create().toJson(data));
            Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);
        }catch(IOException e){throw new UncheckedIOException("Cannot save possession settings",e);}
    }
}
