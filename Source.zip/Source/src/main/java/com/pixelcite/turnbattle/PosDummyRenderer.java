package com.pixelcite.turnbattle;
import net.minecraft.client.render.entity.*;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.util.Identifier;

public final class PosDummyRenderer extends BipedEntityRenderer<PosDummyEntity,BipedEntityModel<PosDummyEntity>> {
    public PosDummyRenderer(EntityRendererFactory.Context ctx){super(ctx,new BipedEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER)),0.5f);}
    @Override public Identifier getTexture(PosDummyEntity entity){return Identifier.ofVanilla("textures/entity/player/wide/steve.png");}
    @Override public void render(PosDummyEntity entity,float yaw,float delta,net.minecraft.client.util.math.MatrixStack matrices,net.minecraft.client.render.VertexConsumerProvider vertices,int light){
        super.render(entity,yaw,delta,matrices,vertices,light);
        // A won dummy displays the controller's own soul through the normal possession cues.
        if(entity.isInvisible()||entity.soul()==null||PosClient.bodies.containsKey(entity.getUuid()))return;
        var item=TurnBattleMod.SOUL_ITEMS.get(entity.soul());if(item==null)return;
        matrices.push();
        matrices.translate(0,1.15,0);matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(180-yaw));matrices.translate(0,0,0.34);matrices.scale(0.3f,0.3f,0.3f);
        net.minecraft.client.MinecraftClient.getInstance().getItemRenderer().renderItem(new net.minecraft.item.ItemStack(item),net.minecraft.client.render.model.json.ModelTransformationMode.FIXED,15728880,net.minecraft.client.render.OverlayTexture.DEFAULT_UV,matrices,vertices,entity.getWorld(),entity.getId());
        matrices.pop();
    }
}
