package com.pixelcite.turnbattle;
import net.minecraft.nbt.*;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.registry.*;
import net.minecraft.util.*;
import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import org.slf4j.LoggerFactory;

/** Recovery snapshots are separate from player saves; clean shutdown fully unwinds possession. */
final class PosJournal {
    private static final Map<UUID,NbtCompound> recovery=new HashMap<>();
    private static final Map<UUID,NbtCompound> mobRecovery=new HashMap<>();
    private static MinecraftServer loaded;
    private static Path file(MinecraftServer s){return s.getSavePath(WorldSavePath.ROOT).resolve("soulbound-possession.dat");}
    static void load(MinecraftServer s){
        if(loaded==s)return;loaded=s;recovery.clear();mobRecovery.clear();PosBodyGear.kept.clear();
        try{if(Files.exists(file(s))){NbtCompound root=NbtIo.readCompressed(file(s),NbtSizeTracker.ofUnlimitedBytes());NbtList list=root.getList("Bodies",10);for(int i=0;i<list.size();i++){NbtCompound c=list.getCompound(i);recovery.put(c.getUuid("Owner"),c);}NbtList mobs=root.getList("Mobs",10);for(int i=0;i<mobs.size();i++){NbtCompound c=mobs.getCompound(i);mobRecovery.put(c.getUuid("Id"),c);}NbtList kept=root.getList("KeptAccessories",10);for(int i=0;i<kept.size();i++){NbtCompound c=kept.getCompound(i);PosBodyGear.kept.put(c.getUuid("Owner"),c.getCompound("Accessories"));}}}
        catch(Exception e){throw new IllegalStateException("Cannot read possession recovery journal",e);}
    }
    static void save(MinecraftServer s){
        load(s);NbtList list=new NbtList();Set<UUID> current=new HashSet<>();
        for(PosManager.Anchor a:PosManager.anchors.values()){
            current.add(a.owner);NbtCompound c=new NbtCompound();c.putUuid("Owner",a.owner);c.putString("Dimension",a.out.dim.getValue().toString());
            c.putDouble("X",a.out.pos.x);c.putDouble("Y",a.out.pos.y);c.putDouble("Z",a.out.pos.z);c.putFloat("Yaw",a.out.yaw);c.putFloat("Pitch",a.out.pitch);c.putInt("Selected",a.selected);
            NbtList items=new NbtList();for(int i=0;i<a.items.size();i++){ItemStack stack=a.items.get(i);if(stack.isEmpty())continue;NbtCompound it=new NbtCompound();it.putInt("Slot",i);it.put("Stack",stack.encode(s.getRegistryManager()));items.add(it);}c.put("Items",items);
            c.put("Accessories",PosBodyGear.snapshot(s,a));c.put("SoulBackpacks",PosBodyGear.leased(s,a));
            PosManager.Session guest=PosManager.occupant(a.owner);if(guest!=null)c.putUuid("Occupant",guest.soul);
            list.add(c);
        }
        for(var e:recovery.entrySet())if(!current.contains(e.getKey()))list.add(e.getValue().copy());
        NbtList mobs=new NbtList();Set<UUID> activeMobs=new HashSet<>();
        for(PosManager.Session ss:PosManager.sessions.values())if(ss.mob!=null){
            activeMobs.add(ss.body);NbtCompound c=new NbtCompound();c.putUuid("Id",ss.body);c.putBoolean("NoAI",ss.oldAi);c.putBoolean("Invisible",ss.oldInvisible);c.putBoolean("Invulnerable",ss.oldInvulnerable);ServerPlayerEntity controller=s.getPlayerManager().getPlayer(ss.soul);c.put("Accessories",controller!=null?PosAccessories.capture(controller,false):ss.accessories.copy());mobs.add(c);
        }
        for(var e:mobRecovery.entrySet())if(!activeMobs.contains(e.getKey()))mobs.add(e.getValue().copy());
        NbtCompound root=new NbtCompound();root.putInt("Version",2);root.put("Bodies",list);root.put("Mobs",mobs);NbtList kept=new NbtList();for(var entry:PosBodyGear.kept.entrySet()){NbtCompound c=new NbtCompound();c.putUuid("Owner",entry.getKey());c.put("Accessories",entry.getValue().copy());kept.add(c);}root.put("KeptAccessories",kept);
        try{Path f=file(s),tmp=f.resolveSibling(f.getFileName()+".tmp");NbtIo.writeCompressed(root,tmp);Files.move(tmp,f,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
        catch(IOException e){throw new UncheckedIOException("Cannot write possession recovery journal",e);}
    }
    static void entityLoaded(net.minecraft.entity.Entity entity,ServerWorld world){
        load(world.getServer());NbtCompound c=mobRecovery.get(entity.getUuid());
        if(c!=null&&entity instanceof net.minecraft.entity.mob.MobEntity m){m.setAiDisabled(c.getBoolean("NoAI"));m.setInvisible(c.getBoolean("Invisible"));m.setInvulnerable(c.getBoolean("Invulnerable"));if(c.contains("Accessories",10)){if(PosAccessories.canApply(m,c.getCompound("Accessories")))PosAccessories.apply(m,c.getCompound("Accessories"));else for(ItemStack stack:PosAccessories.stacks(c.getCompound("Accessories"),world.getRegistryManager()))m.dropStack(stack);}mobRecovery.remove(entity.getUuid());save(world.getServer());}
    }
    static void recover(ServerPlayerEntity p){
        MinecraftServer s=p.getServer();load(s);NbtCompound c=recovery.get(p.getUuid());if(c==null)return;
        if(c.contains("Accessories",10)&&!PosAccessories.canApply(p,c.getCompound("Accessories")))throw new IllegalStateException("Cannot recover body accessories: restore the required Curios/Trinkets mods and slot definitions");
        // Decode before changing the player so removed mods cannot silently erase a stored backpack.
        NbtList validate=c.getList("Items",10);for(int i=0;i<validate.size();i++)ItemStack.fromNbt(s.getRegistryManager(),validate.getCompound(i).getCompound("Stack")).orElseThrow(()->new IllegalStateException("A stored body item requires a missing mod"));
        NbtList loans=c.getList("SoulBackpacks",10);for(int i=0;i<loans.size();i++)ItemStack.fromNbt(s.getRegistryManager(),loans.getCompound(i).getCompound("Stack")).orElseThrow(()->new IllegalStateException("A stored backpack requires a missing mod"));
        PosBodyGear.close(p);
        p.getInventory().clear();NbtList list=c.getList("Items",10);for(int i=0;i<list.size();i++){NbtCompound it=list.getCompound(i);int slot=it.getInt("Slot");if(slot>=0&&slot<41)p.getInventory().setStack(slot,ItemStack.fromNbt(s.getRegistryManager(),it.getCompound("Stack")).orElse(ItemStack.EMPTY));}
        if(c.contains("Accessories",10))PosAccessories.apply(p,c.getCompound("Accessories"));
        p.getInventory().selectedSlot=Math.clamp(c.getInt("Selected"),0,8);
        ServerWorld w=s.getWorld(RegistryKey.of(RegistryKeys.WORLD,Identifier.of(c.getString("Dimension"))));
        if(w!=null)p.teleport(w,c.getDouble("X"),c.getDouble("Y"),c.getDouble("Z"),c.getFloat("Yaw"),c.getFloat("Pitch"));
        PosBodyGear.restoreLeased(p,c.getList("SoulBackpacks",10));recovery.remove(p.getUuid());
        BattleData.get(s).getOrCreate(p.getUuid()).soulOutDim=null;BattleData.get(s).markDirty();
        save(s);
    }
}
