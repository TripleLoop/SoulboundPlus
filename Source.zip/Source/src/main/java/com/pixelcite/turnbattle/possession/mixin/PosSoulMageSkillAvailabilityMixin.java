package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=SoulMageSkill.class,remap=false)
public abstract class PosSoulMageSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILcom/pixelcite/turnbattle/SoulType;Ljava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/SoulMageSkill;lr:I"))
    private static int plus$level(SoulMageSkill skill){return skill.getLevelRequired();}
}
