package com.pixelcite.turnbattle;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.mob.MobEntity;
/** Reflection is confined to private members of the pinned Soulbound version, never Minecraft names. */
final class PosBridge {
    private static final Field OUT;
    private static final Method SPAWN,RESTORE,BOSS;
    static{
        try{
            OUT=SoulWalk.class.getDeclaredField("OUT");OUT.setAccessible(true);
            SPAWN=SoulWalk.class.getDeclaredMethod("spawnBody",ServerPlayerEntity.class,SoulWalk.Out.class);SPAWN.setAccessible(true);
            RESTORE=SoulWalk.class.getDeclaredMethod("restoreAbilities",ServerPlayerEntity.class);RESTORE.setAccessible(true);
            BOSS=EliteMobManager.class.getDeclaredMethod("isBossType",MobEntity.class);BOSS.setAccessible(true);
        }catch(ReflectiveOperationException e){throw new ExceptionInInitializerError(e);}
    }
    @SuppressWarnings("unchecked") static Map<UUID,SoulWalk.Out> out(){try{return (Map<UUID,SoulWalk.Out>)OUT.get(null);}catch(IllegalAccessException e){throw new IllegalStateException(e);}}
    static void sync(MinecraftServer s){SoulWalk.sync(s);}
    static void spawn(ServerPlayerEntity p,SoulWalk.Out o){invoke(SPAWN,p,o);}
    static void restore(ServerPlayerEntity p){invoke(RESTORE,p);}
    static boolean boss(MobEntity mob){return (boolean)invoke(BOSS,mob);}
    private static Object invoke(Method m,Object...args){try{return m.invoke(null,args);}catch(ReflectiveOperationException e){throw new IllegalStateException("Soulbound 2.0.21 integration failed: "+m.getName(),e);}}
}
