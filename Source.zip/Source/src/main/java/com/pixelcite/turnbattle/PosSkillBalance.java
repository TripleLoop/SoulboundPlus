package com.pixelcite.turnbattle;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import java.nio.file.*;
import java.util.*;

/** Server-owned overrides. The client copy is only used outside the server thread. */
public final class PosSkillBalance {
    public static final String MENU_KEY="skill_balance_menu";
    public static final Identifier REQUEST=Identifier.of("soulbound_possession","skills_request"), SET=Identifier.of("soulbound_possession","skills_set"), SYNC=Identifier.of("soulbound_possession","skills_sync");
    public record Definition(String id,String label,String family,BattleSkill skill,int[] defaults) {}
    private static final ThreadLocal<Boolean> RAW=ThreadLocal.withInitial(()->false);
    private static volatile Map<String,int[]> serverValues=Map.of(),clientValues=Map.of();
    private static volatile MinecraftServer server;
    private static volatile boolean clientSynced;
    public static volatile boolean clientCanEdit;
    private static List<Definition> catalogue;
    private static Map<String,Definition> byId;
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("soulbound-plus-skills.json");
    public static String id(BattleSkill skill){return skill.getClass().getSimpleName()+"/"+(skill instanceof Enum<?> e?e.name():"INSTANCE");}
    public static synchronized List<Definition> catalogue(){
        if(catalogue!=null)return catalogue;
        List<BattleSkill> all=new ArrayList<>();
        Collections.addAll(all,PsiSkill.values());Collections.addAll(all,LightnerSkill.values());
        Collections.addAll(all,HumanMageSkill.values());Collections.addAll(all,MonsterSkill.values());
        Collections.addAll(all,SoulMageSkill.values());Collections.addAll(all,OriSkill.values());
        Collections.addAll(all,VesselActionSkill.values());all.add(ActionSkill.INSTANCE);
        List<Definition> defs=new ArrayList<>();Map<String,Definition> ids=new LinkedHashMap<>();
        RAW.set(true);try{for(BattleSkill s:all){String family=s.getClass().getSimpleName().replace("Skill","");
            Definition d=new Definition(id(s),s instanceof VesselActionSkill||s instanceof ActionSkill?"Vessel Action":s.getDisplayName(),family,s,new int[]{1,s.getTpCost(),s.getLevelRequired(),s.getMinVal(),s.getMaxVal(),s.getExtra()});
            defs.add(d);ids.put(d.id,d);
        }}finally{RAW.remove();}
        byId=Collections.unmodifiableMap(ids);catalogue=List.copyOf(defs);return catalogue;
    }
    public static int value(BattleSkill skill,int field,int original){
        if(field==0)return 1;
        if(RAW.get())return original;
        MinecraftServer s=server;
        Map<String,int[]> values=(s!=null&&s.isOnThread())||!clientSynced?serverValues:clientValues;
        int[] v=values.get(id(skill));return v==null?original:v[field];
    }
    public static boolean enabled(BattleSkill s){return true;}
    public static int[] clientValue(Definition d){return clientValues.getOrDefault(d.id,d.defaults).clone();}
    public static void clearClient(){clientValues=Map.of();clientSynced=false;clientCanEdit=false;}
    public static void acceptClient(Map<String,int[]> values,boolean edit){clientValues=Map.copyOf(values);clientSynced=true;clientCanEdit=edit;}
    public static Map<String,int[]> read(PacketByteBuf b){
        int n=b.readVarInt();if(n<0||n>catalogue().size())throw new IllegalArgumentException("Invalid skill count");
        Map<String,int[]> values=new HashMap<>();for(int i=0;i<n;i++){String id=b.readString(160);int[] v=new int[6];for(int f=0;f<6;f++)v[f]=b.readVarInt();if(byId.containsKey(id)&&valid(v)){v[0]=1;values.put(id,v);}}return values;
    }
    public static boolean valid(int[] v){if(v.length!=6||v[0]<0||v[0]>1||v[1]<0||v[1]>10000||v[2]<1||v[2]>10000)return false;return v[3]>=0&&v[3]<=100000&&v[4]>=0&&v[4]<=100000&&v[5]>=0&&v[5]<=10000;}
    public static void register(){
        catalogue();Net121.registerC2SChannel(REQUEST);Net121.registerC2SChannel(SET);Net121.registerS2CChannel(SYNC);
        Net121.registerServerReceiver(REQUEST,(s,p,h,b,sender)->s.execute(()->sync(p)));
        Net121.registerServerReceiver(SET,(s,p,h,b,sender)->{String id=b.readString(160);boolean reset=b.readBoolean();int[] v=new int[6];if(!reset)for(int i=0;i<6;i++)v[i]=b.readVarInt();
            s.execute(()->{if(!ServerSettings.canEdit(p)||!byId.containsKey(id)||(!reset&&!valid(v))){sync(p);return;}
                v[0]=1;Map<String,int[]> next=new HashMap<>(serverValues);if(reset||Arrays.equals(v,byId.get(id).defaults))next.remove(id);else next.put(id,v.clone());
                if(!save(next)){sync(p);return;}serverValues=Map.copyOf(next);
                for(ServerPlayerEntity player:s.getPlayerManager().getPlayerList())sync(player);
            });});
        ServerLifecycleEvents.SERVER_STARTING.register(s->{server=s;load();});
        ServerLifecycleEvents.SERVER_STOPPED.register(s->{server=null;serverValues=Map.of();});
        ServerPlayConnectionEvents.JOIN.register((h,s,sender)->sync(h.player));
    }
    private static void load(){
        Map<String,int[]> loaded=new HashMap<>();if(Files.exists(FILE))try(var r=Files.newBufferedReader(FILE)){
            JsonObject root=JsonParser.parseReader(r).getAsJsonObject();for(var entry:root.entrySet())if(byId.containsKey(entry.getKey())){int[] v=new Gson().fromJson(entry.getValue(),int[].class);if(valid(v)){v[0]=1;loaded.put(entry.getKey(),v);}}
        }catch(Exception e){org.slf4j.LoggerFactory.getLogger("SoulBound+").error("Cannot load skill settings",e);}serverValues=Map.copyOf(loaded);
    }
    private static boolean save(Map<String,int[]> values){try{Files.createDirectories(FILE.getParent());Path tmp=FILE.resolveSibling(FILE.getFileName()+".tmp");Files.writeString(tmp,new GsonBuilder().setPrettyPrinting().create().toJson(values));
        try{Files.move(tmp,FILE,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING);}return true;
    }catch(Exception e){org.slf4j.LoggerFactory.getLogger("SoulBound+").error("Cannot save skill settings",e);return false;}}
    private static void sync(ServerPlayerEntity p){PacketByteBuf b=PacketByteBufs.create();b.writeBoolean(ServerSettings.canEdit(p));b.writeVarInt(serverValues.size());for(var e:serverValues.entrySet()){b.writeString(e.getKey(),160);for(int v:e.getValue())b.writeVarInt(v);}Net121.sendToClient(p,SYNC,b);}
    public static void request(){Net121.sendToServer(REQUEST,PacketByteBufs.create());}
    public static void update(String id,int[] v,boolean reset){PacketByteBuf b=PacketByteBufs.create();b.writeString(id,160);b.writeBoolean(reset);if(!reset)for(int x:v)b.writeVarInt(x);Net121.sendToServer(SET,b);}
}
