package com.pixelcite.turnbattle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import java.util.*;

public final class PosSkillBalanceScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget search;
    private final TextFieldWidget[] fields=new TextFieldWidget[5];
    private final List<ButtonWidget> skills=new ArrayList<>();
    private List<PosSkillBalance.Definition> filtered=List.of();
    private PosSkillBalance.Definition selected;
    private int page;
    private ButtonWidget apply,reset,prev,next;
    private String query="",message="";
    public PosSkillBalanceScreen(Screen parent){super(Text.literal("SoulBound+ — Skill Balance"));this.parent=parent;}
    public static boolean launcher(Object row){
        try{var method=row.getClass().getDeclaredMethod("label");method.setAccessible(true);return "Skill Balance — Open Editor".equals(method.invoke(row));}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot identify Soulbound settings row",e);}
    }
    public static void open(){MinecraftClient mc=MinecraftClient.getInstance();mc.setScreen(new PosSkillBalanceScreen(mc.currentScreen));PosSkillBalance.request();}
    public static boolean open(Object remote){if(!((SettingsScreen.Remote)remote).key.equals(PosSkillBalance.MENU_KEY))return false;MinecraftClient mc=MinecraftClient.getInstance();mc.setScreen(new PosSkillBalanceScreen(mc.currentScreen));PosSkillBalance.request();return true;}
    @Override protected void init(){
        int half=width/2;
        search=addDrawableChild(new TextFieldWidget(textRenderer,12,31,half-24,20,Text.literal("Search skills")));
        search.setPlaceholder(Text.literal("Search name or skill family"));search.setMaxLength(100);search.setText(query);search.setChangedListener(q->{query=q;page=0;filter();});
        int rows=Math.max(1,(height-117)/22);
        skills.clear();for(int i=0;i<rows;i++){final int row=i;skills.add(addDrawableChild(ButtonWidget.builder(Text.empty(),b->{int n=page*skills.size()+row;if(n<filtered.size())select(filtered.get(n));}).dimensions(12,57+i*22,half-24,20).build()));}
        prev=addDrawableChild(ButtonWidget.builder(Text.literal("<"),b->{page--;fillList();}).dimensions(12,height-52,35,20).build());
        next=addDrawableChild(ButtonWidget.builder(Text.literal(">"),b->{page++;fillList();}).dimensions(half-47,height-52,35,20).build());
        for(int i=0;i<5;i++){fields[i]=addDrawableChild(new TextFieldWidget(textRenderer,width-81,72+i*20,69,18,Text.literal("Skill value")));fields[i].setMaxLength(6);}
        apply=addDrawableChild(ButtonWidget.builder(Text.literal("Apply"),b->apply()).dimensions(half+8,height-52,(half-24)/2,20).build());
        reset=addDrawableChild(ButtonWidget.builder(Text.literal("Reset"),b->{if(selected!=null){PosSkillBalance.update(selected.id(),new int[6],true);message="Reset requested";}}).dimensions(half+12+(half-24)/2,height-52,(half-24)/2,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(width/2-40,height-25,80,20).build());
        filter();if(selected==null&&!filtered.isEmpty())selected=filtered.getFirst();refresh();
    }
    private void filter(){String q=query.toLowerCase(Locale.ROOT);filtered=PosSkillBalance.catalogue().stream().filter(d->(d.label()+" "+d.family()+" "+d.id()).toLowerCase(Locale.ROOT).contains(q)).toList();fillList();}
    private void fillList(){if(skills.isEmpty())return;page=Math.clamp(page,0,Math.max(0,(filtered.size()-1)/skills.size()));for(int i=0;i<skills.size();i++){int n=page*skills.size()+i;ButtonWidget b=skills.get(i);b.visible=n<filtered.size();if(b.visible){var d=filtered.get(n);b.setMessage(Text.literal(textRenderer.trimToWidth(d.family()+": "+d.label(),b.getWidth()-10)));}}if(prev!=null){prev.active=page>0;next.active=(page+1)*skills.size()<filtered.size();}}
    private void select(PosSkillBalance.Definition d){selected=d;message="";refresh();}
    public void refresh(){if(apply==null)return;boolean edit=PosSkillBalance.clientCanEdit&&selected!=null;apply.active=reset.active=edit;for(var f:fields)f.setEditable(edit);if(selected==null)return;int[] v=PosSkillBalance.clientValue(selected);for(int i=0;i<5;i++)fields[i].setText(Integer.toString(v[i+1]));}
    private void apply(){if(selected==null)return;try{int[] v=new int[6];v[0]=1;for(int i=0;i<5;i++)v[i+1]=Integer.parseInt(fields[i].getText());if(!PosSkillBalance.valid(v))throw new NumberFormatException();PosSkillBalance.update(selected.id(),v,false);message="Change requested";}catch(NumberFormatException e){message="Invalid value; check the allowed ranges.";}}
    private String[] labels(){if(selected==null)return new String[]{"TP cost","Required LV","Minimum","Maximum","Extra"};return switch(selected.skill().getType()){
        case SHIELD->new String[]{"TP cost","Required LV","Reduction %","Turns","Extra"};
        case BUFF,WEAKEN->new String[]{"TP cost","Required LV","Turns","Secondary","Strength %"};
        case CONFUSE->new String[]{"TP cost","Required LV","Turns","Secondary","Extra"};
        default->new String[]{"TP cost","Required LV","Base minimum","Base maximum","Extra"};};}
    @Override public void render(DrawContext c,int mx,int my,float delta){
        renderBackground(c,mx,my,delta);super.render(c,mx,my,delta);
        c.drawCenteredTextWithShadow(textRenderer,title,width/2,9,0xFFFFFF);
        int half=width/2;String heading=selected==null?"Select a skill":selected.label();c.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(heading,half-20),half+8,34,0xFFFF88);
        String[] labels=labels();for(int i=0;i<5;i++)c.drawTextWithShadow(textRenderer,textRenderer.trimToWidth(labels[i],Math.max(1,half-96)),half+8,77+i*20,0xDDDDDD);
        c.drawTextWithShadow(textRenderer,(page+1)+" / "+Math.max(1,(filtered.size()+skills.size()-1)/skills.size()),53,height-46,0xAAAAAA);
        String note=!PosSkillBalance.clientCanEdit?"Server operator access required.":message.isEmpty()?"TP 0–10000; LV 1–10000; base 0–100000; extra 0–10000":message;
        c.drawCenteredTextWithShadow(textRenderer,textRenderer.trimToWidth(note,width-16),width/2,height-65,0xAAAAAA);
        if(selected!=null&&my>=72&&my<172&&mx>half&&mx<width-82){int i=(my-72)/20;String tip=switch(i){case 0->"TP spent per use (native accessory modifiers still apply).";case 1->"Required level for learning/using this skill.";case 2,3->"Native base parameter; meaning depends on skill type. 999 can mean full heal.";default->"Native extra: turns, hits, strength or chance; some skills ignore it.";};c.drawTooltip(textRenderer,Text.literal(tip),mx,my);}
    }
    @Override public void close(){client.setScreen(parent);}
    @Override public boolean shouldPause(){return false;}
}
