package com.pixelcite.turnbattle.possession.mixin;

import com.pixelcite.turnbattle.*;
import net.minecraft.client.gui.DrawContext;
import java.util.List;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(value=StatsScreen.class,remap=false)
public abstract class PosSkillOrderStatsMixin extends VoidMenuScreen {
    protected PosSkillOrderStatsMixin(){super("",null);}
    @Shadow private int skillTop;
    @Unique private final PosSkillDrag plus$drag=new PosSkillDrag();
    @Unique private List<BattleSkill> plus$skills=List.of();
    @Inject(method="equippedSkills",at=@At("RETURN"),cancellable=true)
    private void plus$ordered(@Coerce Object member,CallbackInfoReturnable<List<BattleSkill>> cir){
        plus$skills=PosSkillOrder.menu(member,cir.getReturnValue());cir.setReturnValue(plus$skills);
    }
    @ModifyArg(method="renderSkillsAndEquip",at=@At(value="INVOKE",target="Lcom/pixelcite/turnbattle/StatsScreen;fit(Ljava/lang/String;I)Ljava/lang/String;"),index=1)
    private int plus$handleRoom(int width){return Math.max(1,width-16);}
    @Inject(method="renderSkillsAndEquip",at=@At("TAIL"))
    private void plus$handles(DrawContext ctx,@Coerce Object member,int x,int y,int width,int height,int mx,int my,float alpha,int scale,CallbackInfo ci){
        skillTop=plus$drag.render(ctx,member,plus$skills,x,y,width,height,scale,skillTop,mx,my,alpha);
    }
    @Override public boolean mouseClicked(double x,double y,int button){return plus$drag.click(x,y,button)||super.mouseClicked(x,y,button);}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){return plus$drag.drag(y,button)||super.mouseDragged(x,y,button,dx,dy);}
    @Override public boolean mouseReleased(double x,double y,int button){return plus$drag.release(y,button)||super.mouseReleased(x,y,button);}
    @Override public boolean keyPressed(int key,int scan,int modifiers){if(plus$drag.dragging()){if(key==256)plus$drag.cancel();return true;}return super.keyPressed(key,scan,modifiers);}
    @Override public void removed(){plus$drag.cancel();super.removed();}
}
