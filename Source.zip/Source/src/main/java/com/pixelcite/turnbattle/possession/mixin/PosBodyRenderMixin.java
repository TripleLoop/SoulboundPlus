package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=SoulBodyRenderer.class,remap=false)
public abstract class PosBodyRenderMixin {
    @Inject(method="render(Lcom/pixelcite/turnbattle/SoulBodyEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At("HEAD"),cancellable=true,remap=true)
    private void possession$hide(SoulBodyEntity e,float yaw,float delta,MatrixStack m,VertexConsumerProvider v,int light,CallbackInfo ci){if(e.isInvisible())ci.cancel();else PosClient.renderingBody=e.getOwner();}
    @Inject(method="render(Lcom/pixelcite/turnbattle/SoulBodyEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At("RETURN"),remap=true)
    private void possession$end(SoulBodyEntity e,float yaw,float delta,MatrixStack m,VertexConsumerProvider v,int light,CallbackInfo ci){PosClient.renderingBody=null;}
}
