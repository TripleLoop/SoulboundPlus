package com.pixelcite.turnbattle;
import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/** Ballet weapon follows the feet, including native combat leg animations. */
public final class PosShoes {
    private static final Identifier ITEM=Identifier.of("turnbattle","ballet_shoes"),TEXTURE=Identifier.ofVanilla("textures/block/white_concrete.png");
    private static final ModelPart SHOE=build();
    private PosShoes() {}
    public static boolean matches(ItemStack stack){return !stack.isEmpty()&&Registries.ITEM.getId(stack.getItem()).equals(ITEM);}
    public static boolean equipped(LivingEntity entity){return PosGloves.equipped(entity,ITEM);}
    private static ModelPart build(){
        var data=new ModelData();var root=data.getRoot();
        root.addChild("sole",ModelPartBuilder.create().uv(0,0).cuboid(-2.2f,11.5f,-2.9f,4.4f,0.7f,5.2f),ModelTransform.NONE);
        root.addChild("upper",ModelPartBuilder.create().uv(0,0).cuboid(-2.15f,10.15f,-2.85f,4.3f,1.4f,5.1f),ModelTransform.NONE);
        root.addChild("ribbon",ModelPartBuilder.create().uv(0,0).cuboid(-2.2f,8.7f,-2.2f,4.4f,0.7f,4.4f).cuboid(-0.55f,9.2f,-2.95f,1.1f,1.4f,0.25f),ModelTransform.NONE);
        root.addChild("bow",ModelPartBuilder.create().uv(0,0).cuboid(-1.5f,9.7f,-2.1f,3,0.55f,1.3f),ModelTransform.NONE);
        return TexturedModelData.of(data,32,16).createModel();
    }
    public static void renderBoth(BipedEntityModel<?> model,LivingEntity entity,MatrixStack matrices,VertexConsumerProvider vertices,int light){
        if(entity.isInvisible())return;
        for(var leg:new ModelPart[]{model.leftLeg,model.rightLeg}){if(!leg.visible)continue;matrices.push();leg.rotate(matrices);
            var consumer=vertices.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));int overlay=net.minecraft.client.render.entity.LivingEntityRenderer.getOverlay(entity,0);
            SHOE.getChild("sole").render(matrices,consumer,light,overlay,0xFF706080);
            SHOE.getChild("upper").render(matrices,consumer,light,overlay,0xFFF1DCC4);
            SHOE.getChild("ribbon").render(matrices,consumer,light,overlay,0xFFAC91BF);
            SHOE.getChild("bow").render(matrices,consumer,light,overlay,0xFFDDC5D8);matrices.pop();
        }
    }
}
