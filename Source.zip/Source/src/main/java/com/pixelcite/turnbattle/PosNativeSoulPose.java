package com.pixelcite.turnbattle;
import java.lang.reflect.*;
import java.util.UUID;

/** Calls the pinned mod's real soul-removal pose without starting its camera/input action. */
public final class PosNativeSoulPose {
    private static final Constructor<?> ACT;
    private static final Method POSE;
    private static final Object SOUL;
    private static final Field ACTS,KIND;
    private static Object action,world;
    static{
        try{
            Class<?> kind=Class.forName("com.pixelcite.turnbattle.PlayerActions$Kind"),act=Class.forName("com.pixelcite.turnbattle.PlayerActions$Act");
            var field=kind.getField("SOUL");field.setAccessible(true);SOUL=field.get(null);ACT=act.getDeclaredConstructor(kind,UUID.class,float.class);ACT.setAccessible(true);
            ACTS=PlayerActions.class.getDeclaredField("acts");KIND=act.getDeclaredField("kind");ACTS.setAccessible(true);KIND.setAccessible(true);
            POSE=PlayerActions.class.getDeclaredMethod("poseSoul",CloneAnimator.Pose.class,act,float.class);POSE.setAccessible(true);
        }catch(ReflectiveOperationException e){throw new ExceptionInInitializerError(e);}
    }
    public static CloneAnimator.Pose pose(float ticks){
        try{
            Object next=net.minecraft.client.MinecraftClient.getInstance().world;
            if(action==null||world!=next){world=next;action=ACT.newInstance(SOUL,new UUID(0,0),0f);}
            var pose=new CloneAnimator.Pose();POSE.invoke(null,pose,action,ticks);return pose;
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot apply Soulbound soul-removal animation",e);}
    }
    public static boolean soulAction(UUID who){
        if(who==null)return false;
        try{var current=((java.util.Map<?,?>)ACTS.get(null)).get(who);return current!=null&&KIND.get(current)==SOUL;}
        catch(IllegalAccessException e){throw new IllegalStateException("Cannot identify native soul extraction",e);}
    }
    public static boolean localSoulAction(){var mc=net.minecraft.client.MinecraftClient.getInstance();return mc!=null&&mc.player!=null&&soulAction(mc.player.getUuid());}
    public static void clear(){world=null;action=null;}
}
