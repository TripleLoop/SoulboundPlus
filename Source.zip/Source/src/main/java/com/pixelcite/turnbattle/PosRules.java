package com.pixelcite.turnbattle;

/** Pure rules shared with tests. Original ownership does not change after possession. */
public final class PosRules {
    private PosRules() {}
    public static double invaderChance(int invader, int owner, int threshold, double ownerEqual) {
        int t = Math.max(1, threshold);
        long delta = (long)invader - owner;
        if (delta >= t) return 1;
        if (delta <= -t) return 0;
        double base = 1 - Math.clamp(ownerEqual, 0, 1);
        return delta >= 0 ? base + (1-base)*delta/t : base + base*delta/t;
    }
    /** Standing inside the freshly vacated body must not count as returning to it. */
    public static boolean canProximityEnter(boolean ownBody,boolean leftBody,long elapsedTicks){
        return elapsedTicks>10&&(!ownBody||leftBody);
    }
    public static long durationTicks(double baseSeconds, double reduction, int souls, double minimum) {
        return Math.max(1, Math.round(20 * Math.max(minimum, baseSeconds - Math.max(0,souls)*reduction)));
    }
    public static int timerStage(long now,long started,long expires){
        if(expires==Long.MAX_VALUE||expires<=started||now<started)return 0;
        double fraction=(double)(now-started)/(expires-started);
        return fraction>=0.9?2:fraction>=0.5?1:0;
    }
}
