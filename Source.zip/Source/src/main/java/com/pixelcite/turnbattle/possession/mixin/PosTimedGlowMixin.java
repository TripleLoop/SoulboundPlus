package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import java.util.Map;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(value=SoulGlowRenderer.class,remap=false)
public abstract class PosTimedGlowMixin {
    @Redirect(method="tick",at=@At(value="INVOKE",target="Ljava/util/Map;containsKey(Ljava/lang/Object;)Z"))
    private static boolean plus$reveal(Map<?,?> map,Object id){return map.containsKey(id)||PosTimedVisual.revealed(id);}
    @Redirect(method="computeScreenPositions",at=@At(value="INVOKE",target="Ljava/util/Map;getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"))
    private static Object plus$soul(Map<?,?> map,Object id,Object fallback){
        Object value=map.containsKey(id)?map.get(id):fallback;
        return value==null||value instanceof SoulType?PosTimedVisual.soul(id,(SoulType)value):value;
    }
}
