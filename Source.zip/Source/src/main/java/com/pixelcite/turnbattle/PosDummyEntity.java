package com.pixelcite.turnbattle;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.world.World;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.entity.data.*;
import java.util.UUID;

/** An inert body for solo animation/contest testing, without a second player account. */
public final class PosDummyEntity extends PathAwareEntity {
    public enum Kind { HUMAN,MONSTER,EMPTY }
    private static final TrackedData<Integer> KIND=DataTracker.registerData(PosDummyEntity.class,TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> SOUL=DataTracker.registerData(PosDummyEntity.class,TrackedDataHandlerRegistry.INTEGER);
    int soulLevel=1;
    int absorbedSouls;
    UUID creator;
    public PosDummyEntity(EntityType<? extends PathAwareEntity> type,World world){super(type,world);setAiDisabled(true);setInvulnerable(true);setPersistent();}
    @Override protected void initDataTracker(DataTracker.Builder builder){super.initDataTracker(builder);builder.add(KIND,0);builder.add(SOUL,SoulType.DETERMINATION.ordinal());}
    public Kind kind(){return Kind.values()[Math.clamp(dataTracker.get(KIND),0,Kind.values().length-1)];}
    public SoulType soul(){return kind()==Kind.EMPTY?null:kind()==Kind.MONSTER?SoulType.MONSTER:SoulType.values()[Math.clamp(dataTracker.get(SOUL),0,SoulType.values().length-1)];}
    void setup(UUID owner,Kind kind,int level,SoulType soul,int absorbed){
        creator=owner;soulLevel=Math.clamp(level,1,99);absorbedSouls=Math.clamp(absorbed,0,7);dataTracker.set(KIND,kind.ordinal());
        dataTracker.set(SOUL,(soul==null||soul==SoulType.MONSTER?SoulType.DETERMINATION:soul).ordinal());refreshName();
    }
    void refreshName(){
        String label=switch(kind()){
            case HUMAN->"Human Dummy — "+soul().getDisplayName()+" (LV "+soulLevel+")";
            case MONSTER->"Monster Dummy ("+absorbedSouls+"/7 souls absorbed)";
            case EMPTY->"Empty Dummy";
        };
        var text=Text.literal(label);if(soul()!=null)text.setStyle(net.minecraft.text.Style.EMPTY.withColor(soul().getColor()&0xFFFFFF));
        setCustomName(text);setCustomNameVisible(true);
    }
    @Override protected void initGoals() {}
    @Override public boolean isAttackable(){return false;}
    @Override public boolean isPushable(){return false;}
    @Override public boolean canTarget(LivingEntity entity){return false;}
    @Override public void writeCustomDataToNbt(NbtCompound nbt){super.writeCustomDataToNbt(nbt);nbt.putInt("DummyLevel",soulLevel);nbt.putInt("DummyKind",kind().ordinal());nbt.putInt("DummySoul",dataTracker.get(SOUL));nbt.putInt("DummyAbsorbed",absorbedSouls);if(creator!=null)nbt.putUuid("DummyCreator",creator);}
    @Override public void readCustomDataFromNbt(NbtCompound nbt){
        super.readCustomDataFromNbt(nbt);soulLevel=Math.clamp(nbt.getInt("DummyLevel"),1,99);absorbedSouls=Math.clamp(nbt.getInt("DummyAbsorbed"),0,7);
        dataTracker.set(KIND,Math.clamp(nbt.getInt("DummyKind"),0,2));int type=Math.clamp(nbt.getInt("DummySoul"),0,SoulType.values().length-1);
        dataTracker.set(SOUL,type==SoulType.MONSTER.ordinal()?SoulType.DETERMINATION.ordinal():type);
        creator=nbt.containsUuid("DummyCreator")?nbt.getUuid("DummyCreator"):null;setAiDisabled(true);setInvulnerable(true);refreshName();
    }
}
