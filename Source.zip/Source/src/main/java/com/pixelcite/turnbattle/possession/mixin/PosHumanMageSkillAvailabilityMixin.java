package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=HumanMageSkill.class,remap=false)
public abstract class PosHumanMageSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILjava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/HumanMageSkill;lv:I"))
    private static int plus$level(HumanMageSkill skill){return skill.getLevelRequired();}
}
