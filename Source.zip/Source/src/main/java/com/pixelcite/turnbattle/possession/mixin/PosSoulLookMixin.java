package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosSoulCamera;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(Entity.class)
public abstract class PosSoulLookMixin {
    @WrapMethod(method="changeLookDirection")
    private void plus$lookScope(double x,double y,Operation<Void> original){
        boolean previous=PosSoulCamera.looking;
        if((Object)this==MinecraftClient.getInstance().player)PosSoulCamera.looking=true;
        try{original.call(x,y);}finally{PosSoulCamera.looking=previous;}
    }
}
