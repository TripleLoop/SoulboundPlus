package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=PsiSkill.class,remap=false)
public abstract class PosPsiSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILjava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/PsiSkill;lr:I"))
    private static int plus$level(PsiSkill skill){return skill.getLevelRequired();}
}
