package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ServerPlayerEntity.class)
public abstract class PosDeathMixin {
    @Inject(method="onDeath",at=@At("HEAD"))
    private void possession$death(DamageSource source,CallbackInfo ci){PosManager.death((ServerPlayerEntity)(Object)this);}
}
