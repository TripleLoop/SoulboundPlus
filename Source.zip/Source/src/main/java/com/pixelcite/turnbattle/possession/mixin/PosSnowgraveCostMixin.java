package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=LightnerSkill.class,remap=false)
public abstract class PosSnowgraveCostMixin {
    @Inject(method="snowgraveCost",at=@At("RETURN"),cancellable=true)
    private static void plus$cost(float maxTp,CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value(LightnerSkill.SNOWGRAVE,1,c.getReturnValue()));}
}
