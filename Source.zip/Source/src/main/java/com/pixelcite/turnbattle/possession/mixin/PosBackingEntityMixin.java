package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosManager;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** A possessed body's parked entity is storage, not another combat participant. */
@Mixin(Entity.class)
public abstract class PosBackingEntityMixin {
    @Inject(method="pushAwayFrom",at=@At("HEAD"),cancellable=true)
    private void possession$noBackingPush(Entity other,CallbackInfo ci){
        if(PosManager.isSuppressedEntity((Entity)(Object)this)||PosManager.isSuppressedEntity(other))ci.cancel();
    }
    @Inject(method={"isAttackable","isCollidable"},at=@At("HEAD"),cancellable=true)
    private void possession$notInteractive(CallbackInfoReturnable<Boolean> cir){if(PosManager.isSuppressedEntity((Entity)(Object)this))cir.setReturnValue(false);}
    @Inject(method="isSpectator",at=@At("HEAD"),cancellable=true)
    private void possession$ignoreTargeting(CallbackInfoReturnable<Boolean> cir){if(PosManager.isSuppressedEntity((Entity)(Object)this))cir.setReturnValue(true);}
}
