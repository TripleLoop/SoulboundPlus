package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosMobVision;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Camera.class)
public abstract class PosMobVisionCameraMixin {
    @Shadow private float cameraY;
    @Shadow private float lastCameraY;
    @Shadow public abstract Vec3d getPos();
    @Shadow protected abstract void setPos(double x,double y,double z);
    @Inject(method="update",at=@At("TAIL"))
    private void plus$eyeHeight(BlockView area,Entity focusedEntity,boolean thirdPerson,boolean inverseView,float delta,CallbackInfo ci){
        if(thirdPerson)return;
        MobEntity mob=PosMobVision.mob();if(mob==null)return;
        Vec3d p=getPos();double offset=PosMobVision.eyeHeight(mob)-MathHelper.lerp(delta,lastCameraY,cameraY);
        setPos(p.x,p.y+offset,p.z);
    }
}
