package com.pixelcite.turnbattle;
/** A mob view is purely visual and must never override a combat/cinematic camera. */
public final class PosVisionRules {
    private PosVisionRules() {}
    public static boolean active(boolean possessingMob,boolean firstPerson,boolean localCamera,boolean alive,boolean combat,boolean cinematic){
        return possessingMob&&firstPerson&&localCamera&&alive&&!combat&&!cinematic;
    }
}
