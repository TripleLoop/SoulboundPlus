package com.pixelcite.turnbattle;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.entity.LivingEntity;
import java.util.*;

/** Detect a humanoid skeleton by its bones, not a list of mob species. Keeps original geometry/textures. */
public final class PosHumanoidModel {
    private static final Map<EntityModel<?>,BipedEntityModel<LivingEntity>> views=new WeakHashMap<>();
    private PosHumanoidModel() {}
    @SuppressWarnings("unchecked") public static BipedEntityModel<LivingEntity> view(EntityModel<?> model){
        if(model instanceof BipedEntityModel<?> b)return (BipedEntityModel<LivingEntity>)b;
        if(!(model instanceof SinglePartEntityModel<?> single))return null;
        ModelPart root=single.getPart();
        for(String key:new String[]{"head","body","right_arm","left_arm","right_leg","left_leg"})if(!root.hasChild(key))return null;
        return views.computeIfAbsent(model,m->{
            var bones=new HashMap<String,ModelPart>();
            for(String key:new String[]{"head","body","right_arm","left_arm","right_leg","left_leg"})bones.put(key,root.getChild(key));
            var head=root.getChild("head");bones.put("hat",head.hasChild("hat")?head.getChild("hat"):new ModelPart(List.of(),Map.of()));
            return new BipedEntityModel<>(new ModelPart(List.of(),bones));
        });
    }
    public static void separateArms(EntityModel<?> model,BipedEntityModel<?> view){
        if(model instanceof SinglePartEntityModel<?> single&&single.getPart().hasChild("arms")){
            var crossed=single.getPart().getChild("arms");PosClient.saveVisibility(crossed);crossed.visible=false;
            PosClient.saveVisibility(view.rightArm);PosClient.saveVisibility(view.leftArm);view.rightArm.visible=true;view.leftArm.visible=true;
        }
    }
}
