package com.pixelcite.turnbattle.possession.mixin;
import net.minecraft.entity.LimbAnimator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(LimbAnimator.class)
public interface PosLimbAccess {
    @Accessor("prevSpeed") float plus$previous();
    @Accessor("speed") float plus$speed();
    @Accessor("pos") float plus$position();
    @Accessor("prevSpeed") void plus$previous(float value);
    @Accessor("speed") void plus$speed(float value);
    @Accessor("pos") void plus$position(float value);
}
