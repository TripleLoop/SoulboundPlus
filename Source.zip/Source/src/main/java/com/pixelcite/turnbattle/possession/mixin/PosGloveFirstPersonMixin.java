package com.pixelcite.turnbattle.possession.mixin;

import com.pixelcite.turnbattle.PosGloves;
import com.pixelcite.turnbattle.PosShoes;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class PosGloveFirstPersonMixin {
    @Unique private boolean plus$pairDrawn;
    @Shadow protected abstract void renderArmHoldingItem(MatrixStack matrices,VertexConsumerProvider vertices,int light,float equipProgress,float swingProgress,Arm side);
    @Inject(method="renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",at=@At("HEAD"))
    private void plus$beginHands(float delta,MatrixStack matrices,VertexConsumerProvider.Immediate vertices,net.minecraft.client.network.ClientPlayerEntity player,int light,CallbackInfo ci){plus$pairDrawn=false;}
    @Inject(method="renderFirstPersonItem",at=@At("HEAD"),cancellable=true)
    private void plus$gloveHands(AbstractClientPlayerEntity player,float delta,float pitch,Hand hand,float swing,ItemStack stack,float equip,MatrixStack matrices,VertexConsumerProvider vertices,int light,CallbackInfo ci){
        if(PosShoes.matches(stack)){
            if(hand==Hand.MAIN_HAND&&!player.isInvisible()&&!PosGloves.equipped(player)){
                matrices.push();try{renderArmHoldingItem(matrices,vertices,light,equip,swing,player.getMainArm());}finally{matrices.pop();}
            }
            ci.cancel();return;
        }
        if(player.isInvisible()||(!PosGloves.matches(stack)&&!PosGloves.equipped(player)))return;
        if(!plus$pairDrawn){
            plus$pairDrawn=true;
            Arm active=hand==Hand.MAIN_HAND?player.getMainArm():player.getMainArm().getOpposite();
            PosGloves.firstPerson=true;
            try{
            matrices.push();
            try{renderArmHoldingItem(matrices,vertices,light,equip,swing,active);}finally{matrices.pop();}
            matrices.push();
            try{renderArmHoldingItem(matrices,vertices,light,equip,0,active.getOpposite());}finally{matrices.pop();}
            }finally{PosGloves.firstPerson=false;}
        }
        // Keep unrelated held items visible; replace only the glove sprite or bare-hand pass.
        if(PosGloves.matches(stack)||stack.isEmpty())ci.cancel();
    }
}
