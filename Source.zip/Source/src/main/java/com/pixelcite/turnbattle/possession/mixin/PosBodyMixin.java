package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(SoulBodyEntity.class)
public abstract class PosBodyMixin {
    @Inject(method="damage",at=@At("HEAD"),cancellable=true)
    private void possession$damage(DamageSource source,float amount,CallbackInfoReturnable<Boolean> cir){cir.setReturnValue(PosManager.bodyDamage((SoulBodyEntity)(Object)this,source,amount));}
}
