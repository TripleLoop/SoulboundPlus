package com.pixelcite.turnbattle;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.*;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import java.util.*;

public final class PosDummies {
    public static final EntityType<PosDummyEntity> TYPE=Registry.register(Registries.ENTITY_TYPE,Identifier.of("soulbound_possession","test_dummy"),EntityType.Builder.create(PosDummyEntity::new,SpawnGroup.MISC).dimensions(0.6f,1.8f).maxTrackingRange(8).disableSummon().build(null));
    record Challenge(UUID soul,PosDummyEntity body,long began,long end,net.minecraft.util.math.Vec3d origin,boolean preview) {}
    static final Map<UUID,Challenge> challenges=new HashMap<>();
    private PosDummies() {}
    static void register(){
        FabricDefaultAttributeRegistry.register(TYPE,net.minecraft.entity.mob.MobEntity.createMobAttributes());
        CommandRegistrationCallback.EVENT.register((dispatcher,access,environment)->dispatcher.register(commands()));
    }
    static com.mojang.brigadier.builder.LiteralArgumentBuilder<net.minecraft.server.command.ServerCommandSource> commands(){
        return CommandManager.literal("soulboundplus").requires(s->s.hasPermissionLevel(2)).then(CommandManager.literal("dummy")
            .then(CommandManager.literal("spawn")
                .then(CommandManager.literal("human").executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.HUMAN,-1,null,0))
                    .then(CommandManager.argument("level",IntegerArgumentType.integer(1,99)).executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.HUMAN,IntegerArgumentType.getInteger(c,"level"),null,0))
                        .then(soulArgument().executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.HUMAN,IntegerArgumentType.getInteger(c,"level"),humanSoul(StringArgumentType.getString(c,"soul")),0)))))
                .then(CommandManager.literal("monster").executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.MONSTER,1,SoulType.MONSTER,0))
                    .then(CommandManager.argument("souls",IntegerArgumentType.integer(0,7)).executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.MONSTER,1,SoulType.MONSTER,IntegerArgumentType.getInteger(c,"souls")))))
                .then(CommandManager.literal("empty").executes(c->spawn(c.getSource().getPlayerOrThrow(),PosDummyEntity.Kind.EMPTY,1,null,0))))
            .then(CommandManager.literal("set")
                .then(CommandManager.literal("level").then(CommandManager.argument("level",IntegerArgumentType.integer(1,99)).executes(c->edit(c.getSource().getPlayerOrThrow(),"level",IntegerArgumentType.getInteger(c,"level"),null))))
                .then(CommandManager.literal("soul").then(soulArgument().executes(c->edit(c.getSource().getPlayerOrThrow(),"soul",0,humanSoul(StringArgumentType.getString(c,"soul"))))))
                .then(CommandManager.literal("souls").then(CommandManager.argument("souls",IntegerArgumentType.integer(0,7)).executes(c->edit(c.getSource().getPlayerOrThrow(),"souls",IntegerArgumentType.getInteger(c,"souls"),null)))))
            .then(CommandManager.literal("preview").then(CommandManager.literal("struggle").executes(c->preview(c.getSource().getPlayerOrThrow(),false))).then(CommandManager.literal("eject").executes(c->preview(c.getSource().getPlayerOrThrow(),true))))
            .then(CommandManager.literal("clear").executes(c->clear(c.getSource().getPlayerOrThrow()))));
    }
    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<net.minecraft.server.command.ServerCommandSource,String> soulArgument(){
        return CommandManager.argument("soul",StringArgumentType.word()).suggests((context,builder)->net.minecraft.command.CommandSource.suggestMatching(Arrays.stream(SoulType.values()).filter(s->s!=SoulType.MONSTER).map(s->s.name().toLowerCase(Locale.ROOT)),builder));
    }
    static SoulType humanSoul(String name)throws CommandSyntaxException{
        try{SoulType type=SoulType.valueOf(name.toUpperCase(Locale.ROOT));if(type!=SoulType.MONSTER)return type;}catch(IllegalArgumentException ignored){}
        throw new SimpleCommandExceptionType(Text.literal("Choose a human soul: determination, perseverance, integrity, patience, justice, bravery, kindness or ori.")).create();
    }
    static int spawn(ServerPlayerEntity p,PosDummyEntity.Kind kind,int level,SoulType soul,int absorbed){
        var dummy=TYPE.create(p.getServerWorld());if(dummy==null)return 0;
        var progress=BattleData.get(p.getServer()).getOrCreate(p.getUuid());
        dummy.setup(p.getUuid(),kind,level<0?progress.level:level,soul==null?progress.soulType:soul,absorbed);
        Vec3d at=p.getPos().add(p.getRotationVec(1).multiply(2));dummy.refreshPositionAndAngles(at.x,p.getY(),at.z,p.getYaw()+180,0);
        p.getServerWorld().spawnEntity(dummy);p.sendMessage(Text.literal("Dummy ready. Approach its chest in soul mode, or use /soulboundplus dummy preview struggle|eject."),false);return 1;
    }
    static PosDummyEntity nearest(ServerPlayerEntity p){return nearest(p,null);}
    static PosDummyEntity nearest(ServerPlayerEntity p,PosDummyEntity.Kind kind){return p.getServerWorld().getEntitiesByClass(PosDummyEntity.class,p.getBoundingBox().expand(16),d->p.getUuid().equals(d.creator)&&(kind==null||d.kind()==kind)).stream().min(Comparator.comparingDouble(p::squaredDistanceTo)).orElse(null);}
    static int edit(ServerPlayerEntity p,String field,int value,SoulType soul){
        var dummy=nearest(p,field.equals("souls")?PosDummyEntity.Kind.MONSTER:PosDummyEntity.Kind.HUMAN);
        if(dummy==null){p.sendMessage(Text.literal("No matching dummy of yours within 16 blocks."),false);return 0;}
        if(PosManager.occupant(dummy.getUuid())!=null||challenges.containsKey(dummy.getUuid())){p.sendMessage(Text.literal("Leave the dummy and finish its struggle before editing it."),false);return 0;}
        dummy.setup(dummy.creator,dummy.kind(),field.equals("level")?value:dummy.soulLevel,field.equals("soul")?soul:dummy.soul(),field.equals("souls")?value:dummy.absorbedSouls);
        p.sendMessage(Text.literal("Updated ").append(dummy.getDisplayName()),false);return 1;
    }
    static long duration(PosDummyEntity dummy){return duration(dummy.kind(),dummy.absorbedSouls);}
    static long duration(PosDummyEntity.Kind kind,int souls){return kind==PosDummyEntity.Kind.MONSTER?PosRules.durationTicks(PosConfig.get("monsterBase"),PosConfig.get("soulReduction"),Math.clamp(souls,0,7),PosConfig.get("minimum")):Long.MAX_VALUE;}
    static int preview(ServerPlayerEntity p,boolean eject){
        var dummy=nearest(p);if(dummy==null){p.sendMessage(Text.literal("Spawn a nearby test dummy first."),false);return 0;}
        if(PosManager.occupant(dummy.getUuid())!=null||challenges.containsKey(dummy.getUuid()))return 0;
        if(eject)PosNet.effect(p.getServer(),dummy.getUuid(),p.getPos().subtract(dummy.getPos()));
        else{challenges.put(dummy.getUuid(),new Challenge(p.getUuid(),dummy,PosManager.now(p.getServer()),PosManager.now(p.getServer())+Math.max(1,Math.round(PosConfig.get("struggle")*20)),dummy.getPos(),true));PosNet.sync(p.getServer());}
        return 1;
    }
    static boolean busy(UUID soul){return challenges.values().stream().anyMatch(c->!c.preview&&c.soul.equals(soul));}
    static void challenge(ServerPlayerEntity p,PosDummyEntity dummy){
        if(challenges.containsKey(dummy.getUuid())||PosManager.occupant(dummy.getUuid())!=null)return;
        if(dummy.kind()!=PosDummyEntity.Kind.HUMAN){PosManager.enterMob(p,dummy);return;}
        float seconds=PosConfig.get("struggle");
        challenges.put(dummy.getUuid(),new Challenge(p.getUuid(),dummy,PosManager.now(p.getServer()),PosManager.now(p.getServer())+Math.max(1,Math.round(seconds*20)),dummy.getPos(),false));PosManager.stopMotion(p);PosNet.sync(p.getServer());
    }
    static void tick(MinecraftServer s){
        boolean changed=false;
        for(var c:new ArrayList<>(challenges.values())){
            var p=PosManager.player(s,c.soul);var dummy=c.body;
            if(p==null||!p.isAlive()||dummy.isRemoved()){challenges.remove(dummy.getUuid());changed=true;continue;}
            boolean interrupted=BattleManager.isInBattle(p.getUuid())||!PosConfig.on("enabled")||(!c.preview&&!SoulWalk.isOut(p));
            if(!interrupted)PosBodyMotion.struggle(dummy,dummy.getUuid(),c.origin,c.began,c.end,PosManager.now(s));
            if(!c.preview&&!interrupted){p.setVelocity(Vec3d.ZERO);p.teleport((net.minecraft.server.world.ServerWorld)dummy.getWorld(),dummy.getX(),dummy.getY()+0.9,dummy.getZ(),p.getYaw(),p.getPitch());}
            if(!interrupted&&PosManager.now(s)<c.end)continue;
            challenges.remove(dummy.getUuid());changed=true;if(c.preview)continue;
            PosManager.cooldown(s,p.getUuid(),dummy.getUuid());
            double chance=PosRules.invaderChance(BattleData.get(s).getOrCreate(p.getUuid()).level,dummy.soulLevel,(int)PosConfig.get("levelGap"),PosConfig.get("ownerBonus")/100.0);
            if(!interrupted&&s.getOverworld().random.nextDouble()<chance){PosManager.enterMob(p,dummy);PosNet.effect(s,dummy.getUuid(),dummy.getRotationVec(1),dummy.soul());PosManager.message(p,"You won control of the test dummy.");}
            else{PosManager.push(p,dummy.getPos());PosNet.effect(s,dummy.getUuid(),p.getPos().subtract(dummy.getPos()),PosNet.soul(p));PosManager.message(p,"The dummy ejected your soul.");}
        }
        if(changed)PosNet.sync(s);
    }
    static void interrupt(ServerPlayerEntity p){
        for(var c:new ArrayList<>(challenges.values()))if(c.soul.equals(p.getUuid())){challenges.remove(c.body.getUuid());if(!c.preview){PosManager.cooldown(p.getServer(),p.getUuid(),c.body.getUuid());PosManager.push(p,c.body.getPos());PosNet.effect(p.getServer(),c.body.getUuid(),p.getPos().subtract(c.body.getPos()));}}
    }
    static int clear(ServerPlayerEntity p){
        int count=0;for(var world:p.getServer().getWorlds())for(var entity:new ArrayList<>(world.getEntitiesByType(TYPE,d->p.getUuid().equals(d.creator)))){
            var held=PosManager.occupant(entity.getUuid());if(held!=null){var guest=PosManager.player(p.getServer(),held.soul);if(guest!=null)PosManager.exit(guest,false,true);}
            var challenge=challenges.remove(entity.getUuid());if(challenge!=null&&!challenge.preview){var guest=PosManager.player(p.getServer(),challenge.soul);if(guest!=null)PosManager.push(guest,entity.getPos());}
            for(var slot:EquipmentSlot.values()){var stack=entity.getEquippedStack(slot);if(!stack.isEmpty()){entity.dropStack(stack.copy());entity.equipStack(slot,net.minecraft.item.ItemStack.EMPTY);}}
            entity.discard();count++;
        }
        PosNet.sync(p.getServer());p.sendMessage(Text.literal("Removed "+count+" test dummies."),false);return count;
    }
}
