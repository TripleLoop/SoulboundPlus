package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=LivingEntity.class,priority=1200)
public abstract class PosBackingLivingMixin {
    @Inject(method={"canHit","isPushable"},at=@At("HEAD"),cancellable=true)
    private void possession$ignoreHitbox(CallbackInfoReturnable<Boolean> cir){if(PosManager.isSuppressedEntity((LivingEntity)(Object)this))cir.setReturnValue(false);}
    @Inject(method="damage",at=@At("HEAD"),cancellable=true)
    private void possession$ignoreDamage(DamageSource source,float amount,CallbackInfoReturnable<Boolean> cir){if(PosManager.isSuppressedEntity((LivingEntity)(Object)this))cir.setReturnValue(false);}
    @Inject(method="canTarget(Lnet/minecraft/entity/LivingEntity;)Z",at=@At("HEAD"),cancellable=true)
    private void possession$ignoreAsTarget(LivingEntity target,CallbackInfoReturnable<Boolean> cir){if(PosManager.isSuppressedEntity(target)||PosManager.isSuppressedEntity((LivingEntity)(Object)this))cir.setReturnValue(false);}
}
