package com.pixelcite.turnbattle;
import java.util.UUID;

/** Five chest-led yanks, sampled by both server movement and client skeleton poses. */
public final class PosStruggleMotion {
    public record Sample(double x,double y,double z,double force) {}
    private PosStruggleMotion() {}
    public static Sample sample(UUID body,double elapsed,double duration){
        if(duration<=0||elapsed<0||elapsed>duration)return new Sample(0,0,0,0);
        double active=pullWindowTicks(duration);
        if(elapsed>=active)return new Sample(0,0,0,0);
        double period=active/5.0,width=Math.min(8,period*0.45);
        double x=0,y=0,z=0,force=0;
        double seed=((body.getMostSignificantBits()^body.getLeastSignificantBits())&0xffff)*(Math.PI*2/65536);
        for(int i=1;i<=5;i++){
            double age=elapsed-(i-0.5)*period;if(age < -width||age>width)continue;
            double w=age<=0?smooth(1+age/width):(1-smooth(age/width))*(1-1.25*smooth(age/width));
            double angle=seed+i*2.3999632297;
            x+=Math.cos(angle)*w;z+=Math.sin(angle)*w;y+=Math.max(0,w)*0.16;force+=Math.abs(w);
        }
        return new Sample(x,y,z,Math.min(1,force));
    }
    /** Continuous chest tug and smaller recoil; no abrupt direction flip mid-pull. */
    public static double ejectionForce(double ticks){
        if(ticks<0||ticks>=16)return 0;
        return ticks<=8?Math.sin(Math.PI*ticks/8):-0.25*Math.sin(Math.PI*(ticks-8)/8);
    }
    private static double smooth(double x){x=Math.clamp(x,0,1);return x*x*(3-2*x);}
    /** Reserve the final 30%, capped at three seconds, for an uninterrupted soul extraction. */
    public static double pullWindowTicks(double duration){return Math.max(0,duration-Math.min(60,duration*0.3));}
    public static double struggleExtractionTicks(double now,double start,double end){
        double begin=start+pullWindowTicks(end-start);
        return now<begin?-1:Math.clamp((now-begin)/Math.max(0.001,end-begin),0,1)*60;
    }
    public static double extractionTicks(double now,double start,double end){
        double length=Math.min(60,Math.max(1,end-start));
        return now<end-length?-1:Math.clamp((now-(end-length))/length,0,1)*60;
    }
}
