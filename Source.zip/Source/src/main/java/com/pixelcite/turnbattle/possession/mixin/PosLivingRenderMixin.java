package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LivingEntityRenderer.class)
public abstract class PosLivingRenderMixin {
    @Shadow protected EntityModel<?> model;
    @Inject(method="render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/LivingEntityRenderer;setupTransforms(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/util/math/MatrixStack;FFFF)V",shift=At.Shift.AFTER))
    private void possession$nativeExtraction(LivingEntity e,float yaw,float delta,MatrixStack matrices,VertexConsumerProvider vertices,int light,CallbackInfo ci){if(com.pixelcite.turnbattle.PosHumanoidModel.view(model)!=null)PosClient.transformExtraction(e,matrices);}
    @Redirect(method="render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/entity/model/EntityModel;setAngles(Lnet/minecraft/entity/Entity;FFFFF)V"))
    @SuppressWarnings({"rawtypes","unchecked"})
    private void possession$finalPose(EntityModel target,net.minecraft.entity.Entity entity,float limbAngle,float limbDistance,float age,float headYaw,float headPitch){
        target.setAngles(entity,limbAngle,limbDistance,age,headYaw,headPitch);
        PosClient.finishModelAngles(target,(LivingEntity)entity,limbAngle,limbDistance,age,headYaw,headPitch);
    }
    @Inject(method="render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",at=@At("RETURN"))
    private void possession$restore(LivingEntity e,float yaw,float delta,MatrixStack m,VertexConsumerProvider v,int light,CallbackInfo ci){PosClient.restoreParts();}
}
