package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class PosTimedOutlineMixin {
    @Inject(method="isGlowing",at=@At("RETURN"),cancellable=true)
    private void plus$outline(CallbackInfoReturnable<Boolean> cir){if(PosTimedVisual.glowing(((Entity)(Object)this).getUuid()))cir.setReturnValue(true);}
    @Inject(method="getTeamColorValue",at=@At("RETURN"),cancellable=true)
    private void plus$color(CallbackInfoReturnable<Integer> cir){var id=((Entity)(Object)this).getUuid();if(PosTimedVisual.glowing(id))cir.setReturnValue(PosTimedVisual.soul(id,SoulType.DETERMINATION).getColor()&0xFFFFFF);}
}
