package com.pixelcite.turnbattle;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;

/** Apply after the most-derived model setAngles, so zombie/skeleton arms cannot overwrite extraction. */
public final class PosModelPose {
    private PosModelPose() {}
    public static void apply(BipedEntityModel<?> model,LivingEntity entity,CloneAnimator.Pose pose){
        var previous=CloneAnimator.activePoseFor(entity);
        CloneAnimator.beginModelPose(entity,pose);
        try{CloneAnimator.applyModelPose(model,entity);}
        finally{CloneAnimator.endModelPose();if(previous!=null)CloneAnimator.beginModelPose(entity,previous);}
    }
}
