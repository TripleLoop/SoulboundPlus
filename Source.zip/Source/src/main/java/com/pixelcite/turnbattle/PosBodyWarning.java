package com.pixelcite.turnbattle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Owner-only damage notice, sharing the vanilla selected-item-name position. */
public final class PosBodyWarning {
    private static int remaining;
    private PosBodyWarning() {}
    static void show(){remaining=60;}
    static void reset(){remaining=0;}
    static void tick(MinecraftClient client){
        if(client.world==null||client.player==null||!client.player.isAlive())reset();
        else if(!client.isPaused()&&remaining>0)remaining--;
    }
    public static boolean render(DrawContext context){
        MinecraftClient client=MinecraftClient.getInstance();
        if(remaining<=0||client.player==null||!client.player.isAlive()||client.interactionManager==null)return false;
        int rgb=TurnBattleClientMod.clientSoul!=null?TurnBattleClientMod.clientSoul.getColor()&0xFFFFFF:0xFFFFFF;
        Text text=Text.translatable("soulbound_plus.body_damage_warning").styled(style->style.withColor(rgb));
        int width=client.textRenderer.getWidth(text);
        int y=context.getScaledWindowHeight()-59+(client.interactionManager.hasStatusBars()?0:14);
        int alpha=Math.min(255,remaining*256/10);
        context.drawTextWithBackground(client.textRenderer,text,(context.getScaledWindowWidth()-width)/2,y,width,(alpha<<24)|0xFFFFFF);
        return true;
    }
}
