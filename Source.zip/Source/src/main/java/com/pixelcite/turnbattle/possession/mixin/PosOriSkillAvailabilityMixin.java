package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=OriSkill.class,remap=false)
public abstract class PosOriSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILjava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/OriSkill;levelRequired:I"))
    private static int plus$level(OriSkill skill){return skill.getLevelRequired();}
}
