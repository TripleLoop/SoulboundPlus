package com.pixelcite.turnbattle;

import java.util.*;

/** Stable identity-based ordering; unavailable skills keep their saved positions. */
public final class PosSkillOrderRules {
    private PosSkillOrderRules() {}
    public static List<String> unique(Collection<String> ids){
        LinkedHashSet<String> result=new LinkedHashSet<>();
        for(String id:ids)if(id!=null&&!id.isBlank())result.add(id);
        return List.copyOf(result);
    }
    public static List<String> merge(List<String> saved,List<String> visible){
        List<String> ordered=unique(visible);Set<String> moving=new HashSet<>(ordered);
        Iterator<String> replacements=ordered.iterator();List<String> result=new ArrayList<>();
        for(String id:unique(saved)){
            if(moving.contains(id)){if(replacements.hasNext())result.add(replacements.next());}
            else result.add(id);
        }
        replacements.forEachRemaining(result::add);return List.copyOf(result);
    }
    public static List<String> move(List<String> visible,int from,int to){
        List<String> result=new ArrayList<>(visible);
        if(from<0||from>=result.size()||to<0||to>=result.size())return List.copyOf(result);
        result.add(to,result.remove(from));return List.copyOf(result);
    }
    public static <T> List<T> sorted(Collection<T> source,List<String> saved,java.util.function.Function<T,String> identity,Comparator<T> fallback){
        Map<String,Integer> rank=new HashMap<>();int index=0;for(String id:unique(saved))rank.put(id,index++);
        List<T> result=new ArrayList<>(source);
        result.sort(Comparator.<T>comparingInt(s->rank.getOrDefault(identity.apply(s),Integer.MAX_VALUE)).thenComparing(fallback));return result;
    }
}
