package com.pixelcite.turnbattle;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import java.nio.file.*;
import java.util.*;

/** Personal UI preferences, scoped to player profile and selected actor; no skill grants or server edits. */
public final class PosSkillOrder {
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("soulbound-plus-skill-order.json");
    private static final Map<String,Map<String,List<String>>> profiles=new HashMap<>();
    private static boolean loaded,writable=true;
    private PosSkillOrder() {}
    private static String profile(){var player=MinecraftClient.getInstance().player;return player==null?"":player.getUuidAsString();}
    public static String actor(int code){
        if(code<0)return "self";
        if(code>=1000){int i=code-1000;var names=TurnBattleClientMod.customRecruitNames;return "custom:"+(names!=null&&i<names.length?names[i]:i);}
        return "recruit:"+(code<Recruit.values().length?Recruit.values()[code].name():code);
    }
    public static String actor(Object member){return actor(((VoidMenuScreen.Member)member).code());}
    public static boolean supports(Object member){
        var m=(VoidMenuScreen.Member)member;
        return m.cls()!=null&&(!m.isYou()||(!TurnBattleClientMod.rogueliteInRun&&!DepthsClient.inRun()));
    }
    private static void load(){
        if(loaded)return;loaded=true;if(!Files.exists(FILE))return;
        try(var reader=Files.newBufferedReader(FILE)){
            JsonObject root=JsonParser.parseReader(reader).getAsJsonObject();
            for(var p:root.entrySet()){
                Map<String,List<String>> actors=new HashMap<>();
                for(var a:p.getValue().getAsJsonObject().entrySet()){
                    List<String> ids=new ArrayList<>();for(var id:a.getValue().getAsJsonArray())if(id.isJsonPrimitive()&&id.getAsJsonPrimitive().isString())ids.add(id.getAsString());
                    actors.put(a.getKey(),PosSkillOrderRules.unique(ids));
                }
                profiles.put(p.getKey(),actors);
            }
        }catch(Exception e){profiles.clear();writable=false;org.slf4j.LoggerFactory.getLogger("SoulBound+").error("Cannot read personal skill ordering",e);}
    }
    public static List<BattleSkill> ordered(String actor,Collection<BattleSkill> source){
        load();List<String> saved=profiles.getOrDefault(profile(),Map.of()).getOrDefault(actor,List.of());
        return PosSkillOrderRules.sorted(source,saved,PosSkillBalance::id,Comparator.<BattleSkill>comparingInt(s->s==VesselActionSkill.INSTANCE?-1:0).thenComparing(BattleSkill::getDisplayName,String.CASE_INSENSITIVE_ORDER).thenComparing(PosSkillBalance::id));
    }
    public static List<BattleSkill> menu(Object member,List<BattleSkill> nativeSkills){
        if(!supports(member))return nativeSkills;
        List<BattleSkill> out=new ArrayList<>(nativeSkills);if(!out.contains(VesselActionSkill.INSTANCE))out.add(VesselActionSkill.INSTANCE);
        return ordered(actor(member),out);
    }
    public static boolean move(String actor,List<BattleSkill> visible,int from,int to){
        load();if(!writable||profile().isEmpty())return false;
        String profile=profile();List<String> ids=visible.stream().map(PosSkillBalance::id).toList();
        Map<String,List<String>> actors=new HashMap<>(profiles.getOrDefault(profile,Map.of()));
        actors.put(actor,PosSkillOrderRules.merge(actors.getOrDefault(actor,List.of()),PosSkillOrderRules.move(ids,from,to)));
        Map<String,Map<String,List<String>>> next=new HashMap<>(profiles);next.put(profile,actors);
        try{
            Files.createDirectories(FILE.getParent());Path tmp=FILE.resolveSibling(FILE.getFileName()+".tmp");
            Files.writeString(tmp,new GsonBuilder().setPrettyPrinting().create().toJson(next));
            try{Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,FILE,StandardCopyOption.REPLACE_EXISTING);}
            profiles.clear();profiles.putAll(next);return true;
        }catch(Exception e){org.slf4j.LoggerFactory.getLogger("SoulBound+").error("Cannot save personal skill ordering",e);return false;}
    }
}
