package com.pixelcite.turnbattle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.*;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import java.util.UUID;

/** Uses vanilla spectator shaders without changing the camera entity or game mode. */
public final class PosMobVision {
    private static MobEntity view;
    private static ClientWorld world;
    private static String type;
    private static UUID body;
    private static PostEffectProcessor ownedEffect;
    private static String effectKind;
    private static String failedKind;
    private PosMobVision() {}
    public static MobEntity mob(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null){clearModel();return null;}
        PosClient.Appearance appearance=PosClient.bodies.get(mc.player.getUuid());
        boolean possessed=appearance!=null&&appearance.mob()!=null;
        if(!possessed){clearModel();return null;}
        boolean combat=mc.currentScreen instanceof BattleScreen||LiveCombatClient.hudShown()||LiveCombatClient.moveLocked();
        boolean cinematic=OverhaulView.cameraActive()||LiveCamera.active()||PlayerActions.cameraActive()||DepthsClient.cameraActive()||DarkFountainSealEffect.cameraActive();
        if(!PosVisionRules.active(possessed,mc.options.getPerspective().isFirstPerson(),mc.getCameraEntity()==mc.player,
                mc.player.isAlive()&&!mc.player.isSpectator()&&!TurnBattleClientMod.clientSoulRemoved&&!SoulWalk.localOut,combat,cinematic)){
            // Keep the unspawned proxy while temporarily in third person/combat, but never keep a previous world/body.
            if(!possessed||world!=mc.world)clearModel();return null;
        }
        if(view==null||world!=mc.world||!appearance.mob().equals(type)||!appearance.bodyId().equals(body)){
            clearModel();Entity entity=Registries.ENTITY_TYPE.get(Identifier.of(appearance.mob())).create(mc.world);
            if(!(entity instanceof MobEntity mob))return null;
            view=mob;world=mc.world;type=appearance.mob();body=appearance.bodyId();
        }
        PosClient.applyMobLook(view,appearance.darknerLook());
        return view;
    }
    private static String kind(MobEntity mob){
        if(mob instanceof CreeperEntity)return "creeper";
        if(mob instanceof SpiderEntity)return "spider";
        if(mob instanceof EndermanEntity)return "enderman";
        return null;
    }
    public static void frame(GameRenderer renderer){
        MobEntity mob=mob();String wanted=kind(mob);
        if(wanted==null){release(renderer);failedKind=null;return;}
        if(wanted.equals(effectKind)&&ownedEffect!=null&&renderer.getPostProcessor()==ownedEffect)return;
        release(renderer);
        // Do not close or replace a shader owned by Minecraft's current camera or another mod.
        if(renderer.getPostProcessor()!=null||wanted.equals(failedKind))return;
        renderer.onCameraEntitySet(mob);
        ownedEffect=renderer.getPostProcessor();effectKind=ownedEffect!=null?wanted:null;
        failedKind=ownedEffect==null?wanted:null;
    }
    private static void release(GameRenderer renderer){
        if(ownedEffect!=null&&renderer.getPostProcessor()==ownedEffect)renderer.disablePostProcessor();
        ownedEffect=null;effectKind=null;
    }
    private static void clearModel(){view=null;world=null;type=null;body=null;}
    public static void reset(){release(MinecraftClient.getInstance().gameRenderer);clearModel();failedKind=null;}
    public static float eyeHeight(MobEntity mob){return mob.getEyeHeight(EntityPose.STANDING);}
}
