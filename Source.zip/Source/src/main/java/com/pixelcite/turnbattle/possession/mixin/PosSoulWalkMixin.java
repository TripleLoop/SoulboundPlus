package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(value=SoulWalk.class,remap=false)
public abstract class PosSoulWalkMixin {
    @Redirect(method="returnToBody",at=@At(value="INVOKE",target="Lcom/pixelcite/turnbattle/Net121;sendToClient(Lnet/minecraft/server/network/ServerPlayerEntity;Lnet/minecraft/util/Identifier;Lnet/minecraft/network/PacketByteBuf;)V",remap=true))
    private static void possession$coloredEntry(ServerPlayerEntity receiver,net.minecraft.util.Identifier channel,net.minecraft.network.PacketByteBuf data){
        if(!PosManager.internalReturn()||!channel.equals(SoulWalk.GRAZE))Net121.sendToClient(receiver,channel,data);
    }
    @Inject(method="tryLeave",at=@At("HEAD"),cancellable=true)
    private static void possession$exit(ServerPlayerEntity p,CallbackInfoReturnable<Boolean> cir){if(PosManager.busy(p.getUuid())){PosManager.message(p,"Finish the possession struggle first.");cir.setReturnValue(false);}else if(PosManager.exitKey(p))cir.setReturnValue(false);}
    @Inject(method="tryLeave",at=@At("RETURN"))
    private static void possession$capture(ServerPlayerEntity p,CallbackInfoReturnable<Boolean> cir){if(cir.getReturnValue())PosManager.left(p);}
    @Inject(method="returnToBody",at=@At("HEAD"),cancellable=true)
    private static void possession$return(ServerPlayerEntity p,boolean graze,CallbackInfo ci){if(PosManager.returnOwn(p,graze))ci.cancel();}
    @Inject(method="tick",at=@At("HEAD"),cancellable=true)
    private static void possession$tick(MinecraftServer s,CallbackInfo ci){PosManager.soulTick(s);ci.cancel();}
    @Inject(method="bodyWanted",at=@At("HEAD"),cancellable=true)
    private static void possession$bodyWanted(SoulBodyEntity body,CallbackInfoReturnable<Boolean> cir){
        if(PosManager.bodyWanted(body))cir.setReturnValue(true);
    }
    @Inject(method="onDisconnect",at=@At("HEAD"))
    private static void possession$disconnect(ServerPlayerEntity p,CallbackInfo ci){PosManager.disconnect(p);}
    @Inject(method="onJoin",at=@At("HEAD"))
    private static void possession$join(ServerPlayerEntity p,CallbackInfo ci){PosManager.recover(p);}
    @Inject(method="onRespawn",at=@At("HEAD"))
    private static void possession$respawn(ServerPlayerEntity p,CallbackInfo ci){PosManager.respawn(p);}
}
