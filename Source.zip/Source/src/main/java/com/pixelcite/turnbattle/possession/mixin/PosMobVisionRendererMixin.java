package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosMobVision;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public abstract class PosMobVisionRendererMixin {
    @Inject(method="renderHand",at=@At("HEAD"),cancellable=true)
    private void plus$mobHands(CallbackInfo ci){if(PosMobVision.mob()!=null)ci.cancel();}
    @Inject(method="render",at=@At("HEAD"))
    private void plus$mobVision(CallbackInfo ci){PosMobVision.frame((GameRenderer)(Object)this);}
}
