package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import java.util.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=ActionSkill.class,remap=false)
public abstract class PosActionRollMixin {
    @Inject(method={"roll","rollScaled"},at=@At("HEAD"),cancellable=true)
    private void plus$roll(Random random,CallbackInfoReturnable<Integer> c){BattleSkill s=(BattleSkill)(Object)this;int lo=s.getMinVal(),hi=s.getMaxVal();c.setReturnValue(lo>=hi?lo:lo+random.nextInt(hi-lo+1));}
}
