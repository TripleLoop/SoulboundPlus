package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.PosManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(PlayerEntity.class)
public abstract class PosSoulDropMixin {
    @Inject(method="dropItem(Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/ItemEntity;",at=@At("RETURN"))
    private void plus$bodyDrop(ItemStack stack,boolean random,boolean retainOwnership,CallbackInfoReturnable<ItemEntity> c){if((Object)this instanceof ServerPlayerEntity p)PosManager.soulDrop(p,c.getReturnValue());}
}
