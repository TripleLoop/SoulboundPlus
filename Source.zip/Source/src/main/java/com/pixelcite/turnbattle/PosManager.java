package com.pixelcite.turnbattle;

import net.minecraft.entity.*;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.*;
import net.minecraft.world.GameRules;
import net.minecraft.util.collection.DefaultedList;
import java.util.*;

/** All possession transitions run on the server thread. Inventory has exactly one active holder. */
public final class PosManager {
    static final Map<UUID,Anchor> anchors=new HashMap<>();
    static final Map<UUID,Session> sessions=new HashMap<>();
    static final Map<UUID,Contest> contests=new HashMap<>(); // logical body -> one challenger
    static final Map<String,Long> cooldowns=new HashMap<>();
    private static final Set<UUID> dying=new HashSet<>();
    private static final Map<UUID,Long> notices=new HashMap<>();
    private static boolean internal;
    public static boolean internalReturn(){return internal;}
    static final class Anchor {
        final UUID owner;
        final SoulWalk.Out out;
        final DefaultedList<ItemStack> items=DefaultedList.ofSize(41,ItemStack.EMPTY);
        int selected;
        net.minecraft.nbt.NbtCompound accessories=new net.minecraft.nbt.NbtCompound();
        UUID accessoryHolder;
        Anchor(UUID owner,SoulWalk.Out out){this.owner=owner;this.out=out;}
    }
    static final class Session {
        final UUID soul,body,owner;
        MobEntity mob;
        final float entryHp;
        final boolean oldAi,oldInvisible,oldInvulnerable;
        final long expires,started;
        int suppressedNetworkId=-1,visualStage;
        net.minecraft.nbt.NbtCompound accessories=new net.minecraft.nbt.NbtCompound();
        Session(UUID soul,UUID body,UUID owner,MobEntity mob,long expires,long started){
            this.started=started;this.soul=soul;this.body=body;this.owner=owner;this.mob=mob;this.expires=expires;
            entryHp=mob!=null?mob.getHealth():0;
            oldAi=mob!=null&&mob.isAiDisabled();oldInvisible=mob!=null&&mob.isInvisible();oldInvulnerable=mob!=null&&mob.isInvulnerable();
        }
    }
    static final class Contest {
        final UUID challenger,occupant,body,owner;
        final long end,began;
        final Vec3d start;
        Contest(UUID c,UUID o,UUID b,UUID owner,long began,long end,Vec3d start){this.began=began;challenger=c;occupant=o;body=b;this.owner=owner;this.end=end;this.start=start;}
    }
    private PosManager(){}
    static Map<UUID,SoulWalk.Out> out(){return PosBridge.out();}
    static long now(MinecraftServer s){return s.getOverworld().getTime();}
    // Network IDs are used by Soulbound's nearby-enemy collection; UUIDs are used by clients.
    public static final Set<UUID> CLIENT_BACKING=java.util.concurrent.ConcurrentHashMap.newKeySet();
    public static final Set<UUID> CLIENT_OCCUPIED_OWNERS=java.util.concurrent.ConcurrentHashMap.newKeySet();
    public static boolean isSuppressedEntity(Entity e){
        if(e==null||e.getWorld()==null||e instanceof net.minecraft.entity.player.PlayerEntity)return false;
        if(e.getWorld().isClient){
            if(e instanceof SoulBodyEntity body)return body.getOwner()!=null&&CLIENT_OCCUPIED_OWNERS.contains(body.getOwner());
            return CLIENT_BACKING.contains(e.getUuid());
        }
        if(e instanceof SoulBodyEntity body)return body.getOwner()!=null&&occupant(body.getOwner())!=null;
        for(Session ss:sessions.values())if(ss.mob!=null&&ss.body.equals(e.getUuid()))return true;
        return false;
    }
    public static boolean isCombatExcluded(Entity e){return e instanceof PosDummyEntity||isSuppressedEntity(e);}
    static void suppressMob(Session ss){
        MobEntity mob=ss.mob;if(mob==null)return;
        if(ss.suppressedNetworkId>=0&&ss.suppressedNetworkId!=mob.getId())BattleManager.frozenEntityIds.remove(ss.suppressedNetworkId);
        ss.suppressedNetworkId=mob.getId();BattleManager.frozenEntityIds.add(mob.getId());
        mob.setAiDisabled(true);mob.setTarget(null);mob.getNavigation().stop();mob.setInvisible(true);mob.setInvulnerable(true);mob.setVelocity(Vec3d.ZERO);
    }
    public static boolean possessing(UUID id){return sessions.containsKey(id);}
    static ServerPlayerEntity player(MinecraftServer s,UUID id){return id==null?null:s.getPlayerManager().getPlayer(id);}
    static Session occupant(UUID body){for(Session p:sessions.values())if(p.body.equals(body))return p;return null;}
    public static void message(ServerPlayerEntity p,String text){
        if(p==null)return;long n=now(p.getServer());if(notices.getOrDefault(p.getUuid(),-100L)+20>n)return;
        notices.put(p.getUuid(),n);p.sendMessage(Text.literal(text),true);
    }
    static void inventoryTo(ServerPlayerEntity p,Anchor a){
        for(int i=0;i<41;i++)a.items.set(i,p.getInventory().getStack(i).copy());
        a.selected=p.getInventory().selectedSlot;
    }
    static void inventoryFrom(Anchor a,ServerPlayerEntity p){
        p.getInventory().clear();
        for(int i=0;i<41;i++)p.getInventory().setStack(i,a.items.get(i).copy());
        p.getInventory().selectedSlot=Math.clamp(a.selected,0,8);
        p.currentScreenHandler.sendContentUpdates();
    }
    static void stashSoulItems(ServerPlayerEntity soul,Anchor anchor){
        if(!SoulWalk.isOut(soul)||possessing(soul.getUuid()))return;
        Session host=occupant(anchor.owner);ServerPlayerEntity holder=host!=null?player(soul.getServer(),host.soul):null;
        for(int i=0;i<41;i++){
            ItemStack incoming=soul.getInventory().getStack(i);if(incoming.isEmpty()||PosBodyGear.keepOnSoul(soul,anchor,incoming))continue;
            soul.getInventory().setStack(i,ItemStack.EMPTY);
            if(holder!=null){holder.getInventory().insertStack(incoming);inventoryTo(holder,anchor);holder.currentScreenHandler.sendContentUpdates();}
            else{
                for(int j=0;j<36&&!incoming.isEmpty();j++){ItemStack stored=anchor.items.get(j);if(!stored.isEmpty()&&ItemStack.areItemsAndComponentsEqual(stored,incoming)){int n=Math.min(incoming.getCount(),Math.max(0,stored.getMaxCount()-stored.getCount()));stored.increment(n);incoming.decrement(n);}}
                for(int j=0;j<36&&!incoming.isEmpty();j++)if(anchor.items.get(j).isEmpty()){anchor.items.set(j,incoming.copy());incoming.setCount(0);}
            }
            if(!incoming.isEmpty()){ServerWorld w=soul.getServer().getWorld(anchor.out.dim);if(w!=null)w.spawnEntity(new net.minecraft.entity.ItemEntity(w,anchor.out.pos.x,anchor.out.pos.y+0.5,anchor.out.pos.z,incoming));}
        }
        soul.currentScreenHandler.sendContentUpdates();
    }
    public static void left(ServerPlayerEntity p){
        if(internal)return;
        SoulWalk.Out o=out().get(p.getUuid());
        if(o==null||anchors.containsKey(p.getUuid()))return;
        PosBodyGear.close(p);
        Anchor a=new Anchor(p.getUuid(),o);inventoryTo(p,a);anchors.put(p.getUuid(),a);
        p.getInventory().clear();p.currentScreenHandler.sendContentUpdates();
        SoulBodyEntity body=body(p.getServer(),a);
        if(body!=null){body.setInvulnerable(false);body.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(p.getMaxHealth());body.setHealth(p.getHealth());}
        PosBodyGear.left(p,a);
        PosJournal.save(p.getServer());
    }
    static SoulBodyEntity body(MinecraftServer s,Anchor a){
        ServerWorld w=s.getWorld(a.out.dim);
        Entity e=w!=null&&a.out.bodyId!=null?w.getEntity(a.out.bodyId):null;
        return e instanceof SoulBodyEntity b?b:null;
    }
    static Anchor forceLeave(ServerPlayerEntity p){
        Anchor existing=anchors.get(p.getUuid());if(existing!=null)return existing;
        SoulWalk.Out o=new SoulWalk.Out();o.dim=p.getWorld().getRegistryKey();o.pos=p.getPos();o.yaw=p.getYaw();o.pitch=p.getPitch();
        o.since=now(p.getServer());o.leftBody=false;o.soul=BattleData.get(p.getServer()).getOrCreate(p.getUuid()).soulType;
        out().put(p.getUuid(),o);
        PosBridge.spawn(p,o);
        left(p);
        BattleData.PlayerProgress prog=BattleData.get(p.getServer()).getOrCreate(p.getUuid());
        prog.soulOutDim=o.dim.getValue().toString();prog.soulOutX=o.pos.x;prog.soulOutY=o.pos.y;prog.soulOutZ=o.pos.z;prog.soulOutYaw=o.yaw;prog.soulOutPitch=o.pitch;
        BattleData.get(p.getServer()).markDirty();
        fly(p);p.teleport(p.getServerWorld(),p.getX()+1.7,p.getY()+1,p.getZ(),p.getYaw(),p.getPitch());
        PosBridge.sync(p.getServer());
        return anchors.get(p.getUuid());
    }
    static void fly(ServerPlayerEntity p){p.getAbilities().allowFlying=true;p.getAbilities().flying=true;p.sendAbilitiesUpdate();p.fallDistance=0;}
    static boolean cooling(ServerPlayerEntity p,UUID b){
        long left=cooldowns.getOrDefault(p.getUuid()+":"+b,0L)-now(p.getServer());
        if(left<=0)return false;message(p,"Possession cooldown: "+((left+19)/20)+"s");return true;
    }
    static void cooldown(MinecraftServer s,UUID soul,UUID body){if(soul!=null)cooldowns.put(soul+":"+body,now(s)+Math.round(PosConfig.get("cooldown")*20));}
    static void markBoth(MinecraftServer s,Contest c){cooldown(s,c.challenger,c.body);cooldown(s,c.occupant,c.body);}
    public static boolean busy(UUID soul){if(PosDummies.busy(soul))return true;for(Contest c:contests.values())if(c.challenger.equals(soul)||c.occupant.equals(soul))return true;return false;}
    static UUID ownerFor(Entity e){
        if(e instanceof SoulBodyEntity b)return b.getOwner();
        if(e instanceof ServerPlayerEntity p){Session ss=sessions.get(p.getUuid());return ss!=null?ss.owner:p.getUuid();}
        return null;
    }
    static UUID keyFor(Entity e){
        if(e instanceof ServerPlayerEntity p){Session ss=sessions.get(p.getUuid());if(ss!=null)return ss.body;}
        UUID owner=ownerFor(e);return owner!=null?owner:e.getUuid();
    }
    static boolean excludedType(Class<?> type){
        return SoulBodyEntity.class.isAssignableFrom(type)||PassiveEntity.class.isAssignableFrom(type)||MirrorCloneEntity.class.isAssignableFrom(type)
            ||DarknerBossEntity.class.isAssignableFrom(type)||Shopkeeper.Entity.class.isAssignableFrom(type);
    }
    public static boolean eligible(MobEntity mob){
        return !excludedType(mob.getClass())
            &&mob.isAlive()&&!mob.hasVehicle()&&!mob.hasPassengers()
            &&!(mob.getCustomName()!=null&&mob.getCustomName().getString().contains(" BOSS]"))&&!EliteMobManager.isElite(mob.getUuid())&&!PosBridge.boss(mob);
    }
    public static void attempt(ServerPlayerEntity p,Entity target){
        if(!PosConfig.on("enabled")||!p.isAlive()||!SoulWalk.isOut(p)||possessing(p.getUuid()))return;
        if(BattleManager.isInBattle(p.getUuid())||busy(p.getUuid())||p.hasVehicle())return;
        UUID owner=ownerFor(target),key=keyFor(target);
        if(cooling(p,key)||contests.containsKey(key))return;
        if(target instanceof PosDummyEntity dummy){if(PosConfig.on("players")&&(dummy.kind()!=PosDummyEntity.Kind.MONSTER||PosConfig.on("monsters")))PosDummies.challenge(p,dummy);return;}
        if(target instanceof ServerPlayerEntity controller){
            Session held=sessions.get(controller.getUuid());
            if(held!=null&&held.owner==null){
                boolean dummy=held.mob instanceof PosDummyEntity;
                if(PosConfig.on(dummy?"players":"mobs")&&!BattleManager.isInBattle(controller.getUuid())&&!busy(controller.getUuid())){
                    if(held.mob instanceof PosDummyEntity d&&d.kind()==PosDummyEntity.Kind.MONSTER){if(PosConfig.on("monsters")){exit(controller,false,true);enterMob(p,d);}}
                    else beginContest(p,controller,key,null);
                }
                return;
            }
        }
        if(owner!=null&&owner.equals(p.getUuid())){
            Anchor a=anchors.get(p.getUuid());
            if(a!=null&&PosRules.canProximityEnter(true,a.out.leftBody,now(p.getServer())-a.out.since))returnOwn(p,false);
            return;
        }
        if(owner!=null){
            ServerPlayerEntity original=player(p.getServer(),owner);if(original==null||!original.isAlive()||!PosConfig.on("players"))return;
            if(BattleManager.isInBattle(owner))return;
            Session current=occupant(key);
            ServerPlayerEntity holder=current!=null?player(p.getServer(),current.soul):(!SoulWalk.isOut(original)&&!possessing(owner)?original:null);
            if(holder!=null&&BattleManager.isInBattle(holder.getUuid()))return;
            if(BattleData.get(p.getServer()).getOrCreate(owner).playerRace==CharacterRace.MONSTER){
                if(!PosConfig.on("monsters"))return;
                enterPlayer(p,owner,true);return;
            }
            if(holder==null){enterPlayer(p,owner,false);return;}
            beginContest(p,holder,owner);
        }else if(target instanceof MobEntity m&&PosConfig.on("mobs")&&eligible(m)&&occupant(key)==null&&!BattleManager.isMobInBattle(m.getId())){
            enterMob(p,m);
        }
    }
    static void beginContest(ServerPlayerEntity challenger,ServerPlayerEntity holder,UUID owner){beginContest(challenger,holder,owner,owner);}
    static void beginContest(ServerPlayerEntity challenger,ServerPlayerEntity holder,UUID body,UUID owner){
        if(busy(holder.getUuid()))return;
        MinecraftServer s=challenger.getServer();
        double seconds=PosConfig.get("struggle");
        Contest c=new Contest(challenger.getUuid(),holder.getUuid(),body,owner,now(s),now(s)+Math.max(1,Math.round(seconds*20)),holder.getPos());
        contests.put(body,c);challenger.setVelocity(Vec3d.ZERO);holder.setVelocity(Vec3d.ZERO);
        message(challenger,"Struggling for control...");message(holder,"A soul is fighting for your body!");
        PosNet.sync(s);
    }
    static void resolve(MinecraftServer s,Contest c){
        contests.remove(c.body);markBoth(s,c);
        ServerPlayerEntity a=player(s,c.challenger),b=player(s,c.occupant);
        if(a==null||b==null||!a.isAlive()||!b.isAlive())return;
        if(BattleManager.isInBattle(a.getUuid())||BattleManager.isInBattle(b.getUuid())){ejectChallenger(a,b,c);return;}
        BattleData d=BattleData.get(s);
        int al=d.getOrCreate(a.getUuid()).level,bl=d.getOrCreate(b.getUuid()).level;
        boolean challengerIsOwner=c.owner!=null&&c.owner.equals(a.getUuid());
        double bias=(challengerIsOwner||(c.owner!=null&&c.owner.equals(b.getUuid())))?PosConfig.get("ownerBonus")/100.0:0.5;
        double chance=challengerIsOwner?1-PosRules.invaderChance(bl,al,(int)PosConfig.get("levelGap"),bias)
            :PosRules.invaderChance(al,bl,(int)PosConfig.get("levelGap"),bias);
        if(s.getOverworld().random.nextDouble()<chance){
            Session ss=sessions.get(b.getUuid());MobEntity released=ss!=null?ss.mob:null;if(ss!=null)exit(b,false,true);else forceLeave(b);
            if(challengerIsOwner)restoreNow(a);else if(c.owner!=null)enterPlayer(a,c.owner,false);else if(released!=null)enterMob(a,released);
            PosNet.effect(s,c.body,b.getPos().subtract(a.getPos()),PosNet.soul(b));
            push(b,a.getPos());message(a,"You won control of the body.");message(b,"Your soul was ejected.");
        }else ejectChallenger(a,b,c);
    }
    static void ejectChallenger(ServerPlayerEntity a,ServerPlayerEntity b,Contest c){
        push(a,b.getPos());PosNet.effect(a.getServer(),c.body,a.getPos().subtract(b.getPos()),PosNet.soul(a));message(a,"Your soul was ejected.");
    }
    static void push(ServerPlayerEntity p,Vec3d from){
        Vec3d v=p.getPos().subtract(from);if(v.horizontalLengthSquared()<0.01)v=new Vec3d(1,0,0);
        v=v.normalize().multiply(1.8);p.teleport(p.getServerWorld(),from.x+v.x,from.y+0.8,from.z+v.z,p.getYaw(),p.getPitch());p.setVelocity(v.multiply(0.2));
        Anchor a=anchors.get(p.getUuid());if(a!=null){a.out.since=now(p.getServer());a.out.leftBody=false;}
    }
    static void enterPlayer(ServerPlayerEntity p,UUID owner,boolean monster){
        MinecraftServer s=p.getServer();ServerPlayerEntity original=player(s,owner);if(original==null)return;
        Session prior=occupant(owner);
        if(prior!=null){ServerPlayerEntity old=player(s,prior.soul);if(old!=null)exit(old,false,true);}
        boolean displacedNative=!anchors.containsKey(owner);
        Anchor target=anchors.get(owner);if(target==null)target=forceLeave(original);
        SoulBodyEntity body=body(s,target);if(body==null)return;
        if(!PosBodyGear.takePlayerBody(p,target))return;
        Vec3d pos=body.getPos();float yaw=body.getYaw();
        long expiry=monster?now(s)+PosRules.durationTicks(PosConfig.get("monsterBase"),PosConfig.get("soulReduction"),BattleData.get(s).getOrCreate(owner).absorbedSouls.size(),PosConfig.get("minimum")):Long.MAX_VALUE;
        sessions.put(p.getUuid(),new Session(p.getUuid(),owner,owner,null,expiry,now(s)));out().remove(p.getUuid());
        inventoryFrom(target,p);PosBridge.restore(p);
        p.teleport((ServerWorld)body.getWorld(),pos.x,pos.y,pos.z,yaw,0);body.setInvisible(true);body.setInvulnerable(true);stopMotion(p);
        if(displacedNative)PosNet.effect(s,owner,original.getPos().subtract(pos),PosNet.soul(original));
        PosBridge.sync(s);PosNet.sync(s);PosNet.entry(p);PosJournal.save(s);
    }
    static void enterMob(ServerPlayerEntity p,MobEntity mob){
        MinecraftServer s=p.getServer();long expiry=PosConfig.on("mobTimer")?now(s)+Math.max(1,Math.round(20*PosConfig.get("monsterBase")*PosConfig.get("mobMultiplier"))):Long.MAX_VALUE;
        if(mob instanceof PosDummyEntity dummy){long duration=PosDummies.duration(dummy);expiry=duration==Long.MAX_VALUE?Long.MAX_VALUE:now(s)+duration;}
        Session ss=new Session(p.getUuid(),mob.getUuid(),null,mob,expiry,now(s));if(!PosBodyGear.takeMobBody(p,mob,ss))return;sessions.put(p.getUuid(),ss);out().remove(p.getUuid());
        suppressMob(ss);
        p.getInventory().clear();for(EquipmentSlot slot:EquipmentSlot.values())if(slot.getType()==EquipmentSlot.Type.HUMANOID_ARMOR||slot.getType()==EquipmentSlot.Type.HAND)p.equipStack(slot,mob.getEquippedStack(slot).copy());
        PosBridge.restore(p);p.teleport((ServerWorld)mob.getWorld(),mob.getX(),mob.getY(),mob.getZ(),mob.getYaw(),0);stopMotion(p);
        PosBridge.sync(s);PosNet.sync(s);PosNet.entry(p);PosJournal.save(s);
    }
    static void stopMotion(ServerPlayerEntity p){
        p.setVelocity(Vec3d.ZERO);p.velocityModified=true;p.fallDistance=0;
        p.networkHandler.sendPacket(new net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket(p));
    }
    public static boolean exitKey(ServerPlayerEntity p){
        if(!possessing(p.getUuid()))return false;
        if(BattleManager.isInBattle(p.getUuid())||busy(p.getUuid())){message(p,"Finish the battle or struggle before leaving this body.");return true;}
        exit(p,false,true);return true;
    }
    static void exit(ServerPlayerEntity p,boolean soulDeath,boolean effect){
        if(busy(p.getUuid()))battleStarting(p);
        Session ss=sessions.remove(p.getUuid());if(ss==null)return;
        MinecraftServer s=p.getServer();Vec3d pos=p.getPos();
        PosBodyGear.release(p,ss);
        if(ss.suppressedNetworkId>=0)BattleManager.frozenEntityIds.remove(ss.suppressedNetworkId);
        if(ss.owner!=null){
            Anchor target=anchors.get(ss.owner);
            if(target!=null){
                inventoryTo(p,target);SoulBodyEntity b=moveBody(s,target,p);
                if(b!=null){b.setInvisible(false);b.setInvulnerable(false);copyEquipment(p,b);}
            }

        }else if(ss.mob!=null&&!ss.mob.isRemoved()){
            MobEntity m=ss.mob;m.refreshPositionAndAngles(pos.x,pos.y,pos.z,p.getYaw(),0);m.bodyYaw=p.bodyYaw;m.prevBodyYaw=p.bodyYaw;m.headYaw=p.headYaw;m.prevHeadYaw=p.headYaw;
            m.setAiDisabled(ss.oldAi);m.setInvisible(ss.oldInvisible);m.setInvulnerable(ss.oldInvulnerable);
            for(EquipmentSlot slot:EquipmentSlot.values())if(slot.getType()==EquipmentSlot.Type.HUMANOID_ARMOR||slot.getType()==EquipmentSlot.Type.HAND)m.equipStack(slot,p.getEquippedStack(slot).copy());
            // Non-equipment items acquired while controlling a mob are left at its body.
            for(int i=0;i<36;i++)if(i!=p.getInventory().selectedSlot){ItemStack stack=p.getInventory().getStack(i);if(!stack.isEmpty())m.dropStack(stack.copy());}
            if(soulDeath)m.setHealth(Math.max(0.01f,Math.min(m.getMaxHealth(),ss.entryHp*0.5f)));
        }
        p.getInventory().clear();p.currentScreenHandler.sendContentUpdates();
        Anchor own=anchors.get(p.getUuid());
        if(own!=null){out().put(p.getUuid(),own.out);own.out.leftBody=false;own.out.since=now(s);fly(p);if(!soulDeath)push(p,pos);}
        cooldown(s,p.getUuid(),ss.body);cooldown(s,ss.owner,ss.body);
        if(ss.owner!=null)PosBodyGear.resume(s,anchors.get(ss.owner));
        PosBodyGear.resume(s,anchors.get(p.getUuid()));
        if(effect)PosNet.effect(s,ss.body,p.getPos().subtract(pos),PosNet.soul(p));
        PosBridge.sync(s);PosNet.sync(s);PosJournal.save(s);
    }
    static void copyEquipment(ServerPlayerEntity p,SoulBodyEntity b){for(EquipmentSlot slot:EquipmentSlot.values())if(slot.getType()==EquipmentSlot.Type.HUMANOID_ARMOR||slot.getType()==EquipmentSlot.Type.HAND)b.equipStack(slot,p.getEquippedStack(slot).copy());}
    static SoulBodyEntity moveBody(MinecraftServer s,Anchor a,ServerPlayerEntity controller){
        SoulBodyEntity b=body(s,a);
        if(b!=null&&b.getWorld()!=controller.getWorld()){b.discard();b=null;}
        a.out.dim=controller.getWorld().getRegistryKey();a.out.pos=controller.getPos();a.out.yaw=controller.getYaw();
        if(b==null){ServerPlayerEntity owner=player(s,a.owner);if(owner!=null){PosBridge.spawn(owner,a.out);b=body(s,a);}}
        if(b!=null)b.refreshPositionAndAngles(controller.getX(),controller.getY(),controller.getZ(),controller.getYaw(),0);
        return b;
    }
    static void trackBody(MinecraftServer s,Anchor a){SoulBodyEntity b=body(s,a);if(b!=null){a.out.pos=b.getPos();a.out.dim=b.getWorld().getRegistryKey();a.out.yaw=b.getYaw();}}
    public static boolean returnOwn(ServerPlayerEntity p,boolean graze){
        if(internal)return false;
        Anchor own=anchors.get(p.getUuid());if(own==null)return false;
        if(BattleManager.isInBattle(p.getUuid())){message(p,"Finish the battle before returning.");return true;}
        if(possessing(p.getUuid())){exitKey(p);return true;}
        UUID key=p.getUuid();if(cooling(p,key)||busy(p.getUuid()))return true;
        Session current=occupant(key);
        if(current!=null){ServerPlayerEntity holder=player(p.getServer(),current.soul);if(holder!=null&&!BattleManager.isInBattle(holder.getUuid()))beginContest(p,holder,key);return true;}
        if(!PosAccessories.canApply(p,PosBodyGear.snapshot(p.getServer(),own))){message(p,"Restore your body accessory slot definitions before returning; its gear is stored safely.");return true;}
        PosBodyGear.suspend(p,own);stashSoulItems(p,own);trackBody(p.getServer(),own);inventoryFrom(own,p);PosAccessories.apply(p,own.accessories);anchors.remove(p.getUuid());
        internal=true;try{SoulWalk.returnToBody(p,graze);}finally{internal=false;}
        if(graze)PosNet.entry(p);
        PosJournal.save(p.getServer());return true;
    }
    public static void soulTick(MinecraftServer s){
        // Replaces the base proximity return loop so occupied bodies cannot bypass a contest.
        long n=now(s);
        for(var entry:new ArrayList<>(out().entrySet())){
            ServerPlayerEntity p=player(s,entry.getKey());if(p==null||!p.isAlive())continue;
            Anchor a=anchors.get(entry.getKey());if(a==null){left(p);a=anchors.get(entry.getKey());}if(a==null)continue;
            if(!p.getWorld().getRegistryKey().equals(a.out.dim)){returnOwn(p,false);continue;}
            stashSoulItems(p,a);PosBodyGear.tickSoul(p,a);fly(p);
            SoulBodyEntity b=body(s,a);
            Vec3d center=(b!=null?b.getPos():a.out.pos).add(0,1.15,0);
            double dist=p.getPos().add(0,0.25,0).distanceTo(center);
            if(dist>1.4)a.out.leftBody=true;
            if(PosRules.canProximityEnter(true,a.out.leftBody,n-a.out.since)&&dist<PosConfig.get("entryRadius")){returnOwn(p,true);continue;}
            if(!PosConfig.on("enabled")||n-a.out.since<=10||busy(p.getUuid()))continue;
            for(Entity target:p.getServerWorld().getOtherEntities(p,p.getBoundingBox().expand(2.5),e->e instanceof SoulBodyEntity||e instanceof ServerPlayerEntity||e instanceof MobEntity)){
                if(!target.isAlive()||(target.isSpectator()&&!(target instanceof PosDummyEntity)))continue;
                if(target instanceof ServerPlayerEntity q&&SoulWalk.isOut(q))continue;
                // Own-body re-entry is handled above, with the leave-and-return gate.
                // Including it here used to immediately undo a successful soul extraction.
                if(target instanceof SoulBodyEntity ownBody&&p.getUuid().equals(ownBody.getOwner()))continue;
                if(target instanceof SoulBodyEntity bb&&occupant(bb.getOwner())!=null)continue; // occupied body is represented by its controller
                double chest=target instanceof MobEntity&&!(target instanceof SoulBodyEntity)?Math.min(target.getHeight()*0.6,1.15):1.15;
                if(p.getPos().add(0,0.25,0).distanceTo(target.getPos().add(0,chest,0))<PosConfig.get("entryRadius")){attempt(p,target);if(!SoulWalk.isOut(p)||busy(p.getUuid()))break;}
            }
        }
    }
    public static void tick(MinecraftServer s){
        long n=now(s);PosDummies.tick(s);boolean visualChanged=false;
        for(Contest c:new ArrayList<>(contests.values())){
            ServerPlayerEntity a=player(s,c.challenger),b=player(s,c.occupant);
            if(a==null||b==null||!a.isAlive()||!b.isAlive()){contests.remove(c.body);markBoth(s,c);continue;}
            if(BattleManager.isInBattle(a.getUuid())||BattleManager.isInBattle(b.getUuid())){contests.remove(c.body);markBoth(s,c);ejectChallenger(a,b,c);continue;}
            a.setVelocity(Vec3d.ZERO);b.setVelocity(Vec3d.ZERO);
            PosBodyMotion.struggle(b,c.body,c.start,c.began,c.end,n);
            a.teleport(b.getServerWorld(),b.getX(),b.getY()+0.9,b.getZ(),a.getYaw(),a.getPitch());
            if(n>=c.end)resolve(s,c);
        }
        for(Session ss:new ArrayList<>(sessions.values())){
            ServerPlayerEntity p=player(s,ss.soul);if(p==null)continue;
            if(!PosConfig.on("enabled")||!PosConfig.on(ss.mob instanceof PosDummyEntity?"players":ss.owner==null?"mobs":"players")|| (ss.mob instanceof PosDummyEntity dummy&&dummy.kind()==PosDummyEntity.Kind.MONSTER&&!PosConfig.on("monsters"))||(ss.owner!=null&&BattleData.get(s).getOrCreate(ss.owner).playerRace==CharacterRace.MONSTER&&!PosConfig.on("monsters"))){exit(p,false,true);continue;}
            if(n>=ss.expires&&!BattleManager.isInBattle(ss.soul)){exit(p,false,true);continue;}
            int stage=PosRules.timerStage(n,ss.started,ss.expires);if(stage!=ss.visualStage){ss.visualStage=stage;visualChanged=true;}
            if(ss.owner!=null){Anchor a=anchors.get(ss.owner);if(a!=null){inventoryTo(p,a);SoulBodyEntity b=moveBody(s,a,p);if(b!=null){b.setInvisible(true);b.setInvulnerable(true);copyEquipment(p,b);}}}
            else if(ss.mob!=null){
                if(ss.mob.isRemoved()||!ss.mob.isAlive()){exit(p,false,true);continue;}
                if(ss.mob.getWorld()!=p.getWorld()){
                    ss.mob.teleport(p.getServerWorld(),p.getX(),p.getY(),p.getZ(),Set.of(),p.getYaw(),0);
                    Entity moved=p.getServerWorld().getEntity(ss.body);
                    if(moved instanceof MobEntity m)ss.mob=m;else{exit(p,false,true);continue;}
                }
                suppressMob(ss);ss.mob.refreshPositionAndAngles(p.getX(),p.getY(),p.getZ(),p.getYaw(),0);}
            
        }
        cooldowns.entrySet().removeIf(e->e.getValue()<=n);
        if(n%20==0){PosJournal.save(s);PosNet.sync(s);}else if(visualChanged)PosNet.sync(s);
    }
    public static void battleStarting(ServerPlayerEntity p){
        boolean changed=busy(p.getUuid());PosDummies.interrupt(p);
        for(Contest c:new ArrayList<>(contests.values()))if(c.occupant.equals(p.getUuid())||c.challenger.equals(p.getUuid())){
            contests.remove(c.body);markBoth(p.getServer(),c);
            ServerPlayerEntity a=player(p.getServer(),c.challenger),b=player(p.getServer(),c.occupant);if(a!=null&&b!=null)ejectChallenger(a,b,c);
        }
        if(changed)PosNet.sync(p.getServer());
    }
    public static boolean bodyDamage(SoulBodyEntity b,DamageSource source,float amount){
        if(b.getWorld().isClient)return false;
        UUID owner=b.getOwner();if(owner==null||occupant(owner)!=null||!b.isAlive())return false;
        float hp=b.getHealth()-Math.max(0,amount);b.setHealth(Math.max(0,hp));
        if(amount>0){ServerPlayerEntity p=player(b.getServer(),owner);if(p!=null&&p.isAlive())PosNet.bodyWarning(p);}
        if(hp<=0){ServerPlayerEntity p=player(b.getServer(),owner);if(p!=null&&p.isAlive())p.kill();}
        return amount>0;
    }
    public static void death(ServerPlayerEntity p){
        if(!dying.add(p.getUuid()))return;
        MinecraftServer s=p.getServer();
        boolean linkedBody=anchors.containsKey(p.getUuid())||possessing(p.getUuid());
        battleStarting(p);
        if(possessing(p.getUuid()))exit(p,true,false);
        Session guest=occupant(p.getUuid());if(guest!=null){ServerPlayerEntity q=player(s,guest.soul);if(q!=null)exit(q,false,true);}
        Anchor own=anchors.remove(p.getUuid());
        net.minecraft.nbt.NbtCompound deathAccessories=null;
        if(own!=null){
            PosBodyGear.suspend(p,own);stashSoulItems(p,own);trackBody(s,own);inventoryFrom(own,p);if(PosAccessories.canApply(p,own.accessories))PosAccessories.apply(p,own.accessories);else deathAccessories=own.accessories.copy();ServerWorld w=s.getWorld(own.out.dim);if(w!=null)p.teleport(w,own.out.pos.x,own.out.pos.y,own.out.pos.z,own.out.yaw,own.out.pitch);
            SoulBodyEntity b=body(s,own);if(b!=null)b.discard();out().remove(p.getUuid());
            BattleData.get(s).getOrCreate(p.getUuid()).soulOutDim=null;BattleData.get(s).markDirty();PosBridge.sync(s);
        }
        if(linkedBody)PosBodyGear.death(p,p.getWorld().getGameRules().getBoolean(GameRules.KEEP_INVENTORY),deathAccessories);
        if(!p.getWorld().getGameRules().getBoolean(GameRules.KEEP_INVENTORY)){
            // Drop before vanilla and Soulbound death hooks; their later inventory pass sees an empty inventory.
            p.getInventory().dropAll();
            BattleData.PlayerProgress progress=BattleData.get(s).getOrCreate(p.getUuid());
            if(progress.equippedWeapon!=null&&!progress.equippedWeapon.isEmpty())p.dropItem(progress.equippedWeapon.copy(),true,false);
            if(progress.equippedAccessory!=null&&!progress.equippedAccessory.isEmpty())p.dropItem(progress.equippedAccessory.copy(),true,false);
            progress.equippedWeapon=ItemStack.EMPTY;progress.equippedAccessory=ItemStack.EMPTY;
            if(progress.equippedArmor!=null)for(int i=0;i<progress.equippedArmor.length;i++){
                if(progress.equippedArmor[i]!=null&&!progress.equippedArmor[i].isEmpty())p.dropItem(progress.equippedArmor[i].copy(),true,false);
                progress.equippedArmor[i]=ItemStack.EMPTY;
            }
            BattleData.get(s).markDirty();
        }
        PosJournal.save(s);PosNet.sync(s);
    }
    public static void soulDrop(ServerPlayerEntity p,net.minecraft.entity.ItemEntity item){PosBodyGear.soulDrop(p,item);}
    public static void recover(ServerPlayerEntity p){PosJournal.recover(p);PosBodyGear.restoreKept(p);}
    public static boolean bodyWanted(SoulBodyEntity body){Anchor a=anchors.get(body.getOwner());return a!=null&&body.getUuid().equals(a.out.bodyId);}
    public static void respawn(ServerPlayerEntity p){dying.remove(p.getUuid());PosBodyGear.restoreKept(p);}
    public static void disconnect(ServerPlayerEntity p){
        MinecraftServer s=p.getServer();battleStarting(p);
        if(possessing(p.getUuid()))exit(p,false,false);
        Session guest=occupant(p.getUuid());if(guest!=null){ServerPlayerEntity q=player(s,guest.soul);if(q!=null){exit(q,false,true);restoreNow(q);}}
        restoreNow(p);
    }
    static void restoreNow(ServerPlayerEntity p){
        Anchor a=anchors.get(p.getUuid());if(a==null)return;
        if(!PosAccessories.canApply(p,PosBodyGear.snapshot(p.getServer(),a)))throw new IllegalStateException("Cannot restore body gear: restore its accessory slot definitions; recovery data retained");
        anchors.remove(p.getUuid());
        PosBodyGear.suspend(p,a);stashSoulItems(p,a);trackBody(p.getServer(),a);inventoryFrom(a,p);PosAccessories.apply(p,a.accessories);out().put(p.getUuid(),a.out);
        internal=true;try{SoulWalk.returnToBody(p,false);}finally{internal=false;}
        PosJournal.save(p.getServer());
    }
    public static void stop(MinecraftServer s){
        for(Session ss:new ArrayList<>(sessions.values())){ServerPlayerEntity p=player(s,ss.soul);if(p!=null)exit(p,false,false);}
        for(ServerPlayerEntity p:s.getPlayerManager().getPlayerList())restoreNow(p);
        PosJournal.save(s);
    }
    public static void clear(){PosNet.clear();PosDummies.challenges.clear();anchors.clear();sessions.clear();contests.clear();cooldowns.clear();dying.clear();notices.clear();PosBodyGear.kept.clear();CLIENT_BACKING.clear();CLIENT_OCCUPIED_OWNERS.clear();}
}
