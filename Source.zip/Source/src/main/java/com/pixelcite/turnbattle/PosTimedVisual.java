package com.pixelcite.turnbattle;

import java.util.*;

/** Additive client cues; never changes native reveal state, teams, or potion effects. */
public final class PosTimedVisual {
    public record Cue(SoulType soul,int stage,long started,long expires) {}
    private static final Map<UUID,Cue> cues=new HashMap<>();
    private PosTimedVisual() {}
    public static void accept(Map<UUID,Cue> next){cues.clear();cues.putAll(next);}
    public static boolean revealed(Object id){Cue c=cues.get(id);return c!=null&&c.stage>=1;}
    public static Cue cue(java.util.UUID id){return cues.get(id);}
    public static boolean glowing(UUID id){Cue c=cues.get(id);return c!=null&&c.stage>=2;}
    public static SoulType soul(Object id,SoulType fallback){Cue c=cues.get(id);return c==null?fallback:c.soul;}
}
