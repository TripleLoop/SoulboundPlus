package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value={PsiSkill.class,LightnerSkill.class,HumanMageSkill.class,MonsterSkill.class,SoulMageSkill.class,OriSkill.class,VesselActionSkill.class,ActionSkill.class},remap=false)
public abstract class PosSkillValuesMixin {
    @Inject(method="getTpCost",at=@At("RETURN"),cancellable=true)
    private void plus$tp(CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value((BattleSkill)(Object)this,1,c.getReturnValue()));}
    @Inject(method="getLevelRequired",at=@At("RETURN"),cancellable=true)
    private void plus$level(CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value((BattleSkill)(Object)this,2,c.getReturnValue()));}
    @Inject(method="getMinVal",at=@At("RETURN"),cancellable=true)
    private void plus$min(CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value((BattleSkill)(Object)this,3,c.getReturnValue()));}
    @Inject(method="getMaxVal",at=@At("RETURN"),cancellable=true)
    private void plus$max(CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value((BattleSkill)(Object)this,4,c.getReturnValue()));}
    @Inject(method="getExtra",at=@At("RETURN"),cancellable=true)
    private void plus$extra(CallbackInfoReturnable<Integer> c){c.setReturnValue(PosSkillBalance.value((BattleSkill)(Object)this,5,c.getReturnValue()));}
}
