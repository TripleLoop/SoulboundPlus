package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=MonsterSkill.class,remap=false)
public abstract class PosMonsterSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILjava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/MonsterSkill;lv:I"))
    private static int plus$level(MonsterSkill skill){return skill.getLevelRequired();}
}
