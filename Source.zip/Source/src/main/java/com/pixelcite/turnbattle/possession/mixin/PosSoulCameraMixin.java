package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=PlayerActions.class,remap=false)
public abstract class PosSoulCameraMixin {
    @Inject(method="cameraActive",at=@At("HEAD"),cancellable=true)
    private static void plus$freeSoulCamera(CallbackInfoReturnable<Boolean> cir){if(PosNativeSoulPose.localSoulAction())cir.setReturnValue(false);}
    @Inject(method="localLocked",at=@At("HEAD"),cancellable=true)
    private static void plus$freeSoulLook(CallbackInfoReturnable<Boolean> cir){if(PosSoulCamera.looking&&PosNativeSoulPose.localSoulAction())cir.setReturnValue(false);}
}
