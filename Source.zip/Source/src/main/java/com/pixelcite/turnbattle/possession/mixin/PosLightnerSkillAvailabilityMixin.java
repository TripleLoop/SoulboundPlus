package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=LightnerSkill.class,remap=false)
public abstract class PosLightnerSkillAvailabilityMixin {
    @Redirect(method="getAvailable(ILjava/util/Set;)Ljava/util/List;",at=@At(value="FIELD",target="Lcom/pixelcite/turnbattle/LightnerSkill;lv:I"))
    private static int plus$level(LightnerSkill skill){return skill.getLevelRequired();}
}
