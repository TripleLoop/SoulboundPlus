package com.pixelcite.turnbattle.possession.mixin;

import com.pixelcite.turnbattle.PosGloves;
import com.pixelcite.turnbattle.PosShoes;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemFeatureRenderer.class)
public abstract class PosGloveFeatureMixin {
    @Inject(method="render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V",at=@At("HEAD"))
    private void plus$glovePair(MatrixStack matrices,VertexConsumerProvider vertices,int light,LivingEntity entity,float limbAngle,float limbDistance,float delta,float animation,float yaw,float pitch,CallbackInfo ci){
        Object model=((HeldItemFeatureRenderer<?,?>)(Object)this).getContextModel();
        if(model instanceof BipedEntityModel<?> biped&&(PosGloves.equipped(entity)||PosShoes.equipped(entity))){
            matrices.push();
            // Match vanilla's child-model feature transform before following the arm poses.
            if(biped.child){matrices.translate(0,0.75,0);matrices.scale(0.5f,0.5f,0.5f);}
            if(PosGloves.equipped(entity))PosGloves.renderBoth(biped,entity,matrices,vertices,light);
            if(PosShoes.equipped(entity))PosShoes.renderBoth(biped,entity,matrices,vertices,light);
            matrices.pop();
        }
    }
    @Inject(method="renderItem",at=@At("HEAD"),cancellable=true)
    private void plus$gloves(LivingEntity entity,ItemStack stack,ModelTransformationMode mode,Arm side,MatrixStack matrices,VertexConsumerProvider vertices,int light,CallbackInfo ci){
        if(!PosGloves.matches(stack)&&!PosShoes.matches(stack))return;
        Object model=((HeldItemFeatureRenderer<?,?>)(Object)this).getContextModel();
        if(!(model instanceof BipedEntityModel<?> biped))return;
        // The feature-level hook draws one pair regardless of how many slots contain gloves.
        ci.cancel();
    }
}
