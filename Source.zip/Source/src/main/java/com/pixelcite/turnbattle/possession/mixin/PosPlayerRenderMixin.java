package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(EntityRenderDispatcher.class)
public abstract class PosPlayerRenderMixin {
    @Inject(method="render",at=@At("HEAD"),cancellable=true)
    private <E extends Entity> void possession$model(E e,double x,double y,double z,float yaw,float delta,MatrixStack m,VertexConsumerProvider v,int light,CallbackInfo ci){
        if(PosManager.isSuppressedEntity(e)){ci.cancel();return;}
        m.push();m.translate(x,y,z);boolean replaced=PosClient.renderMob(e,yaw,delta,m,v,light);m.pop();if(replaced)ci.cancel();
    }
}
