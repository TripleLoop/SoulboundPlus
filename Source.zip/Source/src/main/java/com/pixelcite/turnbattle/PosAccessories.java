package com.pixelcite.turnbattle;

import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.registry.RegistryWrapper;
import java.lang.reflect.*;
import java.util.*;

/** Optional public APIs only: no Curios/Trinkets classes are linked on an installation without them. */
final class PosAccessories {
    private PosAccessories() {}
    private static final String CURIOS="top.theillusivec4.curios.api.CuriosApi",TRINKETS="dev.emi.trinkets.api.TrinketsApi";
    static Object call(Object target,String name,Object... args){
        Class<?> type=target instanceof Class<?> c?c:target.getClass();
        for(Method m:type.getMethods())if(m.getName().equals(name)&&m.getParameterCount()==args.length){
            Class<?>[] types=m.getParameterTypes();boolean match=true;for(int i=0;i<types.length;i++)if(args[i]!=null&&!types[i].isInstance(args[i])&&!(types[i]==int.class&&args[i] instanceof Integer)&&!(types[i]==boolean.class&&args[i] instanceof Boolean))match=false;
            if(!match)continue;
            try{return m.invoke(target instanceof Class<?>?null:target,args);}catch(ReflectiveOperationException e){throw new IllegalStateException("Accessory API failed: "+type.getName()+"."+name,e);}
        }
        throw new IllegalStateException("Unsupported accessory API: "+type.getName()+"."+name);
    }
    private static Object api(String name,String method,LivingEntity entity){
        try{return ((Optional<?>)call(Class.forName(name,false,PosAccessories.class.getClassLoader()),method,entity)).orElse(null);}
        catch(ClassNotFoundException e){return null;}
    }
    static final class Group {
        final String provider,key;final Object normal,cosmetic,parent,owner;
        Group(String provider,String key,Object normal,Object cosmetic,Object parent,Object owner){this.provider=provider;this.key=key;this.normal=normal;this.cosmetic=cosmetic;this.parent=parent;this.owner=owner;}
        int size(Object handler){return handler==null?0:handler instanceof Inventory inv?inv.size():(int)call(handler,"getSlots");}
        ItemStack get(Object handler,int slot){return handler instanceof Inventory inv?inv.getStack(slot):(ItemStack)call(handler,"getStackInSlot",slot);}
        void set(Object handler,int slot,ItemStack stack){if(handler instanceof Inventory inv){inv.setStack(slot,stack);inv.markDirty();}else call(handler,"setStackInSlot",slot,stack);}
        @SuppressWarnings("unchecked") List<Boolean> renders(){return provider.equals("curios")?(List<Boolean>)call(parent,"getRenders"):List.of();}

        @SuppressWarnings({"unchecked","rawtypes"}) void changed(){if(provider.equals("curios"))((Set)call(owner,"getUpdatingInventories")).add(parent);}
    }
    static List<Group> groups(LivingEntity entity){
        List<Group> out=new ArrayList<>();Object curios=api(CURIOS,"getCuriosInventory",entity);
        if(curios!=null){Map<?,?> map=(Map<?,?>)call(curios,"getCurios");for(var e:map.entrySet()){Object parent=e.getValue();out.add(new Group("curios",e.getKey().toString(),call(parent,"getStacks"),call(parent,"getCosmeticStacks"),parent,curios));}}
        Object trinkets=api(TRINKETS,"getTrinketComponent",entity);
        if(trinkets!=null){Map<?,?> map=(Map<?,?>)call(trinkets,"getInventory");for(var group:map.entrySet())for(var slot:((Map<?,?>)group.getValue()).entrySet()){
            if(!(slot.getValue() instanceof Inventory))throw new IllegalStateException("Unsupported Trinkets inventory");
            out.add(new Group("trinkets",group.getKey()+"/"+slot.getKey(),slot.getValue(),null,null,trinkets));
        }}return out;
    }
    static NbtCompound capture(LivingEntity entity,boolean clear){return capture(groups(entity),entity.getWorld().getRegistryManager(),clear);}
    static NbtCompound capture(List<Group> groups,RegistryWrapper.WrapperLookup registries,boolean clear){
        NbtCompound out=new NbtCompound();NbtList list=new NbtList();
        for(Group g:groups){NbtCompound data=new NbtCompound();data.putString("Provider",g.provider);data.putString("Key",g.key);data.putInt("Count",g.size(g.normal));
            data.put("Items",items(g,g.normal,registries));data.put("Cosmetics",items(g,g.cosmetic,registries));
            List<Boolean> renders=g.renders();byte[] states=new byte[renders.size()];for(int i=0;i<states.length;i++)states[i]=(byte)(renders.get(i)?1:0);data.putByteArray("Renders",states);list.add(data);
        }out.put("Groups",list);if(clear)clear(groups);return out;
    }
    private static NbtList items(Group g,Object handler,RegistryWrapper.WrapperLookup registries){
        NbtList list=new NbtList();for(int i=0;i<g.size(handler);i++){ItemStack stack=g.get(handler,i);if(stack.isEmpty())continue;NbtCompound data=new NbtCompound();data.putInt("Slot",i);data.put("Stack",stack.encode(registries));list.add(data);}return list;
    }
    static void clear(List<Group> groups){for(Group g:groups){boolean changed=false;for(Object h:new Object[]{g.normal,g.cosmetic})for(int i=0;i<g.size(h);i++)if(!g.get(h,i).isEmpty()){g.set(h,i,ItemStack.EMPTY);changed=true;}if(changed)g.changed();}}
    static boolean canApply(LivingEntity entity,NbtCompound data){return canApply(groups(entity),entity.getWorld().getRegistryManager(),data);}
    static boolean canApply(List<Group> groups,RegistryWrapper.WrapperLookup registries,NbtCompound data){
        Map<String,Group> slots=new HashMap<>();for(Group g:groups)slots.put(g.provider+":"+g.key,g);
        try{NbtList list=data.getList("Groups",10);for(int i=0;i<list.size();i++){NbtCompound row=list.getCompound(i);Group g=slots.get(row.getString("Provider")+":"+row.getString("Key"));
            boolean nonempty=!row.getList("Items",10).isEmpty()||!row.getList("Cosmetics",10).isEmpty();
            if(g==null){if(nonempty)return false;continue;}int count=row.getInt("Count");if(count<0||count>4096)return false;
            for(String key:new String[]{"Items","Cosmetics"}){NbtList items=row.getList(key,10);for(int j=0;j<items.size();j++){NbtCompound item=items.getCompound(j);int slot=item.getInt("Slot");if(slot<0||slot>=count||slot>=g.size(key.equals("Items")?g.normal:g.cosmetic)||ItemStack.fromNbt(registries,item.getCompound("Stack")).isEmpty())return false;if(key.equals("Cosmetics")&&g.cosmetic==null)return false;}}
        }return true;}catch(RuntimeException e){return false;}
    }
    static void apply(LivingEntity entity,NbtCompound data){apply(groups(entity),entity.getWorld().getRegistryManager(),data);}
    static void apply(List<Group> groups,RegistryWrapper.WrapperLookup registries,NbtCompound data){
        if(!canApply(groups,registries,data))throw new IllegalStateException("Body accessory slots are not supported by this player; original data retained");
        Map<String,Group> slots=new HashMap<>();for(Group g:groups)slots.put(g.provider+":"+g.key,g);
        clear(groups);NbtList list=data.getList("Groups",10);
        for(int i=0;i<list.size();i++){NbtCompound row=list.getCompound(i);Group g=slots.get(row.getString("Provider")+":"+row.getString("Key"));if(g==null)continue;
            // Native slot capacities remain server-controlled; preflight rejects overflow without changing either inventory.
            for(String key:new String[]{"Items","Cosmetics"}){Object handler=key.equals("Items")?g.normal:g.cosmetic;NbtList items=row.getList(key,10);for(int j=0;j<items.size();j++){NbtCompound item=items.getCompound(j);g.set(handler,item.getInt("Slot"),ItemStack.fromNbt(registries,item.getCompound("Stack")).orElseThrow());}}
            List<Boolean> renders=g.renders();byte[] states=row.getByteArray("Renders");for(int j=0;j<renders.size()&&j<states.length;j++)renders.set(j,states[j]!=0);g.changed();
        }
    }
    static List<ItemStack> stacks(NbtCompound data,RegistryWrapper.WrapperLookup registries){
        List<ItemStack> out=new ArrayList<>();NbtList groups=data.getList("Groups",10);for(int i=0;i<groups.size();i++)for(String key:new String[]{"Items","Cosmetics"}){NbtList items=groups.getCompound(i).getList(key,10);for(int j=0;j<items.size();j++)out.add(ItemStack.fromNbt(registries,items.getCompound(j).getCompound("Stack")).orElseThrow());}return out;
    }
}
