package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=BattleManager.class,remap=false)
public abstract class PosBattleMixin {
    @Inject(method="startNewBattle",at=@At("HEAD"),cancellable=true)
    private static void possession$battle(ServerPlayerEntity p,LivingEntity enemy,CallbackInfo ci){if(PosManager.isCombatExcluded(enemy)){ci.cancel();return;}PosManager.battleStarting(p);if(enemy instanceof ServerPlayerEntity q)PosManager.battleStarting(q);}
    @Inject(method={"tryStart","tryStartMobInitiated"},at=@At("HEAD"),cancellable=true)
    private static void possession$excludeBacking(ServerPlayerEntity p,LivingEntity enemy,CallbackInfo ci){if(PosManager.isCombatExcluded(enemy))ci.cancel();}
    @Inject(method="tryStartPvp",at=@At("RETURN"))
    private static void possession$pvp(ServerPlayerEntity p,ServerPlayerEntity q,CallbackInfo ci){if(BattleManager.isInBattle(p.getUuid())){PosManager.battleStarting(p);PosManager.battleStarting(q);}}
    @Inject(method={"tryStartVirtual","tryStartVirtualDark"},at=@At("RETURN"))
    private static void possession$virtual(ServerPlayerEntity p,String name,String type,float hp,float armor,CallbackInfo ci){if(BattleManager.isInBattle(p.getUuid()))PosManager.battleStarting(p);}
    @Inject(method="joinBattle",at=@At("RETURN"))
    private static void possession$join(ServerPlayerEntity p,BattleState state,CallbackInfo ci){if(BattleManager.isInBattle(p.getUuid()))PosManager.battleStarting(p);}
}

