package com.pixelcite.turnbattle.possession.mixin;
import net.minecraft.client.render.entity.model.AnimalModel;
import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(AnimalModel.class)
public interface PosAnimalAccess {
    @Invoker("getBodyParts") Iterable<ModelPart> possession$bodyParts();
}
