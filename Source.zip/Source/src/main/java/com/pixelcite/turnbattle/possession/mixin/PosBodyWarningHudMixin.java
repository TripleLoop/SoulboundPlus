package com.pixelcite.turnbattle.possession.mixin;

import com.pixelcite.turnbattle.PosBodyWarning;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class PosBodyWarningHudMixin {
    @Inject(method="renderHeldItemTooltip",at=@At("HEAD"),cancellable=true)
    private void plus$bodyWarning(DrawContext context,CallbackInfo ci){
        if(PosBodyWarning.render(context))ci.cancel();
    }
}
