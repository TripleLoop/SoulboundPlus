package com.pixelcite.turnbattle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import java.util.*;

/** A handle-only drag: normal row clicks still open the skill tree. Saves once, on drop. */
public final class PosSkillDrag {
    private List<BattleSkill> skills=List.of(),snapshot=List.of();
    private String actor="",dragActor="";
    private int x,y,width,visible,top,from=-1,to;
    private double mouseY;
    private long scrollAt;
    public boolean dragging(){return from>=0;}
    public void cancel(){from=-1;snapshot=List.of();}
    public int render(DrawContext ctx,Object member,List<BattleSkill> ordered,int x,int y,int width,int height,int scale,int top,int mx,int my,float alpha){
        if(!PosSkillOrder.supports(member)){cancel();skills=List.of();return top;}
        String nextActor=PosSkillOrder.actor(member);
        if(dragging()&&(!dragActor.equals(nextActor)||!snapshot.equals(ordered)))cancel();
        actor=nextActor;skills=List.copyOf(ordered);this.x=x;this.width=width;this.y=y+6+6*scale+8+8;
        int equipmentY=y+height-(6*scale+8+20+8);
        visible=Math.max(1,(equipmentY-12-this.y)/12);this.top=top;
        int colorAlpha=Math.clamp((int)(alpha*255),0,255)<<24;
        for(int k=0;k<visible&&top+k<skills.size();k++){
            int rowY=this.y+k*12;boolean hover=mx>=x+width-17&&mx<x+width-2&&my>=rowY-1&&my<rowY+11;
            int color=colorAlpha|((dragging()&&top+k==from)||hover?0xFFFF66:0xFFFFFF);
            for(int line=0;line<3;line++)ctx.fill(x+width-14,rowY+2+line*3,x+width-6,rowY+3+line*3,color);
            if(hover&&!dragging())ctx.drawTooltip(MinecraftClient.getInstance().textRenderer,Text.literal("Drag to change battle order"),mx,my);
        }
        if(dragging()){
            long now=System.nanoTime();int nextTop=top;
            if(now-scrollAt>120_000_000L){
                if(mouseY<this.y+3)nextTop=Math.max(0,top-1);
                else if(mouseY>this.y+visible*12-3)nextTop=Math.min(Math.max(0,skills.size()-visible),top+1);
                if(nextTop!=top)scrollAt=now;
            }
            to=target(mouseY,top);int line=Math.clamp(to-top+(to>from?1:0),0,visible);
            ctx.fill(x+8,this.y+line*12-1,x+width-4,this.y+line*12+1,colorAlpha|0xFFFF66);
            return nextTop;
        }
        return top;
    }
    private int target(double mouseY,int top){return Math.clamp(top+(int)Math.floor((mouseY-y)/12),0,Math.max(0,skills.size()-1));}
    public boolean click(double mx,double my,int button){
        if(dragging()){if(button!=0)cancel();return true;}
        if(button!=0||skills.isEmpty()||mx<x+width-17||mx>=x+width-2||my<y-1||my>=y+visible*12-1)return false;
        int index=top+(int)Math.floor((my-y+1)/12);if(index>=skills.size())return false;
        snapshot=skills;from=to=index;dragActor=actor;mouseY=my;scrollAt=System.nanoTime();return true;
    }
    public boolean drag(double my,int button){if(!dragging())return false;if(button==0){mouseY=my;to=target(my,top);}return true;}
    public boolean release(double my,int button){
        if(!dragging()||button!=0)return false;
        to=target(my,top);
        if(from!=to&&!PosSkillOrder.move(dragActor,snapshot,from,to)){
            var player=MinecraftClient.getInstance().player;if(player!=null)player.sendMessage(Text.literal("Could not save skill order. Check the client config file."),false);
        }
        cancel();return true;
    }
}
