package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=SettingsScreen.class,remap=false)
public abstract class PosSkillSettingsScreenMixin extends VoidMenuScreen {
    protected PosSkillSettingsScreenMixin(){super("",null);}
    @Inject(method="drawRow",at=@At("HEAD"),cancellable=true)
    private void plus$editButton(DrawContext ctx,@Coerce Object row,int index,int x,int y,int width,int clipTop,int clipBottom,int mx,int my,float alpha,CallbackInfoReturnable<Integer> cir){
        if(!PosSkillBalanceScreen.launcher(row))return;
        var font=MinecraftClient.getInstance().textRenderer;
        var lines=font.wrapLines(Text.literal("Edit server skill costs, required levels and effects."),width-4);
        int opacity=Math.clamp((int)(alpha*255),0,255)<<24;
        ctx.drawTextWithShadow(font,"Skill Balance",x,y+4,opacity|0xFFFFFF);
        int lineY=y+16;for(var line:lines){ctx.drawTextWithShadow(font,line,x,lineY,opacity|0xB4B4B4);lineY+=10;}
        int bx=x+width-42,by=y+2;
        ctx.fill(bx,by,bx+40,by+12,opacity|0x3A3A00);
        ctx.drawBorder(bx,by,40,12,opacity|0xFFFF00);
        ctx.drawTextWithShadow(font,"Edit",bx+7,by+2,opacity|0xFFFF00);
        if(by>=clipTop-2&&by+12<=clipBottom+2)click(bx,by,40,12,PosSkillBalanceScreen::open);
        cir.setReturnValue(22+lines.size()*10);
    }
    @Inject(method="sendSet",at=@At("HEAD"),cancellable=true)
    private static void plus$open(@Coerce Object remote,float value,CallbackInfo c){if(PosSkillBalanceScreen.open(remote))c.cancel();}
}
