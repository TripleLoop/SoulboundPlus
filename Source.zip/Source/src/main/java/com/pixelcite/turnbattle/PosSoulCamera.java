package com.pixelcite.turnbattle;
/** Scope look-input relaxation without releasing the native action's movement lock. */
public final class PosSoulCamera {
    public static boolean looking;
    private PosSoulCamera() {}
}
