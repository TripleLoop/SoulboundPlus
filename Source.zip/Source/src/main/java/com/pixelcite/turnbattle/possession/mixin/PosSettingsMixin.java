package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.*;
@Mixin(value=ServerSettings.class,remap=false)
public abstract class PosSettingsMixin {
    @Shadow @Final @Mutable static List<?> ENTRIES;
    @Inject(method="<clinit>",at=@At("TAIL"))
    private static void possession$settings(CallbackInfo ci){ENTRIES=PosConfig.extendEntries(ENTRIES);}
}
