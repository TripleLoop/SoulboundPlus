package com.pixelcite.turnbattle;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Vec3d;
import java.util.*;
final class PosNet {
    private static final Map<UUID,Long> lastEffects=new HashMap<>();
    static void clear(){lastEffects.clear();}
    static final Identifier STATE=Identifier.of("soulbound_possession","state");
    static final Identifier EFFECT=Identifier.of("soulbound_possession","eject");
    static final Identifier ENTRY=Identifier.of("soulbound_possession","entry");
    static final Identifier BODY_WARNING=Identifier.of("soulbound_possession","body_warning");
    static void register(){Net121.registerS2CChannel(STATE);Net121.registerS2CChannel(EFFECT);Net121.registerS2CChannel(BODY_WARNING);Net121.registerS2CChannel(ENTRY);}
    static void bodyWarning(ServerPlayerEntity owner){Net121.sendToClient(owner,BODY_WARNING,PacketByteBufs.create());}
    static void sync(MinecraftServer s){
        for(ServerPlayerEntity p:s.getPlayerManager().getPlayerList()){
            PacketByteBuf b=PacketByteBufs.create();b.writeFloat(PosConfig.get("twitch"));b.writeFloat(PosConfig.get("chestPull"));b.writeVarInt(PosManager.sessions.size());
            for(PosManager.Session ss:PosManager.sessions.values()){
                b.writeUuid(ss.soul);b.writeBoolean(ss.owner!=null);
                if(ss.owner!=null)b.writeUuid(ss.owner);else {
                    b.writeString(Registries.ENTITY_TYPE.getId(ss.mob.getType()).toString());b.writeUuid(ss.body);
                    net.minecraft.nbt.NbtCompound look=null;
                    if(ss.mob instanceof DarknerEntity darkner){
                        look=new net.minecraft.nbt.NbtCompound();look.putInt("Seed",darkner.seed());
                        if(!darkner.item().isEmpty())look.put("Item",darkner.item().encode(p.getRegistryManager()));
                    }
                    if(look==null)look=new net.minecraft.nbt.NbtCompound();
                    var original=new net.minecraft.nbt.NbtCompound();ss.mob.writeCustomDataToNbt(original);
                    var visual=new net.minecraft.nbt.NbtCompound();
                    for(String key:java.util.List.of("IsBaby","Baby","Age","Size","Variant","Color","Sheared","powered","carriedBlockState","DummyKind","DummySoul","DummyLevel","DummyAbsorbed"))if(original.contains(key))visual.put(key,original.get(key).copy());
                    look.put("VariantData",visual);
                    look.putDouble("BodyScale",ss.mob.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.GENERIC_SCALE));
                    b.writeNbt(look);
                }
            }
            b.writeVarInt(PosManager.contests.size()+PosDummies.challenges.size());for(PosManager.Contest c:PosManager.contests.values()){b.writeUuid(c.body);b.writeUuid(c.occupant);b.writeLong(c.began);b.writeLong(c.end);}
            for(var c:PosDummies.challenges.values()){b.writeUuid(c.body().getUuid());b.writeUuid(c.body().getUuid());b.writeLong(c.began());b.writeLong(c.end());}
            var timed=PosManager.sessions.values().stream().filter(ss->ss.expires!=Long.MAX_VALUE).toList();
            b.writeVarInt(timed.size());for(var ss:timed){
                SoulType soul=BattleData.get(s).getOrCreate(ss.soul).soulType;
                b.writeUuid(ss.soul);b.writeVarInt((soul==null?SoulType.DETERMINATION:soul).ordinal());
                b.writeVarInt(PosRules.timerStage(PosManager.now(s),ss.started,ss.expires));b.writeLong(ss.started);b.writeLong(ss.expires);
            }
            Net121.sendToClient(p,STATE,b);
        }
    }
    static SoulType soul(ServerPlayerEntity player){var soul=BattleData.get(player.getServer()).getOrCreate(player.getUuid()).soulType;return soul==null?SoulType.DETERMINATION:soul;}
    static void entry(ServerPlayerEntity player){
        for(var other:player.getServer().getPlayerManager().getPlayerList())if(other.getWorld()==player.getWorld()&&other.squaredDistanceTo(player)<=4096){
            var b=PacketByteBufs.create();b.writeVarInt(player.getId());b.writeVarInt(soul(player).ordinal());Net121.sendToClient(other,ENTRY,b);
        }
    }
    static void effect(MinecraftServer s,UUID body,Vec3d direction){effect(s,body,direction,null);}
    static void effect(MinecraftServer s,UUID body,Vec3d direction,SoulType soul){
        if(body==null)return;
        long tick=PosManager.now(s);Long previous=lastEffects.put(body,tick);if(previous!=null&&tick-previous<2)return;
        lastEffects.entrySet().removeIf(e->tick-e.getValue()>40);
        net.minecraft.entity.Entity source=null;
        var held=PosManager.occupant(body);if(held!=null)source=PosManager.player(s,held.soul);
        var anchor=PosManager.anchors.get(body);if(source==null&&anchor!=null)source=PosManager.body(s,anchor);
        if(source==null)for(var world:s.getWorlds()){source=world.getEntity(body);if(source!=null)break;}
        if(soul==null)soul=source instanceof ServerPlayerEntity player?soul(player):source instanceof PosDummyEntity dummy&&dummy.soul()!=null?dummy.soul():SoulType.DETERMINATION;
        if(source!=null)PosBodyMotion.eject(source,direction);
        if(source!=null)source.getWorld().playSound(null,source.getBlockPos(),TurnBattleSounds.SND_REMOVE_SOUL_WORLD,net.minecraft.sound.SoundCategory.PLAYERS,0.8f,1f);
        for(ServerPlayerEntity p:s.getPlayerManager().getPlayerList()){
            PacketByteBuf b=PacketByteBufs.create();b.writeUuid(body);b.writeDouble(direction.x);b.writeDouble(direction.z);b.writeVarInt(soul.ordinal());Net121.sendToClient(p,EFFECT,b);
        }
    }
}
