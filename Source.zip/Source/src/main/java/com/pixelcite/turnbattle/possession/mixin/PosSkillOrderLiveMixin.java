package com.pixelcite.turnbattle.possession.mixin;
import com.pixelcite.turnbattle.*;
import java.util.List;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=LiveCombatClient.class,remap=false)
public abstract class PosSkillOrderLiveMixin {
    @Shadow @Final private static List<BattleSkill> skills;
    @Inject(method="buildSkills",at=@At("TAIL"))
    private static void plus$liveOrder(CallbackInfo ci){
        if(RogueliteClient.info!=null&&RogueliteClient.info.inRun)return;
        List<BattleSkill> ordered=PosSkillOrder.ordered("self",skills);skills.clear();skills.addAll(ordered);
    }
}
