package com.pixelcite.turnbattle;

import net.minecraft.client.model.*;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;

/** Original padded glove geometry; one Tough Glove item dresses both animated hands. */
public final class PosGloves {
    private static final Identifier TEXTURE=Identifier.ofVanilla("textures/block/white_concrete.png");
    private static final Identifier ITEM=Identifier.of("turnbattle","tough_glove");
    private static final ModelPart RIGHT=build(false),LEFT=build(true);
    public static boolean firstPerson;
    private PosGloves() {}
    public static boolean matches(ItemStack stack){return stack!=null&&!stack.isEmpty()&&Registries.ITEM.getId(stack.getItem()).equals(ITEM);}
    public static boolean equipped(LivingEntity entity){return equipped(entity,ITEM);}
    public static boolean equipped(LivingEntity entity,Identifier item){
        java.util.function.Predicate<ItemStack> matches=stack->stack!=null&&!stack.isEmpty()&&Registries.ITEM.getId(stack.getItem()).equals(item);
        if(matches.test(entity.getMainHandStack())||matches.test(entity.getOffHandStack()))return true;
        var client=net.minecraft.client.MinecraftClient.getInstance();
        if(entity==client.player)return matches.test(TurnBattleClientMod.clientEquippedWeapon);
        java.util.UUID soul=PosClient.soulOf(entity);
        // Battle/player proxies resolve their gear through the original soul, not the borrowed skin.
        if(client.player!=null&&soul.equals(client.player.getUuid()))return matches.test(TurnBattleClientMod.clientEquippedWeapon);
        return matches.test(TurnBattleClientMod.getRemoteEquippedWeapon(soul));
    }
    private static ModelPart build(boolean left){
        ModelData data=new ModelData();ModelPartData root=data.getRoot();
        float center=left?1:-1;
        // Blocky hand padding and outer thumbs wrap the lower arm without replacing its pose.
        root.addChild("leather",ModelPartBuilder.create().uv(0,0)
            .cuboid(center-2.2f,8.4f,-2.25f,4.4f,3.9f,4.5f),ModelTransform.NONE);
        ModelPartBuilder pads=ModelPartBuilder.create().uv(0,0);
        pads.cuboid(center-2.1f,10.1f,-2.75f,4.2f,1.9f,0.7f);
        pads.cuboid(center-1.9f,8.85f,-2.6f,3.8f,1.2f,0.5f);
        float thumb=left?center+1.7f:center-2.8f;
        pads.cuboid(thumb,9.5f,-1.8f,1.1f,2.1f,2.5f);
        root.addChild("padding",pads,ModelTransform.NONE);
        root.addChild("cuff",ModelPartBuilder.create().uv(0,0)
            .cuboid(center-2.35f,7.6f,-2.4f,4.7f,1.2f,4.8f),ModelTransform.NONE);
        root.addChild("strap",ModelPartBuilder.create().uv(0,0)
            .cuboid(center-1.65f,7.85f,-2.53f,3.3f,0.7f,0.2f),ModelTransform.NONE);
        return TexturedModelData.of(data,32,16).createModel();
    }
    public static void renderBoth(BipedEntityModel<?> model,LivingEntity entity,MatrixStack matrices,VertexConsumerProvider vertices,int light){
        render(model.rightArm,Arm.RIGHT,entity,matrices,vertices,light);
        render(model.leftArm,Arm.LEFT,entity,matrices,vertices,light);
    }
    public static void render(ModelPart arm,Arm side,LivingEntity entity,MatrixStack matrices,VertexConsumerProvider vertices,int light){
        if(entity.isInvisible()||!arm.visible)return;
        ModelPart glove=side==Arm.RIGHT?RIGHT:LEFT;
        matrices.push();arm.rotate(matrices);
        VertexConsumer consumer=vertices.getBuffer(RenderLayer.getEntityCutoutNoCull(TEXTURE));
        int overlay=net.minecraft.client.render.entity.LivingEntityRenderer.getOverlay(entity,0);
        glove.getChild("leather").render(matrices,consumer,light,overlay,0xFFDC6B1C);
        glove.getChild("padding").render(matrices,consumer,light,overlay,0xFFFF9637);
        glove.getChild("cuff").render(matrices,consumer,light,overlay,0xFF4B281C);
        glove.getChild("strap").render(matrices,consumer,light,overlay,0xFFEBA047);
        matrices.pop();
    }
}
