package com.pixelcite.turnbattle;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
public final class PosAddon implements ModInitializer {
    @Override public void onInitialize(){
        PosDummies.register();PosConfig.load(); PosNet.register(); PosSkillBalance.register();
        long settings=ServerSettings.ENTRIES.stream().filter(e->e.key().startsWith("poss_")).count();
        if(settings!=PosConfig.SETTINGS.size())throw new IllegalStateException("Possession server settings did not integrate");
        PosBridge.out();
        org.slf4j.LoggerFactory.getLogger("SoulboundPossession").info("Possession addon ready: {} server settings; Soulbound 2.0.21 body hooks resolved.",settings);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_LOAD.register(PosJournal::entityLoaded);
        ServerTickEvents.END_SERVER_TICK.register(PosManager::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((h,s)->PosManager.disconnect(h.player));
        ServerLifecycleEvents.SERVER_STOPPING.register(PosManager::stop);
        ServerLifecycleEvents.SERVER_STOPPED.register(s->PosManager.clear());
    }
}
