package com.pixelcite.turnbattle;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import java.util.Arrays;
/** Client-environment transformation test. Stops before window creation; never starts a world. */
public final class PosVisionSmokeTest implements PreLaunchEntrypoint {
    private static int checks;
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    @Override public void onPreLaunch(){try{
        ClassLoader loader=getClass().getClassLoader();
        Class.forName("com.pixelcite.turnbattle.PosNativeSoulPose",true,loader);
        check(true,"Native extraction reflection signatures resolve");
        Class.forName("com.pixelcite.turnbattle.PosEntryVisual",true,loader);
        check(true,"Native entry ring reflection signatures resolve");
        Class<?> living=Class.forName("net.minecraft.client.render.entity.LivingEntityRenderer",false,loader);
        check(Arrays.stream(living.getDeclaredMethods()).anyMatch(m->m.getName().contains("possession$nativeExtraction")),"Native extraction renderer hook missing");
        check(Arrays.stream(living.getDeclaredMethods()).anyMatch(m->m.getName().contains("possession$finalPose")),"Final model pose hook missing");
        net.minecraft.SharedConstants.createGameVersion();net.minecraft.Bootstrap.initialize();
        // Actual zombie model parts: late extraction must replace arms-forward and move the wrist only once.
        var parts=net.minecraft.client.render.entity.model.BipedEntityModel.getModelData(net.minecraft.client.model.Dilation.NONE,0).getRoot().createPart(64,64);
        var zombie=new net.minecraft.client.render.entity.model.ZombieEntityModel<net.minecraft.entity.mob.ZombieEntity>(parts);
        Class<?> unsafeType=Class.forName("sun.misc.Unsafe");var unsafeField=unsafeType.getDeclaredField("theUnsafe");unsafeField.setAccessible(true);Object unsafe=unsafeField.get(null);
        var actor=(net.minecraft.entity.LivingEntity)unsafeType.getMethod("allocateInstance",Class.class).invoke(unsafe,net.minecraft.entity.mob.ZombieEntity.class);
        zombie.rightArm.pitch=zombie.leftArm.pitch=-1.57f;
        var pose=new CloneAnimator.Pose();pose.armW=1;pose.headW=1;pose.rArmP=.65f;pose.rArmY=-.35f;pose.rArmR=-1.2f;pose.rArmPZ=-4;pose.lArmP=-.35f;pose.lArmR=-.32f;pose.headP=.6f;
        var player=new net.minecraft.client.render.entity.model.BipedEntityModel<net.minecraft.entity.LivingEntity>(net.minecraft.client.render.entity.model.BipedEntityModel.getModelData(net.minecraft.client.model.Dilation.NONE,0).getRoot().createPart(64,64));
        player.rightArm.pitch=.4f;player.leftArm.pitch=-.4f;player.rightLeg.pitch=-.4f;player.leftLeg.pitch=.4f;
        float originalArm=zombie.rightArm.pitch;float originalWidth=zombie.rightArm.pivotX;
        PosPlayerMotion.copy(zombie,player);
        check(Math.abs(zombie.rightArm.pitch-.4f)<.0001f&&Math.abs(zombie.leftArm.pitch+.4f)<.0001f,"Player walk did not replace mob arm stance");
        check(zombie.rightArm.pivotX==originalWidth,"Player animation changed borrowed proportions");
        PosClient.restoreParts();check(zombie.rightArm.pitch==originalArm,"Unpossessed mob retained player pose");
        var illager=new net.minecraft.client.render.entity.model.IllagerEntityModel<net.minecraft.entity.mob.IllagerEntity>(net.minecraft.client.render.entity.model.IllagerEntityModel.getTexturedModelData().createModel());
        var humanoid=PosHumanoidModel.view(illager);check(humanoid!=null,"Independent-arm humanoid was missed");
        var crossed=illager.getPart().getChild("arms");crossed.visible=true;humanoid.rightArm.visible=false;humanoid.leftArm.visible=false;
        PosPlayerMotion.copy(humanoid,player);PosHumanoidModel.separateArms(illager,humanoid);
        check(!crossed.visible&&humanoid.rightArm.visible&&humanoid.leftArm.visible,"Possessed illager keeps crossed arms");
        check(Math.abs(humanoid.rightArm.pitch-.4f)<.0001f,"Illager does not receive player motion");
        PosClient.restoreParts();check(crossed.visible&&!humanoid.rightArm.visible&&!humanoid.leftArm.visible,"Normal illager visibility was not restored");
        var actsField=PlayerActions.class.getDeclaredField("acts");actsField.setAccessible(true);
        @SuppressWarnings("unchecked") var acts=(java.util.Map<java.util.UUID,Object>)actsField.get(null);
        Class<?> actType=Class.forName("com.pixelcite.turnbattle.PlayerActions$Act"),kindType=Class.forName("com.pixelcite.turnbattle.PlayerActions$Kind");
        Object fakeAct=unsafeType.getMethod("allocateInstance",Class.class).invoke(unsafe,actType);
        var kindField=actType.getDeclaredField("kind");kindField.setAccessible(true);var soulField=kindType.getField("SOUL");soulField.setAccessible(true);var menuField=kindType.getField("MENU");menuField.setAccessible(true);
        var id=java.util.UUID.randomUUID();
        try{kindField.set(fakeAct,soulField.get(null));acts.put(id,fakeAct);check(PosNativeSoulPose.soulAction(id),"Soul camera action not detected");kindField.set(fakeAct,menuField.get(null));check(!PosNativeSoulPose.soulAction(id),"Menu camera incorrectly treated as extraction");}
        finally{acts.remove(id);}check(!PosNativeSoulPose.soulAction(id),"Expired extraction still owns camera");
        var prior=new CloneAnimator.Pose();CloneAnimator.beginModelPose(actor,prior);
        float pivot=zombie.rightArm.pivotZ;
        PosModelPose.apply(zombie,actor,pose);
        check(Math.abs(zombie.rightArm.pitch-.65f)<.0001f&&Math.abs(zombie.leftArm.pitch+.35f)<.0001f,"Zombie arms overwrite removal gesture");
        check(Math.abs(zombie.rightArm.roll+1.2f)<.0001f&&Math.abs(zombie.head.pitch-.6f)<.0001f,"Extraction hand/head gesture missing");
        check(Math.abs(zombie.rightArm.pivotZ-(pivot-4))<.0001f,"Extraction wrist offset applied twice");
        check(CloneAnimator.activePoseFor(actor)==prior,"Native animation context not restored");CloneAnimator.endModelPose();
        Class<?> renderer=Class.forName("net.minecraft.client.render.GameRenderer",false,loader);
        Class<?> actions=Class.forName("com.pixelcite.turnbattle.PlayerActions",false,loader);
        check(Arrays.stream(actions.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$freeSoulCamera")),"Free soul camera hook missing");
        check(Arrays.stream(actions.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$freeSoulLook")),"Free look hook missing");
        Class<?> camera=Class.forName("net.minecraft.client.render.Camera",false,loader);
        Class<?> hud=Class.forName("net.minecraft.client.gui.hud.InGameHud",false,loader);
        check(Arrays.stream(hud.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$bodyWarning")),"Body damage warning HUD mixin missing");
        Class<?> gloveFeature=Class.forName("net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer",false,loader);
        Class<?> heldRenderer=Class.forName("net.minecraft.client.render.item.HeldItemRenderer",false,loader);
        Class<?> playerRenderer=Class.forName("net.minecraft.client.render.entity.PlayerEntityRenderer",false,loader);
        Class<?> limb=Class.forName("net.minecraft.entity.LimbAnimator",false,loader);
        check(com.pixelcite.turnbattle.possession.mixin.PosLimbAccess.class.isAssignableFrom(limb),"Limb phase accessor missing");
        Class<?> entity=Class.forName("net.minecraft.entity.Entity",false,loader);
        check(Arrays.stream(entity.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$lookScope")),"Look scope wrapper missing");
        check(Arrays.stream(entity.getDeclaredMethods()).anyMatch(m->m.getName().contains("possession$noBackingPush")),"Backing collision cancellation missing");
        check(Arrays.stream(entity.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$outline")),"Timed outline hook missing");
        Class<?> glow=Class.forName("com.pixelcite.turnbattle.SoulGlowRenderer",false,loader);
        check(Arrays.stream(glow.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$reveal")),"Timed native soul reveal hook missing");
        Class.forName("com.pixelcite.turnbattle.PosDummyRenderer",false,loader);
        Class<?> stats=Class.forName("com.pixelcite.turnbattle.StatsScreen",false,loader);
        for(String method:new String[]{"plus$ordered","plus$handles","mouseClicked","mouseDragged","mouseReleased","keyPressed","removed"})check(Arrays.stream(stats.getDeclaredMethods()).anyMatch(m->m.getName().contains(method)),"Skill drag hook missing: "+method);
        Class<?> battle=Class.forName("com.pixelcite.turnbattle.BattleScreen",false,loader);
        check(Arrays.stream(battle.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$battleOrder")),"Battle skill order hook missing");
        Class<?> live=Class.forName("com.pixelcite.turnbattle.LiveCombatClient",false,loader);
        check(Arrays.stream(live.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$liveOrder")),"Live skill order hook missing");
        Class<?> settings=Class.forName("com.pixelcite.turnbattle.SettingsScreen",false,loader);
        check(Arrays.stream(settings.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$open")),"Updated Soulbound settings editor hook missing");
        check(Arrays.stream(settings.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$editButton")),"Edit action button hook missing");
        Class.forName("com.pixelcite.turnbattle.DarknerRenderer",false,loader);
        check(Arrays.stream(gloveFeature.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$gloves")),"Paired glove feature hook missing");
        check(Arrays.stream(gloveFeature.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$glovePair")),"Slot-independent paired glove hook missing");
        check(Arrays.stream(heldRenderer.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$beginHands")),"First-person single-pair reset hook missing");
        check(Arrays.stream(heldRenderer.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$gloveHands")),"First-person paired glove hook missing");
        check(Arrays.stream(playerRenderer.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$gloveArm")),"First-person glove arm hook missing");
        check(Arrays.stream(renderer.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$mobVision")),"Renderer mixin missing");
        check(Arrays.stream(renderer.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$mobHands")),"Spectator hand visibility hook missing");
        check(Arrays.stream(camera.getDeclaredMethods()).anyMatch(m->m.getName().contains("plus$eyeHeight")),"Camera mixin missing");
        check(Arrays.stream(renderer.getDeclaredMethods()).anyMatch(m->m.getName().equals("onCameraEntitySet")),"Vanilla spectator effect API missing");
        check(Arrays.stream(camera.getDeclaredFields()).anyMatch(f->f.getName().equals("cameraY")),"Camera eye-height field missing");
        check(Arrays.stream(camera.getDeclaredFields()).anyMatch(f->f.getName().equals("lastCameraY")),"Camera interpolation field missing");
        for(String shader:new String[]{"creeper","spider","invert"})try(var resource=loader.getResourceAsStream("assets/minecraft/shaders/post/"+shader+".json")){check(resource!=null,"Missing vanilla spectator shader "+shader);}
        for(String name:new String[]{"toy_knife","tough_glove","ballet_shoes","torn_notebook","burnt_pan","empty_gun","real_knife","climb_claws"}){
            var resources=loader.getResources("assets/turnbattle/models/item/"+name+".json");boolean found=false;
            while(resources.hasMoreElements())try(var reader=new java.io.InputStreamReader(resources.nextElement().openStream(),java.nio.charset.StandardCharsets.UTF_8)){
                var parsed=net.minecraft.client.render.model.json.JsonUnbakedModel.deserialize(reader);
                if(!parsed.getElements().isEmpty()){found=true;check(parsed.getElements().stream().allMatch(e->e.to.z-e.from.z>=0.1f),"Flat weapon geometry "+name);}
            }
            check(found,"Missing 3D model "+name);
        }
        for(int state=0;state<64;state++)check(PosVisionRules.active((state&1)!=0,(state&2)!=0,(state&4)!=0,(state&8)!=0,(state&16)!=0,(state&32)!=0)==(state==15),"Incorrect view gate "+state);
        System.out.println("SOULBOUNDPLUS CLIENT VISION SMOKE PASSED: "+checks+" checks; client camera and renderer mixins transformed. No window/world started.");
    }catch(Exception e){throw new RuntimeException("Client vision smoke failed",e);}System.exit(0);}
}
