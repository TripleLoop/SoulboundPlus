package com.pixelcite.turnbattle.geartest;
import com.pixelcite.turnbattle.PosBodyGearSmokeTest;
import net.minecraft.server.Main;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Main.class)
public abstract class GearMainMixin {
    @Inject(method="main",at=@At("RETURN"))
    private static void verify(String[] args,CallbackInfo ci){PosBodyGearSmokeTest.run();}
}
