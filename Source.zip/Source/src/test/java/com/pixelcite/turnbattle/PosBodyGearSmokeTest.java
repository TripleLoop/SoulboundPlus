package com.pixelcite.turnbattle;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.*;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.nbt.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
import java.util.*;

/** Exercises real registry-backed stacks and the optional accessory bridge with public-API contract fixtures. */
public final class PosBodyGearSmokeTest {
    private static int checks;
    private static void check(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    public static final class Dynamic {
        final List<ItemStack> stacks=new ArrayList<>();Dynamic(int n){resize(n);}
        void resize(int n){while(stacks.size()<n)stacks.add(ItemStack.EMPTY);while(stacks.size()>n)stacks.removeLast();}
        public int getSlots(){return stacks.size();}public ItemStack getStackInSlot(int n){return stacks.get(n);}
        public void setStackInSlot(int n,ItemStack stack){stacks.set(n,stack);}
    }
    public static final class Curio {
        final Dynamic normal,cosmetic;final List<Boolean> renders=new ArrayList<>();
        Curio(int n){normal=new Dynamic(n);cosmetic=new Dynamic(n);for(int i=0;i<n;i++)renders.add(true);}
        public int getSlots(){return normal.getSlots();}
        public List<Boolean> getRenders(){return renders;}
        public void grow(int n){resize(normal.getSlots()+n);}public void shrink(int n){resize(normal.getSlots()-n);}
        void resize(int n){normal.resize(n);cosmetic.resize(n);while(renders.size()<n)renders.add(true);while(renders.size()>n)renders.removeLast();}
    }
    public static final class Owner {final Set<Object> updating=new HashSet<>();public Set<Object> getUpdatingInventories(){return updating;}}
    private static PosAccessories.Group group(Curio c){return new PosAccessories.Group("curios","back",c.normal,c.cosmetic,c,new Owner());}
    public static void run(){try{
        var registries=DynamicRegistryManager.of(Registries.REGISTRIES);
        check(PosBodyGear.backpack(Identifier.of("sophisticatedbackpacks","backpack")),"Base backpack not detected");
        for(String tier:new String[]{"copper","iron","gold","diamond","netherite"})check(PosBodyGear.backpack(Identifier.of("sophisticatedbackpacks",tier+"_backpack")),"Tier not detected");
        check(!PosBodyGear.backpack(Identifier.of("sophisticatedbackpacks","stack_upgrade_tier_1")),"Upgrade incorrectly treated as a backpack");
        check(!PosBodyGear.backpack(Identifier.of("minecraft","chest")),"Unrelated item incorrectly leased");
        ItemStack stack=new ItemStack(Items.CHEST);NbtCompound components=new NbtCompound();UUID id=UUID.randomUUID();components.putUuid("storageUuid",id);components.putString("Upgrade","test-upgrade");stack.set(DataComponentTypes.CUSTOM_DATA,NbtComponent.of(components));
        Curio source=new Curio(3);source.normal.setStackInSlot(2,stack);source.cosmetic.setStackInSlot(0,new ItemStack(Items.DIAMOND));source.renders.set(2,false);
        var saved=PosAccessories.capture(List.of(group(source)),registries,true);
        check(source.normal.getStackInSlot(2).isEmpty()&&source.cosmetic.getStackInSlot(0).isEmpty(),"Source not cleared");
        Curio target=new Curio(3);var targetGroups=List.of(group(target));check(PosAccessories.canApply(targetGroups,registries,saved),"Valid transfer rejected");PosAccessories.apply(targetGroups,registries,saved);
        check(target.normal.getSlots()==3,"Native slot count changed");
        check(ItemStack.areEqual(target.normal.getStackInSlot(2),stack),"Components lost on transfer");check(!target.renders.get(2),"Render state lost");check(target.cosmetic.getStackInSlot(0).isOf(Items.DIAMOND),"Cosmetic slot lost");
        var returned=PosAccessories.capture(targetGroups,registries,true);PosAccessories.apply(List.of(group(source)),registries,returned);
        check(source.normal.getStackInSlot(2).get(DataComponentTypes.CUSTOM_DATA).copyNbt().getUuid("storageUuid").equals(id),"Storage UUID changed");
        check(PosAccessories.stacks(saved,registries).size()==2,"Death/recovery includes wrong item count");
        check(!PosAccessories.canApply(List.of(group(new Curio(1))),registries,saved),"Overflow should be rejected before changing either body");
        check(!PosAccessories.canApply(List.of(),registries,saved),"Missing provider accepted nonempty data");
        SimpleInventory trinkets=new SimpleInventory(2);trinkets.setStack(1,stack.copy());var tg=List.of(new PosAccessories.Group("trinkets","chest/back",trinkets,null,null,null));var trinketData=PosAccessories.capture(tg,registries,true);check(trinkets.isEmpty(),"Trinkets source not cleared");PosAccessories.apply(tg,registries,trinketData);check(ItemStack.areEqual(trinkets.getStack(1),stack),"Trinkets stack components lost");
        if(Registries.ITEM.containsId(Identifier.of("sophisticatedbackpacks","backpack"))){
            ItemStack real=new ItemStack(Registries.ITEM.get(Identifier.of("sophisticatedbackpacks","backpack")));check(PosBodyGear.backpack(real),"Real backpack not detected");
            Class<?> wrapper=Class.forName("net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper");Object wrapped=PosAccessories.call(wrapper,"fromStack",real);PosAccessories.call(wrapped,"setContentsUuid",id);PosAccessories.call(wrapped,"setColors",0x123456,0x654321);
            Curio withReal=new Curio(1);withReal.normal.setStackInSlot(0,real);NbtCompound before=PosAccessories.capture(List.of(group(withReal)),registries,true);PosAccessories.apply(List.of(group(withReal)),registries,before);ItemStack restored=withReal.normal.getStackInSlot(0);Object rw=PosAccessories.call(wrapper,"fromStack",restored);
            check(((Optional<?>)PosAccessories.call(rw,"getContentsUuid")).orElseThrow().equals(id),"Real backpack storage UUID lost");check(ItemStack.areEqual(real,restored),"Real backpack components changed");
            System.out.println("REAL SOPHISTICATED BACKPACK/CORE COMPONENT ROUNDTRIP PASSED");
        }
        System.out.println("SOULBOUNDPLUS BODY GEAR SMOKE PASSED: "+checks+" checks. Curios path uses API contract fixtures, not a NeoForge/Connector session.");
    }catch(Exception e){throw new RuntimeException("Body gear smoke failed",e);}}
}
