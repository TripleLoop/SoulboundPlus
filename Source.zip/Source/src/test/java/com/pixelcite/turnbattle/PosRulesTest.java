package com.pixelcite.turnbattle;
public final class PosRulesTest {
    private static int count;
    static void eq(double got,double want){count++;if(Math.abs(got-want)>1e-9)throw new AssertionError(got+" != "+want);}
    static void check(boolean value){count++;if(!value)throw new AssertionError("Proximity regression");}
    public static void main(String[] args){
        // Exhaustive gates: no mob view in third person, other cameras, death, combat or cinematics.
        for(int mask=0;mask<64;mask++){
            boolean mob=(mask&1)!=0,first=(mask&2)!=0,local=(mask&4)!=0,alive=(mask&8)!=0,combat=(mask&16)!=0,cinematic=(mask&32)!=0;
            check(PosVisionRules.active(mob,first,local,alive,combat,cinematic)==(mask==15));
        }
        // Regression: the soul overlaps its body immediately after the extraction animation.
        // Waiting in that position must never teleport it back, even after the entry grace expires.
        for(int ticks=0;ticks<=200;ticks++)check(!PosRules.canProximityEnter(true,false,ticks));
        check(!PosRules.canProximityEnter(true,true,10));
        check(PosRules.canProximityEnter(true,true,11));
        check(PosRules.canProximityEnter(true,true,200));
        check(!PosRules.canProximityEnter(false,false,10));
        check(PosRules.canProximityEnter(false,false,11));
        eq(PosRules.invaderChance(50,50,10,.55),.45);
        eq(PosRules.invaderChance(40,50,10,.55),0);
        eq(PosRules.invaderChance(60,50,10,.55),1);
        eq(PosRules.invaderChance(0,50,10,.55),0);
        eq(PosRules.invaderChance(500,50,10,.55),1);
        eq(PosRules.invaderChance(40,50,15,.55),.15);
        eq(PosRules.invaderChance(45,50,15,.55),.30);
        eq(PosRules.invaderChance(55,50,15,.55),.45+.55/3);
        eq(PosRules.invaderChance(60,50,15,.55),.45+1.1/3);
        eq(PosRules.invaderChance(65,50,15,.55),1);
        eq(PosRules.durationTicks(30,1,0,2),600);
        eq(PosRules.durationTicks(30,1,10,2),400);
        eq(PosRules.durationTicks(30,1,100,2),40);
        for(int threshold=1;threshold<=100;threshold++){
            double prev=-1;
            for(int delta=-threshold;delta<=threshold;delta++){
                double chance=PosRules.invaderChance(1000+delta,1000,threshold,.55);
                if(chance<prev||chance<0||chance>1)throw new AssertionError("Non-monotonic odds");prev=chance;count++;
            }
        }
        for(int elapsed=0;elapsed<=1200;elapsed++)check(PosRules.timerStage(100+elapsed,100,1100)==(elapsed>=900?2:elapsed>=500?1:0));
        check(PosRules.timerStage(10000,100,Long.MAX_VALUE)==0);
        check(PosRules.timerStage(0,100,1100)==0);
        check(PosRules.timerStage(100,100,100)==0);
        // Five peaks, different directions, no residual motion outside the timed fight.
        var body=new java.util.UUID(1234,5678);
        for(double duration:new double[]{2,20,200,1200}){
            for(int i=1;i<=5;i++){
                var peak=PosStruggleMotion.sample(body,(i-.5)*PosStruggleMotion.pullWindowTicks(duration)/5,duration);
                eq(peak.force(),1);eq(Math.hypot(peak.x(),peak.z()),1);
                if(i>1){var previous=PosStruggleMotion.sample(body,(i-1.5)*PosStruggleMotion.pullWindowTicks(duration)/5,duration);check(peak.x()*previous.x()+peak.z()*previous.z()<0);}
            }
            eq(PosStruggleMotion.sample(body,-1,duration).force(),0);
            eq(PosStruggleMotion.sample(body,duration+1,duration).force(),0);
            for(double t=0;t<=duration;t+=.25){var a=PosStruggleMotion.sample(body,t,duration);check(Double.isFinite(a.x())&&Double.isFinite(a.z())&&Math.hypot(a.x(),a.z())<=1.000001);}
        }
        // The removal gesture and all server/client struggle displacement are mutually exclusive.
        for(double duration:new double[]{2,20,100,200,1200}){
            double start=PosStruggleMotion.pullWindowTicks(duration);
            for(double t=start;t<=duration;t+=.05){var sample=PosStruggleMotion.sample(body,t,duration);eq(sample.force(),0);eq(sample.x(),0);eq(sample.y(),0);eq(sample.z(),0);check(PosStruggleMotion.struggleExtractionTicks(t,0,duration)>=0);}
            eq(PosStruggleMotion.struggleExtractionTicks(start-.001,0,duration),-1);
            eq(PosStruggleMotion.struggleExtractionTicks(start,0,duration),0);
            eq(PosStruggleMotion.struggleExtractionTicks(duration,0,duration),60);
        }
        eq(PosStruggleMotion.ejectionForce(-1),0);eq(PosStruggleMotion.ejectionForce(0),0);
        eq(PosStruggleMotion.ejectionForce(4),1);eq(PosStruggleMotion.ejectionForce(8),0);
        eq(PosStruggleMotion.ejectionForce(12),-.25);eq(PosStruggleMotion.ejectionForce(16),0);
        check(Math.abs(PosStruggleMotion.ejectionForce(8-.0001)-PosStruggleMotion.ejectionForce(8+.0001))<.0001);
        eq(PosStruggleMotion.extractionTicks(139,0,200),-1);
        eq(PosStruggleMotion.extractionTicks(140,0,200),0);
        eq(PosStruggleMotion.extractionTicks(170,0,200),30);
        eq(PosStruggleMotion.extractionTicks(200,0,200),60);
        eq(PosStruggleMotion.extractionTicks(10,0,20),30);
        System.out.println("Passed "+count+" possession rule checks.");
    }
}
