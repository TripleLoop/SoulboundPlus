package com.pixelcite.turnbattle.smokemixin;
import com.pixelcite.turnbattle.PosAddon;
import com.pixelcite.turnbattle.PosSkillsSmokeTest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=PosAddon.class,remap=false)
public abstract class PosSkillSmokeReadyMixin {
    @Inject(method="onInitialize",at=@At("TAIL"))
    private void smoke$ready(CallbackInfo ci){PosSkillsSmokeTest.addonReady();}
}
