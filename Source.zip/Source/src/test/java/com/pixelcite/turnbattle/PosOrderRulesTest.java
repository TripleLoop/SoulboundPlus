package com.pixelcite.turnbattle;
import java.util.*;
public final class PosOrderRulesTest {
    private static int checks;
    private static void check(boolean ok){checks++;if(!ok)throw new AssertionError("Skill ordering regression");}
    public static void main(String[] args){
        List<String> original=List.of("T-Action","heal","fire","guard");
        check(PosSkillOrderRules.move(original,0,3).equals(List.of("heal","fire","guard","T-Action")));
        check(PosSkillOrderRules.move(original,3,0).equals(List.of("guard","T-Action","heal","fire")));
        check(PosSkillOrderRules.sorted(original,List.of("guard","T-Action"),s->s,Comparator.naturalOrder()).equals(List.of("guard","T-Action","fire","heal")));
        check(original.equals(List.of("T-Action","heal","fire","guard")));
        check(PosSkillOrderRules.unique(Arrays.asList("a","a",null,"","b")).equals(List.of("a","b")));
        check(PosSkillOrderRules.merge(List.of("a","hidden","b"),List.of("b","a","new")).equals(List.of("b","hidden","a","new")));
        // All drag directions preserve identities and apply exactly the displayed permutation.
        for(int size=1;size<=30;size++){
            List<String> visible=new ArrayList<>();for(int i=0;i<size;i++)visible.add("skill-"+i);
            for(int from=0;from<size;from++)for(int to=0;to<size;to++){
                List<String> moved=PosSkillOrderRules.move(visible,from,to);
                check(moved.get(to).equals(visible.get(from)));
                check(new HashSet<>(moved).equals(new HashSet<>(visible))&&moved.size()==size);
                List<String> saved=PosSkillOrderRules.merge(List.of("hidden-before","skill-0","hidden-after"),moved);
                List<String> result=PosSkillOrderRules.sorted(visible,saved,s->s,Comparator.naturalOrder());
                check(result.equals(moved));
                check(saved.contains("hidden-before")&&saved.contains("hidden-after"));
            }
        }
        System.out.println("Passed "+checks+" skill-order checks.");
    }
}
