package com.pixelcite.turnbattle;
import net.fabricmc.api.ModInitializer;
import java.lang.reflect.*;
import java.util.*;
import java.nio.file.*;
/** Run through Fabric so these assertions exercise transformed enum classes and server mixins. */
public final class PosSkillsSmokeTest implements ModInitializer {
    private static boolean ready;
    private static PosSkillsSmokeTest instance;
    private boolean ran;
    public static void addonReady(){ready=true;if(instance!=null)instance.run();}
    @Override public void onInitialize(){instance=this;if(ready)run();}
    private int checks;
    private void check(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    @SuppressWarnings("unchecked") private void configMigration() throws Exception {
        var pathField=PosConfig.class.getDeclaredField("FILE");pathField.setAccessible(true);Path file=(Path)pathField.get(null);
        var loaded=PosConfig.class.getDeclaredField("loaded");loaded.setAccessible(true);
        var field=PosConfig.class.getDeclaredField("values");field.setAccessible(true);var values=(Map<String,Float>)field.get(null);
        byte[] old=Files.exists(file)?Files.readAllBytes(file):null;var saved=new HashMap<>(values);boolean wasLoaded=loaded.getBoolean(null);
        try{
            Files.createDirectories(file.getParent());Files.deleteIfExists(file);values.clear();loaded.setBoolean(null,false);PosConfig.load();
            check(PosConfig.get("cooldown")==30&&PosConfig.get("struggle")==10,"Fresh defaults incorrect");
            for(String fixture:new String[]{"{\"cooldown\":15,\"struggle\":3}","{\"cooldown\":42,\"struggle\":7}","{\"_defaultsVersion\":2,\"cooldown\":15,\"struggle\":3}"}){
                Files.writeString(file,fixture);values.clear();loaded.setBoolean(null,false);PosConfig.load();
                boolean legacy=!fixture.contains("_defaultsVersion")&&fixture.contains("15");boolean custom=fixture.contains("42");
                check(PosConfig.get("cooldown")== (legacy?30:custom?42:15),"Cooldown migration failed");
                check(PosConfig.get("struggle")== (legacy?10:custom?7:3),"Struggle migration failed");
                check(Files.readString(file).contains("_defaultsVersion"),"Migration version not persisted");
            }
        }finally{if(old==null)Files.deleteIfExists(file);else Files.write(file,old);values.clear();values.putAll(saved);loaded.setBoolean(null,wasLoaded);}
    }
    private void run(){if(ran)return;ran=true;try{
        configMigration();
        Class<?> walk=Class.forName("com.pixelcite.turnbattle.SoulWalk");
        check(Arrays.stream(walk.getDeclaredMethods()).anyMatch(m->m.getName().contains("possession$coloredEntry")),"Native ring redirect missing");
        check(PosConfig.SETTINGS.stream().noneMatch(s->s.key().equals("overpower")),"Legacy short struggle setting remains");
        check(PosManager.excludedType(DarknerBossEntity.class),"Darkner bosses must not be possessable");
        check(PosManager.excludedType(Shopkeeper.Entity.class),"Non-combat shopkeepers must not be possessable");
        check(PosManager.excludedType(net.minecraft.entity.passive.CowEntity.class),"Passive mobs must remain excluded");
        check(!PosManager.excludedType(DarknerEntity.class),"Ordinary hostile Darkners must remain eligible by type");
        check(!PosManager.excludedType(net.minecraft.entity.mob.ZombieEntity.class),"Existing hostile mob type was excluded");
        check(net.minecraft.registry.Registries.ENTITY_TYPE.get(net.minecraft.util.Identifier.of("soulbound_possession","test_dummy"))==PosDummies.TYPE,"Dummy type not registered");
        check(net.minecraft.entity.attribute.DefaultAttributeRegistry.hasDefinitionFor(PosDummies.TYPE),"Dummy attributes missing");
        // Identity-only fixture: no world constructor, chunks, or gameplay session is started.
        Class<?> unsafeType=Class.forName("sun.misc.Unsafe");var unsafeField=unsafeType.getDeclaredField("theUnsafe");unsafeField.setAccessible(true);Object unsafe=unsafeField.get(null);
        var allocate=unsafeType.getMethod("allocateInstance",Class.class);
        var dummy=(PosDummyEntity)allocate.invoke(unsafe,PosDummyEntity.class);
        var world=(net.minecraft.server.world.ServerWorld)allocate.invoke(unsafe,net.minecraft.server.world.ServerWorld.class);
        var side=net.minecraft.world.World.class.getDeclaredField("isClient");side.setAccessible(true);side.setBoolean(world,true);
        var worldField=net.minecraft.entity.Entity.class.getDeclaredField("world");worldField.setAccessible(true);worldField.set(dummy,world);
        java.util.UUID fixtureId=UUID.randomUUID();dummy.setUuid(fixtureId);
        check(!PosManager.isSuppressedEntity(dummy),"Unoccupied dummy hidden by renderer gate");
        check(!dummy.isSpectator(),"Unoccupied dummy rejected by soul proximity scan");
        check(PosManager.isCombatExcluded(dummy),"Visible test dummy admitted into combat");
        check(!dummy.isAttackable()&&!dummy.isPushable(),"Inert dummy attack/push protection missing");
        try{PosManager.CLIENT_BACKING.add(fixtureId);check(PosManager.isSuppressedEntity(dummy)&&dummy.isSpectator(),"Occupied dummy backing not hidden");}
        finally{PosManager.CLIENT_BACKING.remove(fixtureId);}
        check(!PosManager.isSuppressedEntity(dummy)&&!dummy.isSpectator(),"Released dummy remains hidden");
        var command=PosDummies.commands().build().getChild("dummy");
        var spawn=command.getChild("spawn");var edits=command.getChild("set");
        for(var argument:java.util.List.of(spawn.getChild("human").getChild("level"),edits.getChild("level").getChild("level"))){
            var type=(com.mojang.brigadier.arguments.IntegerArgumentType)((com.mojang.brigadier.tree.ArgumentCommandNode<?,?>)argument).getType();
            check(type.getMinimum()==1&&type.getMaximum()==99,"Human dummy command level limits");
            check(type.parse(new com.mojang.brigadier.StringReader("99"))==99,"Human LV 99 rejected");
            try{type.parse(new com.mojang.brigadier.StringReader("100"));throw new AssertionError("Human LV 100 accepted");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){check(true,"Human upper bound rejected");}
        }
        for(var argument:java.util.List.of(spawn.getChild("monster").getChild("souls"),edits.getChild("souls").getChild("souls"))){
            var type=(com.mojang.brigadier.arguments.IntegerArgumentType)((com.mojang.brigadier.tree.ArgumentCommandNode<?,?>)argument).getType();
            check(type.getMinimum()==0&&type.getMaximum()==7,"Monster dummy soul limits");
            check(type.parse(new com.mojang.brigadier.StringReader("7"))==7,"Seven absorbed souls rejected");
            try{type.parse(new com.mojang.brigadier.StringReader("8"));throw new AssertionError("Eight absorbed souls accepted");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){check(true,"Monster upper bound rejected");}
        }
        check(spawn.getChild("empty").getCommand()!=null,"Empty dummy spawn command missing");
        for(SoulType soul:SoulType.values())if(soul!=SoulType.MONSTER)check(PosDummies.humanSoul(soul.name().toLowerCase(Locale.ROOT))==soul,"Human soul command mapping "+soul);
        for(String invalid:java.util.List.of("monster","invalid_soul"))try{PosDummies.humanSoul(invalid);throw new AssertionError("Invalid human soul accepted");}catch(com.mojang.brigadier.exceptions.CommandSyntaxException expected){check(true,"Invalid human soul rejected");}
        for(int souls=0;souls<=7;souls++)check(PosDummies.duration(PosDummyEntity.Kind.MONSTER,souls)==PosRules.durationTicks(PosConfig.get("monsterBase"),PosConfig.get("soulReduction"),souls,PosConfig.get("minimum")),"Monster dummy timer diverged from player Monster formula");
        check(PosDummies.duration(PosDummyEntity.Kind.HUMAN,7)==Long.MAX_VALUE,"Human dummy unexpectedly timed");
        check(PosDummies.duration(PosDummyEntity.Kind.EMPTY,7)==Long.MAX_VALUE,"Empty dummy unexpectedly timed");
        Field values=PosSkillBalance.class.getDeclaredField("serverValues");values.setAccessible(true);
        var original=values.get(null);
        try{
            var defs=PosSkillBalance.catalogue();Set<String> ids=new HashSet<>();
            for(var d:defs){check(ids.add(d.id()),"Duplicate ID "+d.id());check(PosSkillBalance.valid(d.defaults()),"Invalid native defaults "+d.id());
                BattleSkill s=d.skill();int[] a=d.defaults();check(s.getTpCost()==a[1]&&s.getLevelRequired()==a[2]&&s.getMinVal()==a[3]&&s.getMaxVal()==a[4]&&s.getExtra()==a[5],"Defaults changed "+d.id());
                int[] custom={0,17,23,37,41,7};values.set(null,Map.of(d.id(),custom));
                check(s.getTpCost()==17&&s.getLevelRequired()==23&&s.getMinVal()==37&&s.getMaxVal()==41&&s.getExtra()==7,"Getter hooks missing "+d.id());
                check(PosSkillBalance.enabled(s),"Legacy disable flag must be ignored "+d.id());
                if(s instanceof PsiSkill||s instanceof LightnerSkill||s instanceof HumanMageSkill||s instanceof MonsterSkill||s instanceof SoulMageSkill||s instanceof OriSkill){int code=LiveSkills.encode(s);check(LiveSkills.decode(code)==s,"Legacy disable flag changed live decoding "+d.id());
                    custom[0]=1;check(LiveSkills.decode(code)==s,"Live re-enable missing "+d.id());
                    if(s instanceof SoulMageSkill sm){if(sm.getSoul()!=null)check(SoulMageSkill.getAvailable(23,sm.getSoul(),Set.of(sm.name())).contains(s),"Soul mage LV override ignored "+d.id());}
                    else {Method available=s.getClass().getMethod("getAvailable",int.class,Set.class);check(((List<?>)available.invoke(null,23,Set.of(((Enum<?>)s).name()))).contains(s),"LV override ignored "+d.id());custom[0]=0;check(((List<?>)available.invoke(null,10000,Set.of(((Enum<?>)s).name()))).contains(s),"Legacy disabled skill unavailable "+d.id());}}
                values.set(null,Map.of());
            }
            check(LightnerSkill.snowgraveCost(150)==300,"Native dynamic Snowgrave cost changed");
            values.set(null,Map.of(PosSkillBalance.id(LightnerSkill.SNOWGRAVE),new int[]{1,33,45,902,902,4}));
            check(LightnerSkill.snowgraveCost(150)==33,"Snowgrave override ignored");
            values.set(null,Map.of(PosSkillBalance.id(ActionSkill.INSTANCE),new int[]{1,0,1,42,42,5}));
            check(ActionSkill.INSTANCE.roll(new Random(1))==42&&ActionSkill.INSTANCE.rollScaled(new Random(1))==42,"Action ignored configured roll");
            check(!PosSkillBalance.valid(new int[]{1,10001,1,0,0,0}),"Cost limit missing");
            check(!PosSkillBalance.valid(new int[]{2,0,1,0,0,0}),"Boolean limit missing");
            check(!PosSkillBalance.valid(new int[]{1,0,0,0,0,0}),"Level limit missing");
            check(!PosSkillBalance.valid(new int[]{1,0,1,-1,0,0}),"Negative effect accepted");
            check(PosSkillBalance.valid(new int[]{1,20,6,30,3,0}),"Shield duration incorrectly treated as roll maximum");
            values.set(null,Map.of(PosSkillBalance.id(PsiSkill.FIRE_A),new int[]{0,77,12,2,9,55}));
            Method save=PosSkillBalance.class.getDeclaredMethod("save",Map.class);save.setAccessible(true);check((boolean)save.invoke(null,values.get(null)),"Save failed");
            values.set(null,Map.of());Method load=PosSkillBalance.class.getDeclaredMethod("load");load.setAccessible(true);load.invoke(null);
            check(PsiSkill.FIRE_A.getTpCost()==77&&PosSkillBalance.enabled(PsiSkill.FIRE_A),"Persistence failed");
            Path out=Path.of("skill-catalogue.json");List<Map<String,Object>> export=new ArrayList<>();for(var d:defs)export.add(Map.of("id",d.id(),"name",d.label(),"family",d.family(),"type",d.skill().getType().name(),"defaults",d.defaults()));
            Files.writeString(out,new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(export));
            System.out.println("SOULBOUNDPLUS SKILL SMOKE PASSED: "+checks+" checks across "+defs.size()+" active skills.");
        }finally{values.set(null,original);}
    }catch(Exception e){throw new RuntimeException("Skill smoke failed",e);}}
}
